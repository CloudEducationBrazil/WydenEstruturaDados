#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

Lista* criarLista(){
    Lista* lista = (Lista*) malloc (sizeof(Lista));

    lista->tmn = 0;
    lista->inicio = NULL;

    return lista;
}

void inserirInicio(Lista* lista){
    Node* node = (Node*) malloc (sizeof(Node));

    node->reg = criarReg();
    node->prox = lista->inicio;
    lista->inicio = node;
    lista->tmn++;
}

void inserirFim (Lista* lista){
    Node* node = (Node*) malloc(sizeof(Node));
    Node* aux = noIndice(lista, lista->tmn - 1);

    node->reg = criarReg();
    node->prox = NULL;
    aux->prox = node;
    lista->tmn++;
}

void exibirLista (Lista* lista){

    if (estaVazia(lista)){
        printf ("Lista Vazia !\n\n");
        return;
    }

    Node* aux = lista->inicio;

    printf ("Lista: \n\n");
    while (aux != NULL){
        exibirNode(aux);
        aux = aux->prox;
    }
    printf ("\n");
}

bool estaVazia (Lista* lista){
    if (lista->tmn == 0){
        return true;
    }
    return false;
}

void excluirInicio (Lista* lista){

    if (estaVazia(lista)){
        return;
    }
    Node* aux = lista->inicio;
    lista->inicio = aux->prox;
    free (aux);
    lista->tmn--;
}

Node* noIndice (Lista* lista, int indice){

    Node* node = lista->inicio;
    if (indice >= 0 && indice < lista->tmn){
        int i;

        for (i = 0; i < indice; i++){ //talvez mexer aqui !
            node = node->prox;
        }
        return node;
    }
    if (node == NULL)   printf ("Indice invalido.\n");
    return NULL;
}

int indiceDe (Lista* lista, Node* node){

    if (node != NULL){
        Node* aux = lista->inicio;
        int indice = 0;
        while (aux != node && aux != NULL){
            aux = aux->prox;
            indice++;
        }
        if (aux != NULL){
            return indice;
        }
    }

    printf ("invalido.\n");
    return -1;
}

void excluirIndice (Lista* lista, int indice){

    if (indice < 0){
        printf ("Indice invalido.\n\n");
        return;
    }
    if (indice == 0){
        excluirInicio(lista);
        return;
    } else {
        Node* atual = noIndice (lista, indice);
        if (atual != NULL){
            Node* anterior = noIndice (lista, indice - 1);
            anterior->prox = atual->prox;
            free (atual);
            lista->tmn--;
            return;
        }
        printf ("Impossivel apagar.\n\n");
    }
}

void excluir (Lista* lista, dataRef dataCompromisso){

    dataRef atual = dataAtual();
    Node* aux = lista->inicio;
    Node* aux2;
    bool comp;

    if (aux == NULL){
        return;
    }

    if (dataCompromisso.ano > atual.ano){
        if (dataCompromisso.mes > atual.mes){
            if (dataCompromisso.dia > atual.dia){
                printf("Data invalida.\nVoce nao precisa excluir um compromisso numa data que ja passou.\n\n");
                return;
            }
        }
    }

    comp = compararData(dataCompromisso, atual);
    aux2 = buscarDataCompromisso(lista, atual);
    if (comp) {
        if (aux2 == lista->inicio){
            excluirInicio(lista);
            return;
        } else if (aux2->prox == NULL){
            excluirIndice(lista, lista->tmn - 1);
            return;
        } else {
            int indiceAtual = indiceDe(lista, aux2);
            Node* nodeAtual = noIndice(lista, indiceAtual);
            Node* nodeAnterior = noIndice(lista, indiceAtual - 1);

            nodeAnterior->prox = nodeAtual->prox;
            free(nodeAtual);
            lista->tmn--;
            return;
        }
    }

    do {
        comp = compararDataMaior(dataCompromisso,aux->reg.dataCompromisso);
        if (comp){
            aux = aux->prox;
        } else if (aux2 == lista->inicio){
            excluirInicio(lista);
            return;
        } else {
            int indiceAtual = indiceDe(lista, aux2);
            Node* nodeAtual = noIndice(lista, indiceAtual);
            Node* nodeAnterior = noIndice(lista, indiceAtual - 1);

            nodeAnterior->prox = nodeAtual->prox;
            free(nodeAtual);
            lista->tmn--;
            return;
        }

    } while (aux->prox != NULL);

    if (aux2->prox == NULL){
        excluirIndice(lista, lista->tmn - 1);
        return;
    }

}

void inserir (Lista* lista, dataRef dataCompromisso){

    dataRef atual = dataAtual();
    Node* aux = lista->inicio;
    Node* aux2;
    bool comp;

    if (aux == NULL && lista->tmn != 0){
        return;
    }

    if (dataCompromisso.ano < atual.ano && dataCompromisso.mes < atual.mes && dataCompromisso.dia < atual.dia){
        printf("Data invalida.\nVoce nao pode agendar um compromisso numa data que ja passou.\n\n");
        return;
    }
    comp = compararData(dataCompromisso, atual);
    if (comp) {
        aux2 = buscarDataCompromisso(lista, dataCompromisso);
printf ("passou aqui 2\n");
        if (aux2 != NULL){
printf ("passou aqui 3\n");
            printf("Voce ja agendou outro compromisso para esta data.\n\n");
            return;
        }
    }

    do {
        comp = compararDataMaior(dataCompromisso,aux->reg.dataCompromisso);
        if (comp){
            aux = aux->prox;
        } else {
            if (aux == lista->inicio){
                inserirInicio(lista);
                return;
            } else {
                int indiceAtual = indiceDe(lista, aux);
                Node* nodeAtual = noIndice(lista, indiceAtual);
                Node* nodeAnterior = noIndice(lista, indiceAtual - 1);
                Node* nodeNovo = (Node*) malloc (sizeof(Node));

                nodeNovo->reg = criarReg();
                nodeAnterior->prox = nodeNovo;
                nodeNovo->prox = nodeAtual;

                lista->tmn++;
                return;
            }
        }

    } while (aux->prox != NULL);

    if (aux->prox == NULL){
        inserirFim(lista);
    }
}

void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB){

    if (nodeA == nodeB){
        return;
    }
    int indiceA = indiceDe (lista, nodeA);
    int indiceB = indiceDe (lista, nodeB);

    if (indiceA == -1 || indiceB == -1){
        return;
    }

    if (indiceA > indiceB){
        nodeA = nodeB;
        nodeB = noIndice (lista, indiceA);

        indiceA = indiceB;
        indiceB = indiceDe (lista, nodeB);
    }

    Node* anteriorB = noIndice (lista, indiceB - 1);

    if (nodeA == lista->inicio){
        lista->inicio = nodeB;
    } else {
        Node* anteriorA = noIndice (lista, indiceA - 1);
        anteriorA->prox = nodeB;
    }

    anteriorB->prox = nodeA;

    Node* aux = nodeA->prox;
    nodeA->prox = nodeB->prox;
    nodeB->prox = aux;
}

Node* min(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* minNode = aux;

        while (aux != NULL){
            if (aux->reg.chave < minNode->reg.chave){
                minNode = aux;
            }
            aux = aux->prox;
        }

        return minNode;
    }

    return NULL;
}

Node* max(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* maxNode = aux;

        while (aux != NULL){
            if (aux->reg.chave > maxNode->reg.chave){
                maxNode = aux;
            }
            aux = aux->prox;
        }

        return maxNode;
    }

    return NULL;
}

void cresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), min(lista, i));
    }
}

void decresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), max(lista, i));
    }
}

void tmnLista (Lista* lista){
    printf("Tamanho da lista: %d. \n\n", lista->tmn);
}

Node* buscarChave (Lista* lista, TIPOCHAVE chave){
    Node* aux = lista->inicio;

    while (chave >= lista->tmn + 1){
        if (aux->reg.chave == chave){
            return aux;
        }
        aux = aux->prox;
    }

    printf ("Chave (%d) nao encontrada.", chave);
    return NULL;

}

Node* buscarDataCompromisso (Lista* lista, dataRef dataCompromisso){

    Node* aux = lista->inicio;

    if (aux->prox == NULL){
        if (compararData(dataCompromisso, aux->reg.dataCompromisso)){
            return aux;
        }
        printf("Nao encontramos nenhum compromisso relacionado a esta data.\n\n");
        return NULL;
    }

    while (aux->prox != NULL){
        if (aux->prox == NULL){
            if (compararData(dataCompromisso,aux->reg.dataCompromisso)){
                return aux;
            }
        }
        aux = aux->prox;
    }
    printf("Nao encontramos nenhum compromisso relacionado a esta data.\n\n");
    return NULL;
}

void reinicializar (Lista* lista){
    while (lista->tmn > 0){
        excluirInicio(lista);
    }
}

Registro criarReg (){
    Registro reg;
    extern int masterKey;
    reg.chave = masterKey++;
    reg.dataCompromisso = preencherData();
    fflush(stdin);
    fgets(reg.descricaoCompromisso, 300, stdin);
    fflush(stdin);
    printf ("\n");
    return reg;
}

void exibirNode (Node* node){
    if (node == NULL) return;

    printf("Data: %d/%d/%d.\n", node->reg.dataCompromisso.dia, node->reg.dataCompromisso.mes, node->reg.dataCompromisso.ano);
    printf("%s \n",node->reg.descricaoCompromisso);

}

void altNodeLista (Lista* lista, dataRef dataCompromisso){
    int opc = 0;
    char compromissoAux[300];
    Node* aux;

    aux = buscarDataCompromisso(lista, dataCompromisso);
    if (aux == NULL){
        printf("Nenhum compromisso registrado nesta data.\n\n");
        return;
    }

    printf("Deseja alterar a Data? \nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
    scanf("%d",&opc);
    printf ("\n\n");
    while (opc != 1 && opc != 2){
        printf("\n\nVoce digitou um numero invalido.\nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
        scanf("%d",&opc);
        printf ("\n\n");
    }
    if (opc == 1){
        printf("Digite a nova data: ");
        dataRef novaData = preencherData();
        aux->reg.dataCompromisso = novaData;
        printf("Data alterada!");
    }

    printf("Deseja alterar o Compromisso? \nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
    scanf("%d",&opc);
    printf ("\n\n");
    while (opc != 1 && opc != 2){
        printf("\n\nVoce digitou um numero invalido.\nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
        scanf("%d",&opc);
        printf ("\n\n");
    }
    if (opc == 1){
        printf("Digite o novo compromisso: ");
        fflush(stdin);
        fgets(compromissoAux, 300, stdin);
        fflush(stdin);
        strcpy(aux->reg.descricaoCompromisso, compromissoAux);
        printf("Compromisso alterado!");
    }
}

dataRef preencherData (){
    dataRef dataPreenchida;

    printf("Digite o Ano: ");
    scanf("%d", &dataPreenchida.ano);
    fflush(stdin);
    printf("Digite o Mes: ");
    scanf("%d", &dataPreenchida.mes);
    fflush(stdin);
    printf("Digite o Dia: ");
    scanf("%d", &dataPreenchida.dia);
    fflush(stdin);

    return dataPreenchida;
}

bool compararData (dataRef data1, dataRef data2){

    if (data1.ano == data2.ano){
        if (data1.mes == data2.mes){
            if (data1.dia == data2.dia){
                return true;
            }
        }
    }
    return false;
}

bool compararDataMaior (dataRef data1, dataRef data2){

    if (data1.ano >= data2.ano){
        if (data1.mes >= data2.mes){
            if (data1.dia > data2.dia){
                return true;
            }
        }
    }
    return false;
}

dataRef dataAtual (){
    dataRef atual;

    time_t mytime;
    mytime = time(NULL);
    struct tm tm = *localtime(&mytime);

    atual.ano = tm.tm_year + 1900;
    atual.dia = tm.tm_mday;
    atual.mes = tm.tm_mon + 1;

    return atual;
}

void displayMenu (){

    printf ("Selecione uma opcao: \n");
    printf (" 1 - Criar Lista  2 - Exibir Tamanho  3 - Exibir Lista \n");
    printf (" 4 - Buscar \t  5 - Inserir \t      6 - Deletar \n");
    printf (" 7 - Alterar \t  8 - Salvar \t      9 - Carregar \n");
    printf ("10 - Reiniciar \t 11 - Ajuda \t     12 - Sair \n");
    //printf ("13 - Sair \n");


}