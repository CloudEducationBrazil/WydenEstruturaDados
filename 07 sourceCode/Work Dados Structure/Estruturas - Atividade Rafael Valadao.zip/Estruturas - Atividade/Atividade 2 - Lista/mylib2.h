#ifndef MYLIB2_HEADER_
#define MYLIB2_HEADER_

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

typedef int TIPOCHAVE;
int masterKey = 0;

typedef struct {
	int dia;
	int mes;
	int ano;
}dataRef;

typedef struct {
	TIPOCHAVE chave;            // ControleID
	dataRef dataCompromisso; // Data Compromisso
	char descricaoCompromisso[300]; // Descri��o

} Registro;

typedef struct node{
  Registro reg;
  struct node* prox;
} Node;

typedef struct lista{
    int tmn;
    Node* inicio;
} Lista;


// DECLARA��O DE FUN��ES //

Lista* criarLista();
void inserirInicio (Lista* lista);
void inserirFim (Lista* lista);
void exibirLista (Lista* lista);
bool estaVazia (Lista* lista);
void excluirInicio (Lista* lista);
Node* noIndice (Lista* lista, int indice);
int indiceDe (Lista* lista, Node* node);
void excluirIndice (Lista* lista, int indice);
void excluir (Lista* lista, dataRef dataCompromisso);
void inserir (Lista* lista, dataRef dataCompromisso);
void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB);
Node* min(Lista* lista, int indice);
Node* max(Lista* lista, int index);
void cresOrdem (Lista* lista);
void decresOrdem (Lista* lista);
void tmnLista (Lista* lista);
Node* buscarChave (Lista* lista, TIPOCHAVE chave);
Node* buscarDataCompromisso (Lista* lista, dataRef dataCompromisso);
bool compararData (dataRef data1, dataRef data2);
Registro criarReg();
dataRef preencherData ();
dataRef dataAtual ();
void altNodeLista (Lista* lista, dataRef dataCompromisso);
bool compararDataMaior (dataRef data1, dataRef data2);
void displayMenu();
void exibirNode (Node* node);

#endif