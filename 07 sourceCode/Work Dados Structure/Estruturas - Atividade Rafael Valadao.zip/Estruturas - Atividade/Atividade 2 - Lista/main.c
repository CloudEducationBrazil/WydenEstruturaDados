#include "mylib2.h"
#include "mylib2.c"



int main (){

    int opcMenu = 0;
    dataRef dataBuscada, dataCompromisso;
    Node* aux;

    displayMenu();
    Lista* lista;

    do {
    printf("Selecione a opcao: ");
    scanf("%d", &opcMenu);
    printf("\n");

    switch (opcMenu){
    case 1:
        lista = criarLista();
        if (lista != NULL){
            printf("Lista criada com sucesso!\n\n");
        } else {
            printf("Erro ao criar lista, tente novamente!\n\n");
        }
        break;

    case 9:
        // CARREGA LISTA
        printf("Recurso indisponivel\n\n");
        break;

    case 11:
        printf("Recurso indisponivel\n\n");
        break;

    case 12:
        system("cls");
        printf("Programa finalizado.\n\n");
        return 0;

    default:
        if (opcMenu == 0 || opcMenu > 12){
            printf("opcao invalida!\n\n");
            break;
        }
        printf("Voce precisa criar uma nova lista ou carrega uma ja existente para utilizar essa opcao.\n\n");
        break;
    }

    } while (opcMenu != 1);
    fflush(stdin);
    system("pause");
    system("cls");
    displayMenu();

    do {

    printf("Selecione a opcao: ");
    scanf("%d", &opcMenu);
    printf("\n");

    switch (opcMenu){

    case 1:
        printf("voce ja tem uma lista criada ou carregada.\nEncerre esta lista antes de criar uma nova.\n\n");
        break;

    case 2:
        tmnLista(lista);
        break;

    case 3:
        exibirLista(lista);
        break;

    case 4:
        if (estaVazia(lista)){
            printf("Nao eh possivel realizar essa acao com uma Lista vazia!\n\n");
            break;
        }
        printf("Digite a Data que deseja buscar: ");
        fflush(stdin);
        dataBuscada = preencherData();
        printf("\n\n");
        aux = buscarDataCompromisso(lista, dataBuscada);
        exibirNode(aux);
        break;

    case 5:
        printf("Digite a data que deseja registrar o compromisso.\nData: ");
        dataCompromisso = preencherData();
        inserir(lista, dataCompromisso);
        //printf("Novo compromisso criado com sucesso!\n\n");
        break;

    case 6:
        if (estaVazia(lista)){
            printf("Lista ja esta vazia!\n\n");
            break;
        }
        printf("Digite a data que deseja excluir o compromisso.\nData: ");
        dataCompromisso = preencherData();
        excluir(lista, dataCompromisso);
        printf("Compromisso deletado com sucesso!\n\n");
        break;

    case 7:
        if (estaVazia(lista)){
            printf("Nao eh possivel realizar essa acao com uma Lista vazia!\n\n");
            break;
        }
        printf("Digite a data que deseja alterar o compromisso.\nData: ");
        dataCompromisso = preencherData();
        altNodeLista(lista, dataCompromisso);
        break;

    case 8:
        printf("EM BREVE . . .\n\n");
        break;

    case 9:
        printf("voce ja tem uma lista criada ou carregada.\nEncerre esta lista antes de carregar uma nova.\n\n");
        break;

    case 10:
        reinicializar(lista);
        printf("Lista reinicializada com sucesso!\n\n");
        break;

    case 11:
        printf("EM BREVE . . .\n\n");
        break;

    case 12:
        system("cls");
        printf("Programa finalizado.\n\n");
        return 0;

    default:
        printf("Essa nao � uma opcao valida!\n\n");
        system("pause");
        system("cls");
        displayMenu();
    }

    } while (opcMenu >= 1 || opcMenu <= 12);

    return 0;

}
