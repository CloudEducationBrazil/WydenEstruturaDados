#ifndef MYLIB_HEADER_
#define MYLIB_HEADER_

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

typedef int TIPOCHAVE;
int masterKey = 0;

typedef struct {
	int dia;
	int mes;
	int ano;
}dataRef;

typedef struct {
	dataRef dataAcesso; // Data de Acesso
	char nomePorteiro[200]; // Nome Porteiro
}Funcionario;

typedef struct {
	TIPOCHAVE chave;            // ControleID
	char matricula[20]; // Matr�cula do Aluno
// Descri��o da Ocorr�ncia (Esqueceu/Perdeu/NaoPossui/Outros cart�o)
	char tipoOcorrencia[10];
} Registro;

typedef struct node{
  Registro reg;
  struct node* prox;
} Node;

typedef struct lista{
    int tmn;
    Node* inicio;
} Lista;


// DECLARA��O DE FUN��ES //

Lista* criarLista();
void inserirInicio (Lista* lista);
void inserirFim (Lista* lista);
void exibirLista (Lista* lista);
bool estaVazia (Lista* lista);
void excluirInicio (Lista* lista);
Node* noIndice (Lista* lista, int indice);
int indiceDe (Lista* lista, Node* node);
void excluir (Lista* lista, int indice);
void inserir (Lista* lista, int indice);
void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB);
Node* min(Lista* lista, int indice);
Node* max(Lista* lista, int index);
void cresOrdem (Lista* lista);
void decresOrdem (Lista* lista);
void tmnLista (Lista* lista);
Node* buscarChave (Lista* lista, TIPOCHAVE chave);
Node* buscarMatricula (Lista* lista, char matricula[]);
void altNodeTipoOcr (Lista* lista, char matricula[]);
void altNodeMatricula (Lista* lista, char *matricula);
void altNode (Lista* lista, TIPOCHAVE chave);
Registro criarReg();
void displayMenu();
void exibirNode (Node* node);
Funcionario iniciarTurno ();
//void login (char *nomePorteiro);

#endif