#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

Lista* criarLista(){
    Lista* lista = (Lista*) malloc (sizeof(Lista));

    lista->tmn = 0;
    lista->inicio = NULL;

    return lista;
}

void inserirInicio(Lista* lista){
    Node* node = (Node*) malloc (sizeof(Node));

    node->reg = criarReg();
    node->prox = lista->inicio;
    lista->inicio = node;
    lista->tmn++;
}

void inserirFim (Lista* lista){
    if (lista->tmn == 0){
        inserirInicio(lista);
        return;
    }

    Node* node = (Node*) malloc(sizeof(Node));
    Node* aux = noIndice(lista, lista->tmn - 1);

    node->reg = criarReg();
    node->prox = NULL;
    aux->prox = node;
    lista->tmn++;
}

void exibirLista (Lista* lista){

    if (estaVazia(lista)){
        printf ("Lista Vazia !\n\n");
        return;
    }

    Node* aux = lista->inicio;

    printf ("Lista: \n\n");
    while (aux != NULL){
        //printf ("%s\t", aux->reg.matricula);
        exibirNode(aux);
        aux = aux->prox;
    }
    printf ("\n");
}

bool estaVazia (Lista* lista){
    if (lista->tmn == 0){
        return true;
    }
    return false;
}

void excluirInicio (Lista* lista){

    if (estaVazia(lista)){
        return;
    }
    Node* aux = lista->inicio;
    lista->inicio = aux->prox;
    free (aux);
    lista->tmn--;
}

Node* noIndice (Lista* lista, int indice){

    Node* node = lista->inicio;
    if (indice >= 0 && indice < lista->tmn){
        int i;

        for (i = 0; i < indice; i++){ //talvez mexer aqui !
            node = node->prox;
        }
        return node;
    }
    if (node == NULL)   printf ("Indice invalido.\n");
    return NULL;
}

int indiceDe (Lista* lista, Node* node){

    if (node != NULL){
        Node* aux = lista->inicio;
        int indice = 0;
        while (aux != node && aux != NULL){
            aux = aux->prox;
            indice++;
        }
        if (aux != NULL){
            return indice;
        }
    }

    printf ("invalido.\n");
    return -1;
}

void excluir (Lista* lista, int indice){

    if (indice < 0){
        printf ("Indice invalido.\n\n");
        return;
    }
    if (indice == 0){
        excluirInicio(lista);
        return;
    } else {
        Node* atual = noIndice (lista, indice);
        if (atual != NULL){
            Node* anterior = noIndice (lista, indice - 1);
            anterior->prox = atual->prox;
            free (atual);
            lista->tmn--;
            return;
        }
        printf ("Impossivel apagar.\n\n");
    }
}

void inserir (Lista* lista, int indice){

    if (indice < 0){
        printf("Indice invalido.");
        return;
    }
    if (indice == 0){
        inserirInicio(lista);
    } else if (indice == lista->tmn){
        inserirFim(lista);
    } else {
        Node* atual = noIndice (lista, indice);
        if (atual != NULL){
            Node* anterior = noIndice (lista, indice - 1);
            Node* novo = (Node*) malloc (sizeof(Node));

            novo->reg = criarReg();
            anterior->prox = novo;
            novo->prox = atual;

            lista->tmn++;
            return;
        }
            printf ("Impossivel inserir.\n");
    }
}

void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB){

    if (nodeA == nodeB){
        return;
    }
    int indiceA = indiceDe (lista, nodeA);
    int indiceB = indiceDe (lista, nodeB);

    if (indiceA == -1 || indiceB == -1){
        return;
    }

    if (indiceA > indiceB){
        nodeA = nodeB;
        nodeB = noIndice (lista, indiceA);

        indiceA = indiceB;
        indiceB = indiceDe (lista, nodeB);
    }

    Node* anteriorB = noIndice (lista, indiceB - 1);

    if (nodeA == lista->inicio){
        lista->inicio = nodeB;
    } else {
        Node* anteriorA = noIndice (lista, indiceA - 1);
        anteriorA->prox = nodeB;
    }

    anteriorB->prox = nodeA;

    Node* aux = nodeA->prox;
    nodeA->prox = nodeB->prox;
    nodeB->prox = aux;
}

Node* min(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* minNode = aux;

        while (aux != NULL){
            if (aux->reg.chave < minNode->reg.chave){
                minNode = aux;
            }
            aux = aux->prox;
        }

        return minNode;
    }

    return NULL;
}

Node* max(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* maxNode = aux;

        while (aux != NULL){
            if (aux->reg.chave > maxNode->reg.chave){
                maxNode = aux;
            }
            aux = aux->prox;
        }

        return maxNode;
    }

    return NULL;
}

void cresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), min(lista, i));
    }
}

void decresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), max(lista, i));
    }
}

void tmnLista (Lista* lista){
    printf("Tamanho da lista: %d. \n\n", lista->tmn);
}

Node* buscarChave (Lista* lista, TIPOCHAVE chave){
    Node* aux = lista->inicio;

    while (chave >= lista->tmn + 1){
        if (aux->reg.chave == chave){
            return aux;
        }
        aux = aux->prox;
    }

    printf ("Chave (%d) nao encontrada.", chave);
    return NULL;

}

Node* buscarMatricula (Lista* lista, char matricula[]){
    Node* aux = lista->inicio;

    while (aux->prox != NULL){
        if (strcmp (aux->reg.matricula, matricula) == 0){
            return aux;
        }
        aux = aux->prox;
    }
    if (aux->prox == NULL){
        if (strcmp (aux->reg.matricula, matricula) == 0){
            return aux;
        }
    }

    //if (aux == NULL && aux->prox == NULL)
    printf (" Matricula Nao encontrada.");
    return NULL;

}

void altNodeTipoOcr (Lista* lista, char matricula[]){
    Node* aux = buscarMatricula(lista, matricula);

    if (aux != NULL){
        printf ("Tipo de Ocorrencia atual: %s", aux->reg.tipoOcorrencia);
        printf ("\nDigite o novo tipo de ocorencia: ");
        fflush(stdin);
        fgets (aux->reg.tipoOcorrencia, 10, stdin);
        printf ("\n\n");
        fflush(stdin);
    }
}

void altNodeMatricula (Lista* lista, char matricula[]){
    Node* aux = buscarMatricula (lista, matricula);

    if (aux != NULL){
        printf ("Matricula atual: %s", aux->reg.matricula);
        printf ("Digite a nova matricula: ");
        fflush(stdin);
        fgets (aux->reg.matricula, 20, stdin);
        printf ("\n\n");
        fflush(stdin);
    }
}

void altNodeAcesso (Lista* lista){

    int opc = 0;
    char matriculaAux[20];
    Node* aux;

    printf("Selecione o tipo de alteracao: \n1 - Ultimo Registro \t 2 - Registros Anteriores\nOpcao: ");
    scanf("%d",&opc);
    printf ("\n\n");
    while (opc != 1 && opc != 2){
            printf("Voce digitou um numero invalido.\nDigite: 1 - Ultimo Registro \t 2 - Registros Anteriores\nOpcao: ");
            scanf("%d",&opc);
            printf ("\n\n");
    }

    if (opc == 1){
        aux = noIndice(lista,lista->tmn - 1);
    }
    if (opc == 2){
        printf("Digite a matricula do Registro que deseja alterar: ");
        fflush(stdin);
        fgets(matriculaAux,20,stdin);
        aux = buscarMatricula(lista,matriculaAux);
    }

    if (aux != NULL){
        printf("Deseja alterar a Matricula? \nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
        scanf("%d",&opc);
        printf ("\n\n");
        while (opc != 1 && opc != 2){
            printf("\n\nVoce digitou um numero invalido.\nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
            scanf("%d",&opc);
            printf ("\n\n");
        }
        if (opc == 1)   altNodeMatricula(lista, aux->reg.matricula);

        printf("Deseja alterar a Ocorrencia? \nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
        scanf("%d",&opc);
        printf ("\n\n");
        while (opc != 1 && opc != 2){
            printf("\n\nVoce digitou um numero invalido.\nDigite: 1 - SIM \t 2 - NAO\n\nOpcao: ");
            scanf("%d",&opc);
            printf ("\n\n");
        }
        if (opc == 1)   altNodeTipoOcr(lista,aux->reg.matricula);
    }
}

void reinicializar (Lista* lista){
    while (lista->tmn > 0){
        excluirInicio(lista);
    }
}

Registro criarReg (){
    Registro reg;
    //bool certo = false;
    int tipo = 0;
    //char matricula[20];
    extern int masterKey;
    reg.chave = masterKey++;  // TEM QUE MEXER AQUI//
    printf ("Digite o numero de matricula: ");
    fflush(stdin);
    fgets (reg.matricula, 20, stdin);
    /*while (certo != true){
        printf ("Digite o numero de matricula: ");
        fgets (matricula, 20, stdin);
        for (int i = 0; i < 20 ; i++){
            if (matricula[i] < '0' || matricula[i] > '9'){
                printf ("Voce so pode digitar numeros nesse campo.\n");
                break;
            } else {
                reg.matricula[20] = matricula[20];
                certo = true;
            }
        }
    }*/
    printf ("\nSelecione o tipo de ocorrencia: \n");
    printf(" 1 - Esqueceu \t 2 - Perdeu \n 3 - Nao Possui  4 - Outro\n");
    while (tipo < 1 || tipo > 4){
        printf("\nOpcao: ");
        scanf ("%d", &tipo);
        switch (tipo){
        case 1:
            strcpy(reg.tipoOcorrencia, "Esqueceu");
            break;
        case 2:
            strcpy(reg.tipoOcorrencia, "Perdeu");
            break;
        case 3:
            strcpy(reg.tipoOcorrencia, "Nao Possui");
            break;
        case 4:
            strcpy(reg.tipoOcorrencia, "Outro");
            break;
        case 5:
            default:
            printf ("Valor invalido.\n");
        }
    }
    fflush(stdin);
    printf ("\n");
    return reg;
}

Funcionario iniciarTurno (){
    Funcionario atual;

    printf("Iniciar Turno . . .\n\n");

    printf ("Digite seu nome: ");
    fgets (atual.nomePorteiro,200,stdin);

    time_t mytime;
    mytime = time(NULL);
    struct tm tm = *localtime(&mytime);

    atual.dataAcesso.ano = tm.tm_year + 1900;
    atual.dataAcesso.dia = tm.tm_mday;
    atual.dataAcesso.mes = tm.tm_mon + 1;

    printf ("\n\nLogin efetuado com sucesso !");
    printf ("\n\nFuncionario atual: %s",atual.nomePorteiro);
    if (atual.dataAcesso.mes + 1 < 10 ) printf ("Data: %d/0%d/%d\n\n", atual.dataAcesso.dia, atual.dataAcesso.mes, atual.dataAcesso.ano);
    if (atual.dataAcesso.mes + 1 >= 10 ) printf ("Data: %d/%d/%d\n\n", atual.dataAcesso.dia, atual.dataAcesso.mes, atual.dataAcesso.ano);

    system("pause");
    system("cls");

    return atual;
}

void exibirNode (Node* node){
    if (node == NULL) return;
    printf("Matricula: %s",node->reg.matricula);
    printf("Ocorrencia: %s",node->reg.tipoOcorrencia);
    printf("\nchave: %d\n\n",node->reg.chave);
}

void displayMenu (){

    printf ("Selecione uma opcao: \n");
    printf (" 1 - Criar Lista  2 - Exibir Tamanho  3 - Exibir Lista \n");
    printf (" 4 - Buscar \t  5 - Inserir \t      6 - Deletar \n");
    printf (" 7 - Alterar \t  8 - Salvar \t      9 - Carregar \n");
    printf ("10 - Reiniciar \t 11 - Ajuda \t     12 - Sair \n");

}