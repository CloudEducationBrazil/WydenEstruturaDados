#include "mylib.h"
#include "mylib.c"

int main (){

    Funcionario funcionario;
    int opcMenu = 0, opcSubMenu = 0;
    char matriculaBuscada[20];
    Node* aux;
    funcionario = iniciarTurno();

    displayMenu();
    Lista* lista;

    do {
    printf("Selecione a opcao: ");
    scanf("%d", &opcMenu);
    printf("\n");

    switch (opcMenu){
    case 1:
        lista = criarLista();
        if (lista != NULL){
            printf("Lista criada com sucesso!\n\n");
        } else {
            printf("Erro ao criar lista, tente novamente!\n\n");
        }
        break;

    case 9:
        // CARREGA LISTA
        printf("Recurso indisponivel.\n\n");
        break;

    case 11:
        printf("Recurso indisponivel.\n\n");
        break;

    case 12:
        system("cls");
        printf("Funcionario: %s\n", funcionario.nomePorteiro);
        printf("Deslogado! \n\nPrograma finalizado.\n\n");
        return 0;

    default:
        printf("Voce precisa criar uma nova lista ou carrega uma ja existente para utilizar essa opcao.\n\n");
    }

    } while (opcMenu != 1);
    fflush(stdin);
    system("pause");
    system("cls");
    displayMenu();

    do {

    printf("Selecione a opcao: ");
    scanf("%d", &opcMenu);
    printf("\n");

    switch (opcMenu){

    case 1:
        printf("voce ja tem uma lista criada ou carregada.\nEncerre esta lista antes de criar uma nova.\n\n");
        break;

    case 2:
        tmnLista(lista);
        break;

    case 3:
        exibirLista(lista);
        break;

    case 4:
        if (estaVazia(lista)){
            printf("Nao eh possivel realizar essa acao com uma Lista vazia!\n\n");
            break;
        }
        printf("Digite a Matricula que deseja buscar: ");
        fflush(stdin);
        fgets(matriculaBuscada,20,stdin);
        printf("\n\n");
        aux = buscarMatricula(lista,matriculaBuscada);
        exibirNode(aux);
        break;

    case 5:
        inserirFim(lista);
        printf("Novo registro criado com sucesso!\n\n");
        break;

    case 6:
        if (lista->tmn > 0){
            excluir(lista,lista->tmn - 1);
            printf("Registro deletado com sucesso!\n\n");
        } else {
            printf("Esta lista ja esta vazia!\n\n");
        }
        break;

    case 7:
        if (estaVazia(lista)){
            printf("Nao eh possivel realizar essa acao com uma Lista vazia!\n\n");
            break;
        }
        altNodeAcesso(lista);
        break;

    case 8:
        printf("EM BREVE . . .\n\n");
        break;

    case 9:
        printf("voce ja tem uma lista criada ou carregada.\nEncerre esta lista antes de carregar uma nova.\n\n");
        break;

    case 10:
        reinicializar(lista);
        printf("Lista reinicializada com sucesso!\n\n");
        break;

    case 11:
        printf("EM BREVE . . .\n\n");
        break;

    case 12:
        system("cls");
        printf("Funcionario: %s\n", funcionario.nomePorteiro);
        printf("Deslogado! \n\nPrograma finalizado.\n\n");
        return 0;

    default:
        printf("Essa nao � uma opcao valida!\n\n");
        system("pause");
        system("cls");
        displayMenu();
    }

    } while (opcMenu >= 1 || opcMenu <= 12);


    return 0;

}
