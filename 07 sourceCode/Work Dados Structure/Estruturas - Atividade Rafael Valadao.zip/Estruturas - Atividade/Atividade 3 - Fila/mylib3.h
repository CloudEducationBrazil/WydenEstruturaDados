#ifndef MYLIB2_HEADER_
#define MYLIB2_HEADER_

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>

typedef int TIPOCHAVE;
int masterKey = 0;

typedef struct {
	TIPOCHAVE chave;
} Registro;

typedef struct node{
  Registro reg;
  struct node* prox;
} Node;

typedef struct lista{
    int tmn;
    Node* inicio;
} Lista;


// DECLARA��O DE FUN��ES //

Lista* criarLista();
void inserirInicio (Lista* lista);
void inserirFim (Lista* lista);
void exibirLista (Lista* lista);
bool estaVazia (Lista* lista);
void excluirInicio (Lista* lista);
Node* noIndice (Lista* lista, int indice);
int indiceDe (Lista* lista, Node* node);
void excluir (Lista* lista, int indice);
void inserir (Lista* lista, int indice);
void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB);
Node* min(Lista* lista, int indice);
Node* max(Lista* lista, int index);
void cresOrdem (Lista* lista);
void decresOrdem (Lista* lista);
void tmnLista (Lista* lista);
Node* buscarChave (Lista* lista, TIPOCHAVE chave);
void altNode (Lista* lista);
Registro criarReg();
void displayMenu();
void exibirNode (Node* node);

#endif