#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdbool.h>
#include<time.h>
#include "mylib3.h"

Lista* criarLista(){
    Lista* lista = (Lista*) malloc (sizeof(Lista));

    lista->tmn = 0;
    lista->inicio = NULL;

    return lista;
}

void inserirInicio(Lista* lista){
    Node* node = (Node*) malloc (sizeof(Node));

    node->reg = criarReg();
    node->prox = lista->inicio;
    lista->inicio = node;
    lista->tmn++;
}

void inserirFim (Lista* lista){
    if (lista->tmn == 0){
        inserirInicio(lista);
        return;
    }

    Node* node = (Node*) malloc(sizeof(Node));
    Node* aux = noIndice(lista, lista->tmn - 1);

    node->reg = criarReg();
    node->prox = NULL;
    aux->prox = node;
    lista->tmn++;
}

void exibirLista (Lista* lista){

    if (estaVazia(lista)){
        printf ("Lista Vazia !\n\n");
        return;
    }

    Node* aux = lista->inicio;

    printf ("Lista: \n\n");
    while (aux != NULL){
        exibirNode(aux);
        aux = aux->prox;
    }
    printf ("\n");
}

bool estaVazia (Lista* lista){
    if (lista->tmn == 0){
        return true;
    }
    return false;
}

void excluirInicio (Lista* lista){

    if (estaVazia(lista)){
        return;
    }
    Node* aux = lista->inicio;
    lista->inicio = aux->prox;
    free (aux);
    lista->tmn--;
}

Node* noIndice (Lista* lista, int indice){

    Node* node = lista->inicio;
    if (indice >= 0 && indice < lista->tmn){
        int i;

        for (i = 0; i < indice; i++){ //talvez mexer aqui !
            node = node->prox;
        }
        return node;
    }
    if (node == NULL)   printf ("Indice invalido.\n");
    return NULL;
}

int indiceDe (Lista* lista, Node* node){

    if (node != NULL){
        Node* aux = lista->inicio;
        int indice = 0;
        while (aux != node && aux != NULL){
            aux = aux->prox;
            indice++;
        }
        if (aux != NULL){
            return indice;
        }
    }

    printf ("invalido.\n");
    return -1;
}

void excluir (Lista* lista, int indice){

    if (indice < 0){
        printf ("Indice invalido.\n\n");
        return;
    }
    if (indice == 0){
        excluirInicio(lista);
        return;
    } else {
        Node* atual = noIndice (lista, indice);
        if (atual != NULL){
            Node* anterior = noIndice (lista, indice - 1);
            anterior->prox = atual->prox;
            free (atual);
            lista->tmn--;
            return;
        }
        printf ("Impossivel apagar.\n\n");
    }
}

void inserir (Lista* lista, int indice){

    if (indice < 0){
        printf("Indice invalido.");
        return;
    }
    if (indice == 0){
        inserirInicio(lista);
    } else if (indice == lista->tmn){
        inserirFim(lista);
    } else {
        Node* atual = noIndice (lista, indice);
        if (atual != NULL){
            Node* anterior = noIndice (lista, indice - 1);
            Node* novo = (Node*) malloc (sizeof(Node));

            novo->reg = criarReg();
            anterior->prox = novo;
            novo->prox = atual;

            lista->tmn++;
            return;
        }
            printf ("Impossivel inserir.\n");
    }
}

void trocarNodes (Lista* lista, Node* nodeA, Node* nodeB){

    if (nodeA == nodeB){
        return;
    }
    int indiceA = indiceDe (lista, nodeA);
    int indiceB = indiceDe (lista, nodeB);

    if (indiceA == -1 || indiceB == -1){
        return;
    }

    if (indiceA > indiceB){
        nodeA = nodeB;
        nodeB = noIndice (lista, indiceA);

        indiceA = indiceB;
        indiceB = indiceDe (lista, nodeB);
    }

    Node* anteriorB = noIndice (lista, indiceB - 1);

    if (nodeA == lista->inicio){
        lista->inicio = nodeB;
    } else {
        Node* anteriorA = noIndice (lista, indiceA - 1);
        anteriorA->prox = nodeB;
    }

    anteriorB->prox = nodeA;

    Node* aux = nodeA->prox;
    nodeA->prox = nodeB->prox;
    nodeB->prox = aux;
}

Node* min(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* minNode = aux;

        while (aux != NULL){
            if (aux->reg.chave < minNode->reg.chave){
                minNode = aux;
            }
            aux = aux->prox;
        }

        return minNode;
    }

    return NULL;
}

Node* max(Lista* lista, int indice){
    Node* aux = noIndice (lista, indice);

    if (aux != NULL){
        Node* maxNode = aux;

        while (aux != NULL){
            if (aux->reg.chave > maxNode->reg.chave){
                maxNode = aux;
            }
            aux = aux->prox;
        }

        return maxNode;
    }

    return NULL;
}

void cresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), min(lista, i));
    }
}

void decresOrdem (Lista* lista){
    int i;

    for (i=0; i < lista->tmn - 1; i++){
        trocarNodes(lista, noIndice(lista, i), max(lista, i));
    }
}

void tmnLista (Lista* lista){
    printf("Tamanho da lista: %d. \n\n", lista->tmn);
}

Node* buscarChave (Lista* lista, TIPOCHAVE chave){
    Node* aux = lista->inicio;

    if (chave == 0){
        return aux;
    }

    while (chave <= lista->tmn - 1){
        if (aux->reg.chave == chave){
            return aux;
        }
        aux = aux->prox;
    }

    printf ("Chave (%d) nao encontrada.\n\n", chave);
    return NULL;

}

void reinicializar (Lista* lista){
    while (lista->tmn > 0){
        excluirInicio(lista);
    }
}

Registro criarReg (){
    Registro reg;
    extern int masterKey;
    reg.chave = masterKey++;
    printf ("Chave: %d\n\n", reg.chave);
    return reg;
}

void exibirNode (Node* node){
    if (node == NULL) return;
    printf("Chave: %d\n\n",node->reg.chave);
}

void altNode (Lista* lista){
    TIPOCHAVE chave = 0;
    printf("Digite a Chave que deseja alterar: ");
    scanf("%d",&chave);
    fflush(stdin);
    Node* aux = buscarChave(lista, chave);
    if (aux != NULL){
        printf("\n\n");
        printf("Chave Atual: %d\n", aux->reg.chave);
        printf("Nova Chave: ");
        scanf("%d",&chave);
        fflush(stdin);
	aux->reg.chave = chave;
        printf("\n\n");
        printf("Chave alterada com sucesso!\n\n");
        return;
    }
    printf("Esta chave nao existe.\n\n");
}

void displayMenu (){

    printf ("Selecione uma opcao: \n");
    printf (" 1 - Criar Lista  2 - Exibir Tamanho  3 - Exibir Lista \n");
    printf (" 4 - Buscar \t  5 - Inserir \t      6 - Deletar \n");
    printf (" 7 - Alterar \t  8 - Salvar \t      9 - Carregar \n");
    printf ("10 - Reiniciar \t 11 - Ajuda \t     12 - Sair \n");

}
