#include <stdio.h>
#include <stdlib.h>

#define MAX 5

typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;

typedef struct {
	dataRef dataAcesso; // Data de Acesso
	char nomePorteiro[30]; // Nome do porteiro
} dadosHeaderf;

typedef struct{
	TIPOCHAVE chave; // Controle ID
	int matricula; // Matr�cula do aluno
	char tipoOcorrencia[20]; //(Esqueceu/Perdeu/Nao Possui/Outros Cartoes)
} REGISTRO;

typedef struct{
    REGISTRO vetor[100];
    int nroElem;
} LISTA;

void criarLista(LISTA *lista);
int tamanhoLista(LISTA *lista);
void imprimirLista(LISTA *lista);
void buscarRegistro(LISTA *lista, int posicao);
void inserirFinal(LISTA *lista, REGISTRO registro);
void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao);
void inserirInicio(LISTA *lista, REGISTRO registro);
void alterarRegistro(LISTA *lista, int posicao);
void excluirRegistro(LISTA *lista, int posicao);
void salvarArquivo(LISTA *pilha);
void carregarArquivo(LISTA *pilha);
void reiniciliarLista(LISTA *lista);

int main(){

    LISTA lista;
    REGISTRO registro;
    TIPOCHAVE chave;
    int op, posicao, op2;
    dadosHeaderf dados;
	FILE *file;

	printf("\n OLA USUARIO, BEM VINDO!\n");
	printf("PARA COMECAR, DIGITE AQUI O NOME DO PORTEIRO: ");
	fflush(stdin);
	fgets(dados.nomePorteiro,30,stdin);
	printf("\nINSIRA A DATA...\n");
	printf("DIA: ");
	scanf("%d",&dados.dataAcesso.dia);
	printf("MES: ");
	scanf("%d",&dados.dataAcesso.mes);
	printf("ANO: ");
	scanf("%d",&dados.dataAcesso.ano);

	file = fopen ("registrosPortaria.txt","w");
	if(file==NULL){
		printf("Erro\n");
		system("pause");
	}else{
		fprintf(file,"%s %d %d %d",dados.nomePorteiro,dados.dataAcesso.dia,dados.dataAcesso.mes,dados.dataAcesso.ano);
	}
	fclose(file);

	do{
        system("cls");
        printf("\n VOCE ESTA NO MENU! O QUE VOCE DESEJA FAZER?\n\n");
		printf("1 - CRIAR LISTA\n");
 	  	printf("2 - IMPRIMIR O TAMANHO\n");
 	  	printf("3 - IMPRIMIR OS ELEMENTOS\n");
	  	printf("4 - BUSCAR O ELEMENTO\n");
 	  	printf("5 - INSERIR O ELEMENTO\n");
	   	printf("6 - ALTERAR ELEMENTO\n");
	   	printf("7 - EXCLUIR ELEMENTO\n");
	   	printf("8 - SALVAR O ARQUIVO\n");
 	  	printf("9 - CARREGAR ARQUIVO\n");
 	  	printf("10 - REINICIALIZAR\n");
 	  	printf("0 - ENCERRAR O PROGRAMA\n\n");
	   	printf("DIGITE AQUI UMA OPCAO: ");
	   	scanf("%d",&op);
	   	switch(op){
    	    case 1:{
    	    	criarLista(&lista);
				break;
			}case 2:{
				system("cls");
   	        	printf("A QUANTIDADE DE ELEMENTOS: %d\n",tamanhoLista(&lista));
   	        	system("pause");
    	        break;
    	    }
    	    case 3:{
    	    	imprimirLista(&lista);
				break;
			}
			case 4:{
				printf("DIGITE A POSICAO PARA BUSCAR: ");
				scanf("%d",&posicao);
    	    	buscarRegistro(&lista,posicao);
				break;
			}
			case 5:{
				system("cls");
				printf("CHAVE: ");
    	    	scanf("%d",&registro.chave);
				printf("MATRICULA: ");
    	    	scanf("%d",&registro.matricula);
    	    	printf("OCORRENCIA: ");
    	    	fflush(stdin);
    	    	fgets(registro.tipoOcorrencia,20,stdin);
    	    	system("cls");
    	       	printf("SELECIONE UMA DAS SEGUINTES OP�OES: \n\n");
    	       	printf("1 - Inserir no INICIO\n");
    	       	printf("2 - Inserir no FIM\n");
    	       	printf("3 - Inserir por POSICAO\n");
    	       	printf("OPCAO: ");
    	    	scanf("%d",&op2);
    	    	switch(op2){
    	    		case 1:{
    	    			inserirInicio(&lista,registro);
						break;
					}case 2:{
						inserirFinal(&lista,registro);
						break;
					}case 3:{
						system("cls");
						printf("DIGITE A POSICAO: ");
						scanf("%d",&posicao);
						inserirPosicao(&lista,registro,posicao);
						break;
					}
				}
				break;
			}
			case 6:{
				printf("DIGITE A POSICAO PARA BUSCAR: ");
				scanf("%d",&posicao);
				alterarRegistro(&lista,posicao);
				break;
			}
			case 7:{
				printf("DIGITE A POSICAO PARA BUSCAR: ");
				scanf("%d",&posicao);
				excluirRegistro(&lista,posicao);
				break;
			}
			case 8:{
				salvarArquivo(&lista);
				break;
			}
			case 9:{
				carregarArquivo(&lista);
				break;
			}
			case 10:{
				reiniciliarLista(&lista);
    			break;
			}case 0:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(op!=0);
    return 0;
}

void criarLista(LISTA *lista){
    lista->nroElem = 0;
    system("cls");
    printf("A LISTA FOI CRIADA COM SUCESSO!\n");
    system("pause");
}

int tamanhoLista(LISTA *lista){
	LISTA aux = *lista;
	return aux.nroElem;
}

void imprimirLista(LISTA *lista){
	int i;
	system("cls");
	if(lista->nroElem==0)
		printf("A LISTA ESTA VAZIA!\n");
	else{
    	for(i=0; i<lista->nroElem;i++)
        	printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s\n",i,lista->vetor[i].chave,lista->vetor[i].matricula,lista->vetor[i].tipoOcorrencia);
	}
	system("pause");
}

void buscarRegistro(LISTA *lista, int posicao){
	int op;
	system("cls");
    if(posicao<lista->nroElem){
    	system("cls");
		printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s)\n",posicao,lista->vetor[posicao].chave,lista->vetor[posicao].matricula,lista->vetor[posicao].tipoOcorrencia);
    	printf("1 - EDITAR O ELEMENTO\n");
    	printf("2 - EXCLUIR O ELEMENTO\n");
    	printf("0 - SAIR\n");
    	printf("DIGITE UMA OPCAO: ");
    	scanf("%d",&op);
    	switch(op){
    		case 1:{
    			alterarRegistro(lista,posicao);
				break;
			}
			case 2:{
				excluirRegistro(lista,posicao);
				break;
			}
			case 0:{
				break;
			}
			default:{
				system("cls");
				printf("FALHA!");
				system("pause");
				break;
			}
		}
    }else
        printf("A OPCAO NAO ENCONTRADA!\n");
    system("pause");
}

void inserirFinal(LISTA *lista, REGISTRO registro){
	system("cls");
	if(lista->nroElem<MAX){
	   	lista->vetor[lista->nroElem] = registro;
    	lista->nroElem = lista->nroElem+1;
    	printf("CONCLUIDO!\n");
	}else{
		printf("FALHA!\n");
		printf("A LISTA ESTA CHEIA!\n");
	}
	system("pause");
}

void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao){
	int i;
	system("cls");
    if(posicao>=lista->nroElem)
       	inserirFinal(lista,registro);
    else{
    	if(lista->nroElem<MAX){
    		printf("CONCLUIDO!\n");
        	for(i=lista->nroElem;i>posicao;i--)
           	lista->vetor[i] = lista->vetor[i-1];
        	lista->vetor[posicao] = registro;
        	lista->nroElem++;
    	}else{
			printf("FALHA!\n");
			printf("A LISTA ESTA CHEIA!\n");
		}
			system("pause");
    }
}

void inserirInicio(LISTA *lista, REGISTRO registro){
    inserirPosicao(lista,registro,0);
}

void alterarRegistro(LISTA *lista, int posicao){
	REGISTRO registro;
	system("cls");
	printf("CHAVE: ");
    scanf("%d",&registro.chave);
	printf("MATRICULA: ");
    scanf("%d",&registro.matricula);
    printf("OCORRENCIA: ");
    fflush(stdin);
    fgets(registro.tipoOcorrencia,20,stdin);
    lista->vetor[posicao] = registro;
}

void excluirRegistro(LISTA *lista, int posicao){
	int i = 0;
	system("cls");
	if(posicao<lista->nroElem){
		printf("CONCLUIDO COM SUCESSO!\n");
		if(posicao==(lista->nroElem-1))
			lista->nroElem = lista->nroElem-1;
		else{
			for(i=posicao;i<lista->nroElem-1;i++)
				lista->vetor[i] = lista->vetor[i+1];
			lista->nroElem = lista->nroElem-1;
		}
	}else
		printf("A POSICA NAO EXISTE!\n");
	system("pause");
}

void salvarArquivo(LISTA *lista){
	int i, tamanho = tamanhoLista(lista);
	FILE *file;
	if(tamanho==0){
		system("cls");
		printf("A LISTA NAO POSSUI ELEMENTOS AINDA\n");
		system("pause");
	}else{
		file = fopen ("registrosLista.txt","w");
		if(file==NULL){
			printf("FALHA NA CRIACAO DO ARQUIVO.\n");
			system("pause");
		}else{
			for(i=0;i<tamanho;i++){
				fprintf(file,"%d %d %s",lista->vetor[i].chave,lista->vetor[i].matricula,lista->vetor[i].tipoOcorrencia);
			}
			system("cls");
			printf("CONCLUIDO! O ARQUIVO FOI SALVO\n");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(LISTA *lista){
	FILE *file;
	REGISTRO registro;
	file = fopen("registrosLista.txt","r");
	if(file==NULL){
		system("cls");
		printf("FALHA AO CARREGAR O ARQUIVO.\n");
		system("pause");
	}else{
		while(fscanf(file,"%d %d %[^\n]s",&registro.chave,&registro.matricula,registro.tipoOcorrencia)!=EOF){
			inserirFinal(lista,registro);
		}
		system("cls");
		printf("CONCLUIDO! O ARQUIVO FOI CARREGADO\n");
		system("pause");
	}
	fclose(file);
}

void reiniciliarLista(LISTA *lista){
    lista->nroElem = 0;
    system("cls");
    printf("CONCLUIDO! A ESTRUTURA FOI REINICIALIZADA\n");
    system("pause");
}
