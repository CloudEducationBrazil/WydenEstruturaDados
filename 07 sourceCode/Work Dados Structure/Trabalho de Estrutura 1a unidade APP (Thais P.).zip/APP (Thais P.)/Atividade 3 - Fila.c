#include <stdio.h>
#include <stdlib.h>

typedef int TIPOCHAVE;

typedef struct{
    TIPOCHAVE chave;
} REGISTRO;

typedef struct fila{
    REGISTRO registro;
    struct fila *prox;
} *FILA;

FILA* criarFila();

int tamanhoFila(FILA *fila);
void imprimirElementos(FILA *fila);
void buscarElemento(FILA *fila);
void inserirRegistro(FILA *fila, REGISTRO registro);
void alterarRegistro(FILA *fila);
void excluirRegistro(FILA *fila);
void salvarArquivo(FILA *fila);
void carregarArquivo(FILA *fila);
void reinicializarFila(FILA *fila);

int main(){
	FILA *fila;
	REGISTRO registro;
	int chave, indice, op;
	do{
		system("cls");
		printf("\n OLA USUARIO, BEM VINDO!\n");
		printf("\n VOCE ESTA NO MENU, O QUE VOCE DESEJA FAZER?\n\n");
		printf("1 - CRIAR\n");
 	  	printf("2 - IMPRIMIR O TAMANHO\n");
 	  	printf("3 - IMPRIMIR OS ELEMENTOS\n");
	  	printf("4 - BUSCAR O ELEMENTO\n");
 	  	printf("5 - INSERIR O ELEMENTO\n");
	   	printf("6 - ALTERAR ELEMENTO\n");
	   	printf("7 - EXCLUIR ELEMENTO\n");
	   	printf("8 - SALVAR FILA EM ARQUIVO\n");
 	  	printf("9 - CARREGAR ARQUIVO\n");
 	  	printf("10 - REINICIALIZAR\n");
 	  	printf("0 - ENCERRAR O PROGRAMA\n");
	   	printf("DIGITE AQUI UMA OPCAO: ");
	   	scanf("%d",&op);
	   	switch(op){
    	    case 1:{
    	    	fila = criarFila();
    	    	system("cls");
    	    	printf("A FILA FOI CRIADA COM SUCESSO!\n");
    	    	system("pause");
				break;
			}case 2:{
				system("cls");
   	        	printf(" A QUANTIDADE DE ELEMENTOS: %d\n",tamanhoFila(fila));
   	        	system("pause");
    	        break;
    	    }
    	    case 3:{
    	    	imprimirElementos(fila);
				break;
			}
			case 4:{
    	    	buscarElemento(fila);
				break;
			}
			case 5:{
				system("cls");
				printf("DIGITE A CHAVE: ");
    	    	scanf("%d",&registro.chave);
				inserirRegistro(fila,registro);
				system("cls");
				printf("O REGISTRO FOI INSERIDO COM SUCESSO!\n");
				system("pause");
				break;
			}
			case 6:{
				alterarRegistro(fila);
				break;
			}
			case 7:{
				excluirRegistro(fila);
				break;
			}
			case 8:{
				salvarArquivo(fila);
				break;
			}
			case 9:{
				carregarArquivo(fila);
				break;
			}
			case 10:{
    			reinicializarFila(fila);
    			system("cls");
				printf(" A FILA FOI REINICIALIZADA COM SUCESSO!\n");
				system("pause");
    			break;
			}case 0:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("FALHA!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(op!=0);
	return 0;
}

FILA* criarFila(){
	FILA *fila = (FILA*)malloc(sizeof(FILA));
	if(fila!=NULL)
        *fila = NULL;
    return fila;
}

int tamanhoFila(FILA *fila){
	FILA aux = *fila;
	int tamanho = 0;
	if(*fila==NULL)
		return 0;
	else{
		while(aux!=NULL){
			aux = aux->prox;
			tamanho++;
		}
		return tamanho;
	}
}

void imprimirElementos(FILA *fila){
	FILA aux = *fila;
	int cont = 0;
	system("cls");
	if(*fila==NULL)
		printf("A FILA AINDA NAO POSSUI ELEMENTOS!\n");
	else{
		while(aux!=NULL){
			printf("INDICE: %d - CHAVE: %d\n",cont,aux->registro.chave);
			aux = aux->prox;
			cont++;
		}
	}
	system("pause");
}

void buscarElemento(FILA *fila){
	FILA aux = *fila;
	int op, cont = 0;
	if(*fila==NULL){
		system("cls");
		printf(" A FILA AINDA NAO POSSUI ELEMENTOS!\n");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
			cont++;
		}
		system("cls");
		printf("INDICE: %d - CHAVE: %d\n",cont,aux->registro.chave);
    	printf("1 - EDITAR UM ELEMENTO\n");
    	printf("2 - EXCLUIR UM ELEMENTO\n");
    	printf("0 - SAIR\n");
    	printf("DIGITE AQUI UMA OPCAO: ");
    	scanf("%d",&op);
    	switch(op){
    		case 1:{
    			alterarRegistro(fila);
				break;
			}
			case 2:{
				excluirRegistro(fila);
				break;
			}
			case 0:{
				break;
			}
			default:{
				system("cls");
				printf("FALHA!\n");
				system("pause");
				break;
			}
		}
	}
}

void inserirRegistro(FILA *fila, REGISTRO registro){
	FILA novo;
	novo = (FILA)malloc(sizeof(struct fila));
	novo->registro = registro;
	novo->prox = *fila;
	*fila = novo;
}

void alterarRegistro(FILA *fila){
	FILA aux = *fila;
	REGISTRO registro;
	if(*fila==NULL){
		system("cls");
		printf("A FILA AINDA NAO POSSUI ELEMENTOS!S\n");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
		}
		system("cls");
		printf("DIGITE A CHAVE: ");
		scanf("%d",&registro.chave);
		aux->registro = registro;
		system("cls");
		printf("O REGISTRO FOI ALTERADO COM SUCESSO!\n");
		system("pause");
	}
}

void excluirRegistro(FILA *fila){
	FILA ant, aux = *fila;
	if(*fila==NULL){
		system("cls");
		printf("A FILA AINDA NAO POSSUI ELEMENTOS!\n");
		system("pause");
	}else{
		if(aux->prox==NULL){
			*fila = aux->prox;
			free(aux);
		}else{
			while(aux->prox!=NULL){
				ant = aux;
				aux = aux->prox;
			}
			ant->prox = NULL;
			free(aux);
		}
		system("cls");
		printf("O REGISTRO FOI EXCLUIDO COM SUCESSO!\n");
		system("pause");
	}
}

void salvarArquivo(FILA *fila){
	FILE *file;
	FILA aux;
	if(*fila==NULL){
		system("cls");
		printf("A FILA AINDA NAO POSSUI ELEMENTOS!\n");
		system("pause");
	}else{
		file = fopen ("registrosFila.txt","w");
		if(file==NULL){
			printf("FALHA AO CRIAR ARQUIVO...\n");
			system("pause");
		}else{
			aux = *fila;
			while(aux!=NULL){
				fprintf(file,"CHAVE: %d\n",aux->registro.chave);
				aux = aux->prox;
			}
			system("cls");
			printf("O ARQUIVO FOI SALVO COM SUCESSO!\n");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(FILA *fila){
	FILE *file;
	REGISTRO registro;
	file = fopen("registrosFila.txt","r");
	if(file==NULL){
		system("cls");
		printf("FALHA!\n");
		system("pause");
	}else{
		while(fscanf(file,"%d",&registro.chave)!=EOF){
			inserirRegistro(fila,registro);
		}
		system("cls");
		printf("O ARQUIVO FOI CARREGADO COM SUCESSO!\n");
		system("pause");
	}
	fclose(file);
}

void reinicializarFila(FILA *fila){
	FILA aux;
	while(*fila!=NULL){
		aux = *fila;
		*fila = aux->prox;
		free(aux);
	}
}
