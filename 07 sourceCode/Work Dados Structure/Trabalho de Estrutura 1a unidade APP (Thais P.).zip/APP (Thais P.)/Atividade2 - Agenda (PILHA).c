#include <stdio.h>
#include <stdlib.h>

typedef int TIPOCHAVE;

typedef struct{
	int dia;
	int mes;
	int ano;
} dataRef;

typedef struct {
	TIPOCHAVE chave; // Controle ID
	dataRef dataCompromisso; // Data Compromisso
    char descricaoCompromisso[300]; // Descri��o
} REGISTRO;

typedef struct pilha{
    REGISTRO registro;
    struct pilha *prox;
} *PILHA;

PILHA* criarPilha();

int tamanhoPilha(PILHA *pilha);
void imprimirElementos(PILHA *pilha);
void buscarElemento(PILHA *pilha);
void inserirRegistro(PILHA *pilha, REGISTRO registro);
void alterarRegistro(PILHA *pilha);
void excluirRegistro(PILHA *pilha);
void salvarArquivo(PILHA *pilha);
void carregarArquivo(PILHA *pilha);
void reinicializarPilha(PILHA *pilha);

int main(){
	PILHA *pilha;
	REGISTRO registro;
	int chave, indice, op;

	do{
		system("cls");
		printf("\n OLA USUARIO, BEM VINDO!\n");
		printf("\n VOCE ESTA NO MENU, O QUE VOCE DESEJA FAZER?\n\n");
		printf("1 - CRIAR\n");
 	  	printf("2 - IMPRIMIR O TAMANHO\n");
 	  	printf("3 - IMPRIMIR OS ELEMENTOS\n");
	  	printf("4 - BUSCAR O ELEMENTO\n");
 	  	printf("5 - INSERIR O ELEMENTO\n");
	   	printf("6 - ALTERAR ELEMENTO\n");
	   	printf("7 - EXCLUIR ELEMENTO\n");
	   	printf("8 - SALVAR EM ARQUIVO\n");
 	  	printf("9 - CARREGAR ARQUIVO\n");
 	  	printf("10 - REINICIALIZAR\n");
 	  	printf("0 - ENCERRAR O PROGRAMA\n");
	   	printf("\n DIGITE AQUI UMA OPCAO: ");
	   	scanf("%d",&op);
	   	switch(op){
    	    case 1:{
    	    	pilha = criarPilha();
    	    	system("cls");
    	    	printf("A PILHA FOI CRIADA COM SUCESSO!\n");
    	    	system("pause");
				break;
			}case 2:{
				system("cls");
   	        	printf(" A QUANTIDADE DE ELEMENTOS: %d\n",tamanhoPilha(pilha));
   	        	system("pause");
    	        break;
    	    }
    	    case 3:{
    	    	imprimirElementos(pilha);
				break;
			}
			case 4:{
    	    	buscarElemento(pilha);
				break;
			}
			case 5:{
				system("cls");
				printf("DIGITE A CHAVE: ");
    	    	scanf("%d",&registro.chave);
    	    	printf("\nINSIRA A DATA...\n");
				printf("DIA: ");
    	    	scanf("%d",&registro.dataCompromisso.dia);
    	    	printf("MES: ");
    	    	scanf("%d",&registro.dataCompromisso.mes);
    	    	printf("ANO: ");
    	    	scanf("%d",&registro.dataCompromisso.ano);
    	    	printf("\nINSIRA UM COMPROMISSO...\n");
    	    	printf("COMPROMISSO: ");
    	    	fflush(stdin);
    	    	fgets(registro.descricaoCompromisso,300,stdin);
				inserirRegistro(pilha,registro);
				system("cls");
				printf("COMPROMISSO SALVO!\n");
				system("pause");
				break;
			}
			case 6:{
				alterarRegistro(pilha);
				break;
			}
			case 7:{
				excluirRegistro(pilha);
				break;
			}
			case 8:{
				salvarArquivo(pilha);
				break;
			}
			case 9:{
				carregarArquivo(pilha);
				break;
			}
			case 10:{
    			reinicializarPilha(pilha);
    			system("cls");
				printf("CONCLUIDO! A PILHA FOI REINICIALIZADA\n");
				system("pause");
    			break;
			}case 0:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("FALHA!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}
	while(op!=0);
	return 0;
}

PILHA* criarPilha(){
	PILHA *pilha = (PILHA*)malloc(sizeof(PILHA));
	if(pilha!=NULL)
        *pilha = NULL;
    return pilha;
}

int tamanhoPilha(PILHA *pilha){
	PILHA aux = *pilha;
	int tamanho = 0;
	if(*pilha==NULL)
		return 0;
	else{
		while(aux!=NULL){
			aux = aux->prox;
			tamanho++;
		}
		return tamanho;
	}
}

void imprimirElementos(PILHA *pilha){
	PILHA aux = *pilha;
	int cont = 0;
	system("cls");
	if(*pilha==NULL)
		printf("A PILHA AINDA NAO POSSUI ELEMENTOS!\n");
	else{
		while(aux!=NULL){
			printf("INDICE: %d - CHAVE: - %d - DATA: %d-%d-%d - DESCRICAO: %s\n",cont,aux->registro.chave,aux->registro.dataCompromisso.dia,aux->registro.dataCompromisso.mes,aux->registro.dataCompromisso.ano,aux->registro.descricaoCompromisso);
			aux = aux->prox;
			cont++;
		}
	}
	system("pause");
}

void buscarElemento(PILHA *pilha){
	PILHA aux = *pilha;
	int op;
	if(*pilha==NULL){
		system("cls");
		printf("A PILHA AINDA NAO POSSUI ELEMENTOS\n");
		system("pause");
	}else{
		system("cls");
		printf("INDICE: %d - CHAVE: %d\n",0,aux->registro.chave);
    	printf("1 - EDITAR UM ELEMENTO\n");
    	printf("2 - EXCLUIR UM ELEMENTO\n");
    	printf("0 - SAIR\n");
    	printf("DIGITE AQUI UMA OPCAO: ");
    	scanf("%d",&op);
    	switch(op){
    		case 1:{
    			alterarRegistro(pilha);
				break;
			}
			case 2:{
				excluirRegistro(pilha);
				break;
			}
			case 0:{
				break;
			}
			default:{
				system("cls");
				printf("FALAH!\n");
				system("pause");
				break;
			}
		}
	}
}

void inserirRegistro(PILHA *pilha, REGISTRO registro){
	PILHA novo;
	novo = (PILHA)malloc(sizeof(struct pilha));
	novo->registro = registro;
	novo->prox = *pilha;
	*pilha = novo;
}

void alterarRegistro(PILHA *pilha){
	PILHA aux;
	REGISTRO registro;
	if(*pilha==NULL){
		system("cls");
		printf("A PILHA AINDA NAO POSSUI ELEMENTOS!\n");
		system("pause");
	}else{
		aux = *pilha;
		system("cls");
		printf("DIGITE A CHAVE: ");
      	scanf("%d",&registro.chave);
		printf("DIA: ");
       	scanf("%d",&registro.dataCompromisso.dia);
		printf("MES: ");
    	scanf("%d",&registro.dataCompromisso.mes);
    	printf("ANO: ");
    	scanf("%d",&registro.dataCompromisso.ano);
    	printf("COMPROMISSO: ");
    	fflush(stdin);
    	fgets(registro.descricaoCompromisso,300,stdin);
		aux->registro = registro;
		system("cls");
		printf("O REGISTRO FOI ALTERADO COM SUCESSO!\n");
		system("pause");
	}
}

void excluirRegistro(PILHA *pilha){
	PILHA aux = *pilha;
	if(*pilha==NULL){
		system("cls");
		printf("A PILHA AINDA NAO POSSUI ELEMENTOS...\n");
		system("pause");
	}else{
		*pilha = aux->prox;
		free(aux);
		system("cls");
		printf(" O REGISTRO FOI EXCLUIDO COM SUCESSO!\n");
		system("pause");
	}
}

void salvarArquivo(PILHA *pilha){
	FILE *file;
	PILHA aux;
	if(*pilha==NULL){
		system("cls");
		printf("A PILHA AINDA NAO POSSUI ELEMENTOS...\n");
		system("pause");
	}else{
		file = fopen ("registrosPilha.txt","w");
		if(file==NULL){
			printf("FALHA AO CRIAR ARQUIVO...\n");
			system("pause");
		}else{
			aux = *pilha;
			while(aux!=NULL){
				fprintf(file,"CHAVE: %d - DATA: %d-%d-%d - COMPROMISSO: %s\n",aux->registro.chave,aux->registro.dataCompromisso.dia,aux->registro.dataCompromisso.mes,aux->registro.dataCompromisso.ano,aux->registro.descricaoCompromisso);
				aux = aux->prox;
			}
			system("cls");
			printf("O ARQUIVO FOI SALVO COM SUCESSO!\n");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(PILHA *pilha){
	FILE *file;
	REGISTRO registro;
	file = fopen("registrosPilha.txt","r");
	if(file==NULL){
		system("cls");
		printf("FALHA AO CARREGAR ARQUIVO...\n");
		system("pause");
	}else{
		while(fscanf(file,"%d %d %d %d %[^\n]s",&registro.chave,&registro.dataCompromisso.dia,&registro.dataCompromisso.mes,&registro.dataCompromisso.ano,registro.descricaoCompromisso)!=EOF){
			inserirRegistro(pilha,registro);
		}
		system("cls");
		printf("O ARQUIVO FOI CARREGADO COM SUCESSO!\n");
		system("pause");
	}
	fclose(file);
}

void reinicializarPilha(PILHA *pilha){
	PILHA aux;
	while(*pilha!=NULL){
		aux = *pilha;
		*pilha = aux->prox;
		free(aux);
	}
}
