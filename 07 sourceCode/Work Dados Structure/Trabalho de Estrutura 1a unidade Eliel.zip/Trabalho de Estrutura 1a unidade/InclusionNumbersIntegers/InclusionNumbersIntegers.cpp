#include<stdio.h>
#include<stdlib.h>
//inicializar - incluir - excluir - imprimir - buscar elemento - numero de elementos - reinicializar

typedef struct no{
	int num;
	struct no *prox;
	
}tipoNo;

int quant(tipoNo *Apontador){
	tipoNo *aux = Apontador;
	int n=0;
	while(aux!=NULL){
		aux = aux->prox;
		n++;
	}
	return n;
}

void inicializar(tipoNo **Apontador){
	
	tipoNo *inicializar = (tipoNo*)malloc(sizeof(tipoNo));
	
	printf("Informe a primeira matricula:\n");
	scanf("%d", &inicializar->num);
	
	inicializar->prox = *Apontador;
	*Apontador=inicializar;
	
	printf("Lista de matriculas inicializada\n");
	system("pause");
	system("clear||cls");
}

void inserirInicio(tipoNo **Apontador){
	tipoNo *novaMatricula = (tipoNo*)malloc(sizeof(tipoNo));
	printf("Informe nova matricula:\n");
	scanf("%d", &novaMatricula->num);
	novaMatricula->prox = *Apontador;
	*Apontador = novaMatricula;
}

void inserirFim(tipoNo **Apontador){
	int n=0, i;
	tipoNo *novaMatricula = (tipoNo*)malloc(sizeof(tipoNo));
	printf("Informe nova matricula:\n");
	scanf("%d", &novaMatricula->num);
	tipoNo *aux;
	aux = (*Apontador);
	while(aux->prox!=NULL){
		aux=aux->prox;
		n++;
	}
	aux->prox = novaMatricula;
	novaMatricula->prox = NULL;
}

void inserirOutro(tipoNo **Apontador){
	int i=0, indice;
	
	tipoNo *aux;
	tipoNo *aux1;
	aux=*Apontador;
	aux1=*Apontador;
	
	printf("Informe em qual indice deseja por a nova matricula:\n");
	while(aux!=NULL){
		printf("Indice %d Matricula %d\n", i, aux->num);
		aux = aux->prox;
		i++;
	}
	scanf("%d", &indice);
	
	aux=*Apontador;
	
	if(indice == 0){
		inserirInicio(Apontador);
	}	
	else{		
		tipoNo *novaMatricula = (tipoNo*)malloc(sizeof(tipoNo));
		printf("Informe nova matricula:\n");
		scanf("%d", &novaMatricula->num);
		
		aux=*Apontador;
		for(i=0;i<indice-1;i++){
			aux = aux->prox;
		}
		for(i=0;i<indice;i++){
			aux1 = aux1->prox;
		}
		aux->prox = novaMatricula;
		novaMatricula->prox = aux1;
	}
	system("pause");
}

void inserir(tipoNo **Apontador){
	int opc;
	
	printf("Informe qual opcao deseja:\n");
	printf("1 - Inserir matricula no inicio da lista\n");
	printf("2 - Inserir matricula no fim da lista\n");
	printf("3 - Inserir matricula em outro lugar da lista\n");
	scanf("%d", &opc);
	
	switch(opc){
		case 1:
			inserirInicio(Apontador);
			break;
			
		case 2:
			inserirFim(Apontador);
			break;
			
		case 3:
			inserirOutro(Apontador);
			break;
	}
}

void excluir(tipoNo **Apontador){
	int i=0, indice;
	tipoNo *aux;
	tipoNo *aux1;
	aux= *Apontador;
	aux1= *Apontador;
	
	printf("Informe qual indice deseja excluir:\n");
	while(aux!=NULL){
		printf("Indice %d Matricula %d\n", i, aux->num);
		aux = aux->prox;
		i++;
	}
	scanf("%d", &indice);
	
	aux = *Apontador;
	
	if(indice==i){
		for(i=0; i<indice-1; i++){
			aux=aux->prox;
		}
		aux->prox=NULL;
	}
	
	else if(indice==0){
		for(i=0; i<indice+1; i++){
			aux=aux->prox;
		}
		*Apontador = aux;
	}
	
	else{
		aux=*Apontador;
		for(i=0;i<indice-1;i++){
			aux = aux->prox;
		}
		for(i=0;i<indice+1;i++){
			aux1 = aux1->prox;
		}
		aux->prox = aux1;
		
		aux=*Apontador;
		printf("Nova lista:\n");
		while(aux!=NULL){
			printf("%d\n", aux->num);
			aux=aux->prox;
		}
}
	system("pause");
}

void busca(tipoNo *Lista){
	int matricula, i, n=0;
	printf("Informe a matricula que deseja buscar na lista:\n");
	scanf("%d", &matricula);
	tipoNo *aux;
	aux = Lista;
	
	while(aux!=NULL){
		aux = aux->prox;
		n++;
	}
	aux = Lista;
	for(i=0; i<n; i++){
		if(matricula == aux->num){
			printf("A matricula estah no indice: %d\n", i);
			i=n+1;
		}
		aux = aux->prox;
	}
	if(i == n){
		printf("Matricula nao encontrada, tente novamente\n");
	}
	system("pause");
}

void exibirQtd(tipoNo *Lista){
	tipoNo *aux;
	aux = Lista;
	int n=0;
	
	while(aux!=NULL){
		aux = aux->prox;
		n++;
	}
	printf("Quantidade de matriculados: %d\n", n);
	system("pause");
}

void imprimirLista(tipoNo *Lista){
	tipoNo *aux = Lista;
	int i=0;
	printf("Lista de Matriculas:\n\n");
	while(aux!=NULL){
		printf("Matricula %d: %d\n\n", i, aux->num);
		i++;
		aux=aux->prox;
	}
	system("pause");
}

void alterar(tipoNo *Apontador){
	int opc, i=0;
	tipoNo *aux = Apontador;
	printf("\nInforme a matricula que deseja alterar:\n\n");
	imprimirLista(Apontador);
	scanf("%d", &opc);
	
	for(i=0; i<opc; i++){
		aux = aux->prox;
	}
	
	printf("Informe nova matricula: \n");
	scanf("%d", &aux->num);
	
	printf("\nLista atualizada:\n");
	imprimirLista(Apontador);
}

void reiniciar(tipoNo **Apontador){
	tipoNo *ant;
	while((*Apontador)!=NULL){
		ant = *Apontador;
		*Apontador = (*Apontador)->prox;
		free(ant);
	}	
}

void arquivar(tipoNo *Apontador){
	FILE *save;
	tipoNo *aux = Apontador;
	int n, i;
	
	save = fopen("Lista.txt", "w");
	
	if (save == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
		exit(0);
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");
		n=quant(Apontador);
		for(i=0; i<n; i++){
			fprintf(save, "%d\n", aux->num);
			aux = aux->prox;
		}
	}	
	fclose(save);
}

void carregar(tipoNo **Apontador){
	FILE *load;
	tipoNo *aux;
	load = fopen("Lista.txt", "r");
	int x;
	
	if (load == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");		
		while(fscanf(load,"%d", &x) != EOF){
			tipoNo *novo = (tipoNo*)malloc(sizeof(tipoNo));
			novo->num = x;
			aux = *Apontador;
			if( (*Apontador) == NULL){
				novo->prox = NULL;
				*Apontador = novo;
			}
			else{
				while( aux->prox != NULL){
					aux = aux->prox;
				}
				novo->prox = NULL;
				aux->prox = novo;
			}
		} 
	}
	fclose(load);
}

int main(){
	
	int opc, x=1, y=0;
	tipoNo *Lista=NULL;
	while(x==1){
		system("cls||clear");		
		printf("Informe qual opcao deseja:\n");	
		if(y==0){
		printf("0 - Inicializar inclusao de Matricula\n");
		y++;
		}
		printf("1 - Inserir novo Matricula\n2 - Excluir Matricula\n3 - Imprimir Lista\n");
		printf("4 - Buscar Matricula\n5 - Exibir a quantidade de Matriculados\n");
		printf("6 - Reinicializar Lista\n7 - Alterar uma Matricula ou Ocorrencia\n");
		printf("8 - Arquivar Lista\n9 - Carregar Lista\n10 - Sair\n\n");
		scanf("%d", &opc);
		if(Lista == NULL){
			if(opc == 9 || opc == 10){
				printf("");
			}
			else if(opc != 0){
				printf("Opcao Invalida, INICIALIZE A LISTA PRIMEIRO!\n");
				opc = 0;
			}			
		}
		switch(opc){
			case 0:
				inicializar(&Lista);
				break;
				
			case 1:
				inserir(&Lista);				
				break;
		
			case 2:
				excluir(&Lista);
				if(Lista == NULL){
					y=0;
				}
				break;
		
			case 3:
				imprimirLista(Lista);
				break;
		
			case 4:
				busca(Lista);
				break;
		
			case 5:
				exibirQtd(Lista);
				break;
			
			case 6:
				reiniciar(&Lista);
				y=0;
				break; 
			
			case 7:
				alterar(Lista);
				break;
							
			case 8:	
				arquivar(Lista);
				break;
				
			case 9:	
				carregar(&Lista);
				break;
			
			case 10:	
				x=2;
				break;
		}	
	}
	system("cls||clear");
	printf("Tchau");
	
	return 0;
}
