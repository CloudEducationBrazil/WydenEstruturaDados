#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct data{
	int dia;
	int mes;
	int ano;	
} strData;

typedef struct agenda{
	strData compromisso;
	struct agenda *prox;
	char info[200];
} strAgenda;

int la_quant(strAgenda *Apontador){
	
	int n=0;
	while(Apontador!=NULL){
		Apontador = Apontador->prox;
		n++;
	}
	return n;
}

void lb_ordenacao(strAgenda *Apontador){
	int i, n, j, k=1, a, b;
	n = la_quant(Apontador);
	strAgenda *seguin = Apontador;
	strAgenda *ant = Apontador;
	strAgenda *aux = (strAgenda*)malloc(sizeof(strAgenda));
	
	for(i=0; i<(n-1) ; i++){
		a = ((ant->compromisso.ano)*365) + ((ant->compromisso.mes)*30) + (ant->compromisso.dia);
		for(j=k; j<n; j++){
			seguin = seguin->prox;
			b = ((seguin->compromisso.ano)*365) + ((seguin->compromisso.mes)*30) + (seguin->compromisso.dia);
			if(a>b){
				aux->compromisso.ano = ant->compromisso.ano;
				aux->compromisso.mes = ant->compromisso.mes;
				aux->compromisso.dia = ant->compromisso.dia;
				strncpy(aux->info, ant->info, 200);
				aux->info[200] = '\0';
				
				ant->compromisso.ano = seguin->compromisso.ano;
				ant->compromisso.mes = seguin->compromisso.mes;
				ant->compromisso.dia = seguin->compromisso.dia;
				strncpy(ant->info, seguin->info, 200);
				ant->info[200] = '\0';
					
				seguin->compromisso.ano = aux->compromisso.ano;
				seguin->compromisso.mes = aux->compromisso.mes;
				seguin->compromisso.dia = aux->compromisso.dia;
				strncpy(seguin->info, aux->info, 200);
				seguin->info[200] = '\0';
			}
		}
		ant = ant->prox;
		seguin = ant;
		k++;
	}
}

void b_start(strAgenda **Apontador){
	
	strAgenda *inicializar = (strAgenda*)malloc(sizeof(strAgenda));
	
	printf("Informe data do compromisso:\n");
	printf("Dia: ");
	scanf("%d", &inicializar->compromisso.dia);
	printf("Mes: ");
	scanf("%d", &inicializar->compromisso.mes);
	printf("Ano: ");
	scanf("%d", &inicializar->compromisso.ano);
	
	printf("Informe a descricao do compromisso:\n");
	fflush(stdin);
	fgets(inicializar->info,200,stdin);
	
	inicializar->prox = NULL;
	*Apontador=inicializar;
	
	printf("Agenda inicializada\n");
	system("pause");
	system("clear||cls");
} 

void c_inserir(strAgenda *Apontador){
	strAgenda *aux = Apontador;
	strAgenda *novoCompromisso = (strAgenda*)malloc(sizeof(strAgenda));
	
	printf("Informe data do compromisso:\n");
	printf("Dia: ");
	scanf("%d", &novoCompromisso->compromisso.dia);
	printf("Mes: ");
	scanf("%d", &novoCompromisso->compromisso.mes);
	printf("Ano: ");
	scanf("%d", &novoCompromisso->compromisso.ano);
	
	printf("Informe a descricao do compromisso:\n");
	fflush(stdin);
	fgets(novoCompromisso->info,200,stdin);
	
	while(aux->prox!=NULL){
		aux=aux->prox;
	}
	
	novoCompromisso->prox = NULL;
	aux->prox = novoCompromisso;
	
	lb_ordenacao(Apontador);
}

void e_printList(strAgenda *Apontador){
	int i=0;
	
	printf("Lista de compromissos:\n\n");
	while(Apontador!=NULL){
		printf("Compromisso %d: Data:%d/%d/%d\nDescricao: %s\n", i, Apontador->compromisso.dia, Apontador->compromisso.mes, Apontador->compromisso.ano, Apontador->info);
		Apontador=Apontador->prox;
		i++;
	}
	system("pause");
	lb_ordenacao(Apontador);
}

void g_exibQtd(strAgenda *Apontador){
	int n=0;
	n = la_quant(Apontador);
	printf("Quantidade de compromissos: %d\n", n);
	system("pause"); 
}

void f_busca(strAgenda *Apontador){
	int dia, mes, ano, i, n=0, k=0;
	printf("Informe a data do compromisso que deseja buscar na lista:\n");
	printf("Dia: ");
	scanf("%d", &dia);
	printf("Mes: ");
	scanf("%d", &mes);
	printf("Ano: ");
	scanf("%d", &ano);
	
	n = la_quant(Apontador);
	
	for(i=0; i<n; i++){
		if(dia == Apontador->compromisso.dia && mes == Apontador->compromisso.mes && ano == Apontador->compromisso.ano){
			printf("Compromisso: %s\n", Apontador->info);
			k++;
		}
		Apontador = Apontador->prox;
	}
	if(k==0){
		printf("Compromisso inexistente\n");		
	}
	system("pause");
}

void h_alterarComp(strAgenda *Apontador){
	int opc, i=0;
	
	printf("\nInforme o compromisso que deseja alterar:\n\n");
	e_printList(Apontador);
	scanf("%d", &opc);
	
	for(i=0; i<opc; i++){
		Apontador = Apontador->prox;
	}
	
	printf("O que deseja alterar:\n1 Data\n2 Descricao do compromisso\n3 Data e Descricao do compromisso\n");
	scanf("%d", &opc);
	
	if(opc==1){
		printf("Informe a nova data:\n");
		printf("Dia: ");
		scanf("%d", &Apontador->compromisso.dia);
		printf("Mes: ");
		scanf("%d", &Apontador->compromisso.mes);
		printf("Ano: ");
		scanf("%d", &Apontador->compromisso.ano);
	}
	else if(opc==2){
		printf("Informe a nova descricao do compromisso:\n");
		fflush(stdin);
		fgets(Apontador->info,200,stdin);
	}
	else{
		printf("Informe a nova data:\n");
		printf("Dia: ");
		scanf("%d", &Apontador->compromisso.dia);
		printf("Mes: ");
		scanf("%d", &Apontador->compromisso.mes);
		printf("Ano: ");
		scanf("%d", &Apontador->compromisso.ano);
		
		printf("\n\nInforme a nova descricao do compromisso:\n");
		fflush(stdin);
		fgets(Apontador->info,200,stdin);
	}
	lb_ordenacao(Apontador);
}

void d_excluir(strAgenda **Apontador){
	int i=0, indice;
	strAgenda *ant;
	strAgenda *aux;
	strAgenda *aux1;
	aux= *Apontador;
	aux1= *Apontador;
	
	printf("Informe qual indice deseja excluir:\n\n");
	i = la_quant(*Apontador);
	e_printList(*Apontador);
	scanf("%d", &indice);
	
	
	if(indice==i){
		while(aux->prox != NULL){
			ant = aux;
			aux = aux->prox;
		}
		ant->prox = NULL;
		free(aux);
	}
	
	else if(indice==0){
		ant = aux;
		aux=aux->prox;
		free(ant);
		*Apontador = aux;
	}
	
	else{
		aux=*Apontador;
		for(i=0;i<indice;i++){
			ant = aux;
			aux = aux->prox;
			aux1 = aux1->prox;
		}
		aux1 = aux1->prox;
		free(aux);
		ant->prox = aux1;
		printf("\n\nNova Agenda:\n\n");
		e_printList(*Apontador);		
	}
	if(*Apontador != NULL){
		lb_ordenacao(*Apontador);
	}
}

void i_arquivar(strAgenda *Apontador){
	FILE *save;
	
	int n, i;
	
	save = fopen("Agenda.txt", "w");
	
	if (save == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
		exit(0);
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");
		n=la_quant(Apontador);
		for(i=0; i<n; i++){
			fprintf(save, "%d %d %d %s", Apontador->compromisso.dia, Apontador->compromisso.mes, Apontador->compromisso.ano, Apontador->info);
			Apontador = Apontador->prox;
		}
	}	
	fclose(save);		
}

void j_carregar(strAgenda **Apontador){
	FILE *load;
	strAgenda *aux;
	load = fopen("Agenda.txt", "r");
	char v[200];
	int d, m, a;
	if (load == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");		
		while(fscanf(load,"%d %d %d %[^\n]s", &d, &m, &a, v) != EOF){		
			strAgenda *novo = (strAgenda*)malloc(sizeof(strAgenda));
			novo->compromisso.dia = d;
			novo->compromisso.mes = m;
			novo->compromisso.ano = a;
			strcpy(novo->info, v);	
			aux = *Apontador;
			if( (*Apontador) == NULL){
				novo->prox = NULL;
				*Apontador = novo;
			}
			else{
				while( aux->prox != NULL){
					aux = aux->prox;
				}
				novo->prox = NULL;
				aux->prox = novo;
			}
		}
	}
	fclose(load);
}

void reiniciar(strAgenda **Apontador){
	strAgenda *ant;
	while((*Apontador)!=NULL){
		ant = *Apontador;
		*Apontador = (*Apontador)->prox;
		free(ant);
	}	
}

int main(int argc, char *argv[]) {
	
	int opc, x=1, y=0;
	strAgenda *Lista=NULL;
	while(x==1){
		system("cls||clear");		
		printf("Informe qual opcao deseja:\n");	
		if(y==0){
		printf("0 - Inicializar Agenda\n");
		y++;
		}
		printf("1 - Inserir novo Compromisso\n2 - Excluir um Compromisso\n3 - Imprimir Compromissos\n4 - Buscar compromisso\n5 - Exibir a quantidade de Compromissos\n");
		printf("6 - Reinicializar Agenda\n7 - Alterar um Compromisso\n8 - Arquivar agenda\n9 - Carregar\n10 - Sair\n\n");
		scanf("%d", &opc);
		if(Lista == NULL){
			if(opc == 9 || opc == 10){
				printf("");
			}
			else if(opc != 0){
				printf("Opcao Invalida, INICIALIZE AGENDA PRIMEIRO!\n");
				opc = 0;
			}			
		}
		switch(opc){
			case 0:
				b_start(&Lista);
				break;
			case 1:
				c_inserir(Lista);				
				break;
		
			case 2:
				d_excluir(&Lista);
				if(Lista == NULL){
					y=0;
				}
				break;
		
			case 3:
				e_printList(Lista);
				break;
		
			case 4:
				f_busca(Lista);
				break;
		
			case 5:
				g_exibQtd(Lista);
				break;
			
			case 6:
				reiniciar(&Lista);
				y=0;
				break; 
			
			case 7:
				h_alterarComp(Lista);
				break;
							
			case 8:	
				i_arquivar(Lista);
				break;
				
			case 9:	
				j_carregar(&Lista);
				break;
			
			case 10:	
				x=2;
				break;
		}		
	}
	system("cls||clear");
	printf("Tchau");
	return 0;
}
