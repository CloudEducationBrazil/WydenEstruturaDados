#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct r{
	int matricula;
	char tipoOcorrencia[10];
	struct r *prox;
}Registro;

int quant(Registro *Apontador){
	Registro *aux = Apontador;
	int n=0;
	while(aux!=NULL){
		aux = aux->prox;
		n++;
	}
	return n;
}

void inicializar(Registro **Apontador){
	
	Registro *inicializar = (Registro*)malloc(sizeof(Registro));
	
	printf("Informe a matricula:\n");
	scanf("%d", &inicializar->matricula);
	printf("Informe a ocorrencia:\n");
	fflush(stdin);
	fgets(inicializar->tipoOcorrencia,10,stdin);
	
	inicializar->prox = *Apontador;
	*Apontador=inicializar;
	
	printf("Lista de matricula inicializada\n"); //MUDE ISSO POR FAVOR
	system("pause");
	system("clear||cls");
}

void inserir(Registro *Apontador){
	int n=0, i;
	Registro *novaMatricula = (Registro*)malloc(sizeof(Registro));
	printf("Informe a matricula:\n");
	scanf("%d", &novaMatricula->matricula);
	printf("Informe a ocorrencia:\n");
	fflush(stdin);
	fgets(novaMatricula->tipoOcorrencia,10,stdin);
	
	Registro *aux = Apontador;
	while(aux->prox!=NULL){
		aux=aux->prox;
		n++;
	}
	aux->prox = novaMatricula;
	novaMatricula->prox = NULL;
}

void excluir(Registro **Apontador){
	int i;
	Registro *aux;
	Registro *ant;
	aux= *Apontador;
	
	for(i=0; i<1; i++){
		ant = aux;
		aux=aux->prox;
	}
	*Apontador = aux;
	free(ant);

	printf("Nova lista:\n");
	while(aux!=NULL){
		printf("Matricula: %d\n", aux->matricula);
		printf("Ocorrencia: %s\n", aux->tipoOcorrencia);
		printf("------------------------------------------------------------");
		aux=aux->prox;
	}
	system("pause");
}

void busca(Registro *Lista){
	int i, n=0, teste, mat;
	printf("Informe a matricula que deseja buscar na lista:\n");
	scanf("%d", &mat);
	Registro *aux = Lista;
	n = quant(Lista);
	
	for(i=0; i<n; i++){
		if(aux->matricula == mat){
			printf("Matricula encontrada\n");
			printf("Ocorrencia: %s\n", aux->tipoOcorrencia);
			i=n+1;
		}
		aux = aux->prox;
	}
	if(i == n){
		printf("Matricula nao encontrada, tente novamente\n");
	}
	system("pause");
}

void exibirQtd(Registro *Lista){
	int n=0;
	
	n = quant(Lista);
	
	printf("Quantidade de matriculados: %d\n", n);
	system("pause");
}

void imprimir(Registro *Lista){
	Registro *aux;
	aux = Lista;
	int i=0;
	printf("Lista de Matriculas:\n\n");
	while(aux!=NULL){
		printf("Posicao %d:\n", i);
		printf("Matricula: %d\n", aux->matricula);
		printf("Ocorrencia: %s\n", aux->tipoOcorrencia);
		printf("--------------------------------------------\n");
		aux=aux->prox;
		i++;
	}
	system("pause");
}

void alterar(Registro *Apontador){
	int opc, i=0;
	Registro *aux = Apontador;
	printf("\nInforme o compromisso que deseja alterar:\n\n");
	imprimir(Apontador);
	scanf("%d", &opc);
	
	for(i=0; i<opc; i++){
		aux = aux->prox;
	}
	
	printf("O que deseja alterar:\n1 Matricula\n2 Ocorrencia\n");
	scanf("%d", &opc);
	
	if(opc==1){
		printf("Atualize matricula:\n");
		scanf("%d", &aux->matricula);
	}
	else if(opc==2){
		printf("Atualize Ocorrencia:\n");
		fflush(stdin);
		fgets(aux->tipoOcorrencia,10,stdin);
	}
	printf("Lista atualizada:\n");
	imprimir(Apontador);
}

void arquivar(Registro *Apontador){
	FILE *save;
	Registro *aux = Apontador;
	int n, i;
	
	save = fopen("Lista.txt", "w");
	
	if (save == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
		exit(0);
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");
		n=quant(Apontador);
		for(i=0; i<n; i++){
			fprintf(save, "%d %s\n", aux->matricula, aux->tipoOcorrencia);
			aux = aux->prox;
		}
	}	
	fclose(save);
}

void carregar(Registro **Apontador){
	FILE *load;
	Registro *aux;
	load = fopen("Lista.txt", "r");
	int mat;
	char b[10];
	
	if (load == NULL){
		printf("ERRO! O arquivo nao foi aberto!\n");
		system("pause");
	}
	else{
		printf("O arquivo foi aberto com sucesso!");
		system("pause");		
		while(fscanf(load,"%d %[^\n]s", &mat, b) != EOF){
			Registro *novo = (Registro*)malloc(sizeof(Registro));
			novo->matricula = mat;
			strcpy(novo->tipoOcorrencia, b);
			aux = *Apontador;
			if( (*Apontador) == NULL){
				novo->prox = NULL;
				*Apontador = novo;
			}
			else{
				while( aux->prox != NULL){
					aux = aux->prox;
				}
				novo->prox = NULL;
				aux->prox = novo;
			}
		} 
	}
	fclose(load);
}

void reiniciar(Registro **Apontador){
	Registro *ant;
	while((*Apontador)!=NULL){
		ant = *Apontador;
		*Apontador = (*Apontador)->prox;
		free(ant);
	}	
}

int main(int argc, char *argv[]) {
	
	int opc, x=1, y=0;
	Registro *Lista=NULL;
	while(x==1){
		system("cls||clear");		
		printf("Informe qual opcao deseja:\n");	
		if(y==0){
			printf("0 - Inicializar Controle de Acesso Academico de Alunos\n"); // MUDAR ISSO
			y++;
		}
		printf("1 - Inserir nova Matricula\n2 - Excluir Matricula\n3 - Imprimir Lista\n");
		printf("4 - Buscar Matricula\n5 - Exibir a quantidade de Matriculados\n");
		printf("6 - Reinicializar Lista\n7 - Alterar uma Matricula ou Ocorrencia\n");
		printf("8 - Arquivar Lista\n9 - Carregar Lista\n10 - Sair\n\n");
		scanf("%d", &opc);
		if(Lista == NULL){
			if(opc == 9 || opc == 10){
			}
			else if(opc != 0){
				printf("Opcao Invalida, INICIALIZE CONTROLE DE ACESSO PRIMEIRO!\n");
				opc = 0;
			}			
		}
		switch(opc){
			case 0:
				inicializar(&Lista);
				break;
				
			case 1:
				inserir(Lista);				
				break;
		
			case 2:
				excluir(&Lista);
				if(Lista == NULL){
					y=0;
				}
				break;
		
			case 3:
				imprimir(Lista);
				break;
		
			case 4:
				busca(Lista);
				break;
		
			case 5:
				exibirQtd(Lista);
				break;
			
			case 6:
				reiniciar(&Lista);
				y=0;
				break; 
			
			case 7:
				alterar(Lista);
				break;
							
			case 8:	
				arquivar(Lista);
				break;
				
			case 9:	
				carregar(&Lista);
				break;
			
			case 10:	
				x=2;
				break;
		}	
	}
	system("cls||clear");
	printf("Tchau");
	
	return 0;
}
