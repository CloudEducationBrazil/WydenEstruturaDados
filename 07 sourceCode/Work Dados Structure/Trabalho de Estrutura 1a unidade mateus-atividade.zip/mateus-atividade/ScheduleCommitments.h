
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <string.h>
typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;


typedef struct {
	TIPOCHAVE chave;                // Controle ID
	dataRef dataCompromisso; // Data Compromisso
    char descricaoCompromisso[300]; // Descri��o
} Compromisso;

typedef struct no{
	Compromisso dado;
	struct no* next;
	
}ELEMENTO;

typedef ELEMENTO* pont;

typedef struct {
	pont inicio;
} LISTA;

void criarListaDinamica(LISTA* l){
	l->inicio = NULL;
}

int tamanhoListaDinamica(LISTA* l) {
  pont end = l->inicio;
  int tam = 0;
  while (end != NULL){
    tam++;
    end = end->next;
  }
  return tam;
  getchar();
} 


pont buscaSeqOrd(LISTA* l, TIPOCHAVE ch){
  pont pos = l->inicio;
  while (pos != NULL && pos->dado.chave < ch) pos = pos->next;
  if (pos != NULL && pos->dado.chave == ch) return pos;
  return NULL;
} 

pont buscaSeqExc(LISTA* l, TIPOCHAVE ch, pont* ant){
  *ant = NULL;
  pont atual = l->inicio;
  while (atual != NULL && atual->dado.chave<ch){
    *ant = atual;
    atual = atual->next;
  }
  if ((atual != NULL) && (atual->dado.chave == ch)) return atual;
  return NULL;
}

void exibirListaDinamica(LISTA* l){
	
if ( l->inicio == NULL) printf("\nLista Encadeada Din�mica Vazia!!!");
  pont end = l->inicio;

  while (end != NULL){
  	setlocale(LC_ALL, "Portuguese");
  	printf("====================Compromisso %d==========================\n",end->dado.chave);
    printf("CHAVE : %d \n", end->dado.chave);
    printf("DATA : %d/%d/%d \n", end->dado.dataCompromisso.dia,end->dado.dataCompromisso.mes,end->dado.dataCompromisso.ano);
    printf("DESCRICAO : %s \n",end->dado.descricaoCompromisso);
    printf("===============================================================\n");
    end = end->next;

  }
  printf("\n \n");
  getchar();
} /* exibirLista */ 

bool excluirElemLista(LISTA* l, TIPOCHAVE ch){
  pont ant, i;
  i = buscaSeqExc(l,ch,&ant);
  if (i == NULL) return false;
  if (ant == NULL) l->inicio = i->next;
  else ant->next = i->next;
  free(i);
  return true;
} /* excluirElemLista */

bool AlterarElemenLista(LISTA* l,Compromisso comp){
    pont ant, i;
 	 i = buscaSeqExc(l,comp.chave,&ant);
     if(i!=NULL){
     	   i->dado = comp;
	 }else{
	 	return false;
	 }
	 
  

     return true;
     
	
}

bool inserirElemListaOrd(LISTA* l, Compromisso comp) {
  TIPOCHAVE ch = comp.chave;
  pont ant, i;
  i = buscaSeqExc(l,ch,&ant);

  if (i != NULL)  return false;
  i = (pont) malloc(sizeof(ELEMENTO));
  i->dado = comp;
  if (ant == NULL) { // o novo elemento serah o 1o da lista
    i->next = l->inicio;
    l->inicio = i;
  } else {  // inser��o ap�s um elemento j� existente
    i->next = ant->next;
    ant->next = i;
  }  
  return true;
} /* inserirElemListaOrd */



bool SalvarListaDinamica(LISTA* l){
	pont end = l->inicio;
	int i;
	printf("[Modulo Salvar] Salvando Elemento ....... \n");
	
	if(l != NULL){
		 FILE *ArqLista;
		 ArqLista = fopen("ListaDinamica.txt", "wt");
		 if ( ArqLista == NULL ) { printf("Erro ao abrir o arquivo"); return false; };
	
	while (end != NULL){
	  	setlocale(LC_ALL, "Portuguese");
	    fprintf(ArqLista,"%d;%s;%d;%d;%d\n",end->dado.chave,end->dado.descricaoCompromisso,end->dado.dataCompromisso.dia,end->dado.dataCompromisso.mes,end->dado.dataCompromisso.ano);
	    end = end->next;

  }
  
	 fclose(ArqLista);
 	 printf("Arquivo gerado com sucesso...");
	 return true; 	
	}else{
	printf("Lista n�o inicializada");	
	}

	 return false;	
}


bool  RecuperarListaDinamica(LISTA* l){
  int i=0;
  char linha[200];

  FILE*arq;
  arq=fopen("ListaDinamica.txt","r");
  
    for(i=0;i<8 && !feof(arq);i++){
    	Compromisso compromisso;
      
      	fscanf(arq,"%d;%[^;]s ",&compromisso.chave,&compromisso.descricaoCompromisso);
      	fscanf(arq,";%d",&compromisso.dataCompromisso.dia);
      	fscanf(arq,";%d",&compromisso.dataCompromisso.mes);
      	fscanf(arq,";%d",&compromisso.dataCompromisso.ano);
      	inserirElemListaOrd(l,compromisso);
      	
    }
    

     

}


void menuDinamica(){
	
		system("CLS");
		printf("0 - Inicializar Lista \n");
		printf("1 - Exibir Tamanho da Lista \n");
		printf("2 - Exibir Lista \n");
		printf("3 - Inserir na Lista \n");
		printf("4 - Alterar na Lista \n");
		printf("5 - Excluir na Lista \n");
		printf("6 - Buscar na Lista \n");
		printf("7 - Salvar Lista \n");
		printf("8 - Carregar Lista \n");
		printf("9 - Reinicializar Lista \n");
		printf("10 - Sair da Rotina \n");
	
}
