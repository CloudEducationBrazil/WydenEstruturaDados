#define MAX 100
#include <stdio.h>
#include <time.h>
typedef int TIPOCHAVE;




typedef struct {
	dataRef dataAcesso; // Data de Acesso
	char nomePorteiro[200]; // Nome Porteiro
} dadosHeaderf;

typedef struct {
	TIPOCHAVE chave;                // Controle ID
	char matricula[40]; // Matr�cula do Aluno
// Descri��o da Ocorr�ncia (Esqueceu/Perdeu/NaoPossui/Outros cart�o)
	char TipoOcorrencia[100]; 
	dadosHeaderf porteiro;
} Ocorrencia;

typedef struct{
	Ocorrencia A[MAX];
	int nroElem;
}lista;


void inicializarListaOcorrencia(lista* lista) {
	lista->nroElem = 0;
}

int tamanho(lista* lista) {
	return lista->nroElem;
}

void exibirListaOcorrencia(lista* lista){
	int i;
	if(lista->nroElem == 0) {
	
		printf("Lista vazia .............");
	}
	for (i=0; i < lista->nroElem; i++){
		
	    printf("================= Ocorrencia n. %d===================== \n", i);
		printf("CHAVE:%i \n", lista->A[i].chave);
		printf("NOME DO PORTEIRO :%s \n", lista->A[i].porteiro.nomePorteiro);
		printf("DATA DA OCORR�NCIA :%d/%d/%d \n", lista->A[i].porteiro.dataAcesso.dia,lista->A[i].porteiro.dataAcesso.mes,lista->A[i].porteiro.dataAcesso.ano);
		printf("MATRICULA DO ALUNO : %s \n",lista->A[i].matricula);
		printf("TIPO DA OCORRENCIA : %s \n",lista->A[i].TipoOcorrencia);
		printf("====================================================== \n");
	}
	
}

bool inserirElemLista(lista* lista, Ocorrencia reg, int i){
	int j;
    time_t mytime;
   	mytime = time(NULL);
    struct tm tm = *localtime(&mytime);
	reg.porteiro.dataAcesso.dia =  tm.tm_mday;
	reg.porteiro.dataAcesso.mes = tm.tm_mon + 1;
	reg.porteiro.dataAcesso.ano = tm.tm_year + 1900;
	if ((lista->nroElem == MAX) || (i < 0) || (i > lista->nroElem))
		return false;
	for (j = lista->nroElem; j > i; j--) lista->A[j] = lista->A[j-1];
		lista->A[i] = reg;
	lista->nroElem++;
	return true;
}

int buscaOcorrencia(lista* lista, TIPOCHAVE ch) {
int i = 0;
	while (i < lista->nroElem){
	if(ch == lista->A[i].chave) return i;
		else i++;
	}
		return -1;
	}

bool excluirElemListaOcorrencia(TIPOCHAVE ch, lista* lista) {
	int pos, j;
	pos = buscaOcorrencia(lista,ch);
	if(pos == -1) return false;
	for(j = pos; j < lista->nroElem-1; j++)
	lista->A[j] = lista->A[j+1];
	lista->nroElem--;
	return true;
}

bool alterarListaOcorrencia(lista* l,Ocorrencia reg , int pos){
 	if ( pos < 0 || pos > MAX || pos > l->nroElem-1 || l->nroElem == 0 ) return false;

 	l->A[pos] = reg;
 	return true;  
 }
 

bool SalvarListaOcorrencia(lista* l){
	FILE *ArqLista;
	ArqLista = fopen("AccessControlAcademic.txt", "w");
    if ( ArqLista == NULL ) { printf("Erro ao abrir o arquivo"); return 0; };
    
   	int i;
	for (i=0; i < l->nroElem; i++){
		 fprintf(ArqLista,"%d;%s;%d;%d;%d;%s;%s",l->A[i].chave,l->A[i].porteiro.nomePorteiro,l->A[i].porteiro.dataAcesso.dia,l->A[i].porteiro.dataAcesso.mes,l->A[i].porteiro.dataAcesso.ano,l->A[i].matricula,l->A[i].TipoOcorrencia);
	}
	fclose(ArqLista);
  	printf("Arquivo gerado com sucesso...");
} 

bool CarregarListaOcorrencia(lista* l){
	
   int i=0;
  char linha[200];

  FILE*arq;
  arq=fopen("AccessControlAcademic.txt","r");
  
    for(i=0;i<MAX && !feof(arq);i++){
    	Ocorrencia ocorrencia;
      
      	fscanf(arq,"%d;%[^;]s ",&ocorrencia.chave,&ocorrencia.porteiro.nomePorteiro);
      	fscanf(arq,";%d",&ocorrencia.porteiro.dataAcesso.dia);
      	fscanf(arq,";%d",&ocorrencia.porteiro.dataAcesso.mes);
      	fscanf(arq,";%d",&ocorrencia.porteiro.dataAcesso.ano);
      	fscanf(arq,";%[^;]s",&ocorrencia.matricula);
      	fscanf(arq,";%[^;]s",&ocorrencia.TipoOcorrencia);
      	inserirElemLista(l,ocorrencia,i);
      	
    }
	

} 
 
void menuOcorrencia(){
	
		system("CLS");
		printf("0 - Inicializar Lista \n");
		printf("1 - Exibir Tamanho da Lista \n");
		printf("2 - Exibir Lista \n");
		printf("3 - Inserir na Lista \n");
		printf("4 - Alterar na Lista \n");
		printf("5 - Excluir na Lista \n");
		printf("6 - Buscar na Lista \n");
		printf("7 - Salvar Lista \n");
		printf("8 - Carregar Lista \n");
		printf("9 - Reinicializar Lista \n");
		printf("10 - Sair da Rotina \n");
	
}

