#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define tamLista 5
#define false 0
#define true 1


typedef int TipoChave;

typedef struct{ TipoChave chave;
} Registro;

typedef struct { 
	Registro A[tamLista];
	int nroElemento;
} Lista;




void menu() {
		system("CLS");
		printf("0 - Inicializar Lista \n");
		printf("1 - Exibir Tamanho da Lista \n");
		printf("2 - Exibir Lista \n");
		printf("3 - Inserir na Lista \n");
		printf("4 - Inserir na Lista Completa \n");
		printf("5 - Alterar na Lista \n");
		printf("6 - Excluir na Lista \n");
		printf("7 - Buscar na Lista \n");
		printf("8 - Salvar Lista \n");
		printf("9 - Carregar Lista \n");
		printf("10 - Reinicializar Lista \n");
		printf("11 - Sair da Rotina \n");
};




void inicializaLista(Lista* l) {
	l->nroElemento = 0;
}

void tamanhoLista(Lista* l){
	printf("\nQuantidade de Elementos na Lista = %d \n", l->nroElemento);
	printf("\nTotal em Bytes %d \n", sizeof(l));
}

void exibeLista(Lista* l){
    printf("\n\n");
    if ( l->nroElemento == 0 ) printf("Lista Vazia\n");
	int i;
	for ( i = 0; i<l->nroElemento; i++)
	  printf("Elemento [%d]=%d\n", i, l->A[i].chave);
	  
    if ( l->nroElemento < tamLista)
	  printf("\n Proxima Posicao LIVRE da Lista = %d", l->nroElemento);
	else
	  printf("\n Lista CHEIA");
};

bool inserirLista(Lista* l, Registro reg, int pos){
 	if ( l->nroElemento == tamLista || pos > l->nroElemento || pos < 0 || pos > tamLista ) return false;
 	int i;
 	for ( i = l->nroElemento; i > pos; i--)
 	  l->A[i] = l->A[i-1];
 	  
 	l->A[pos] = reg;
 	l->nroElemento++;
 	return true;  
 }
 
  int buscarLista(Lista* l, TipoChave chave){
 	int pos;
 	for ( pos=0; pos < l->nroElemento; pos++)
 	  if ( chave == l->A[pos].chave )
	    return pos;
	
	// Se n�o encontrou
    return -1;
 }

bool inserirListaCompleta(Lista* l) {
	Registro reg;

	if ( l->nroElemento > 0 ) { printf("\nLista ja INSERIDA"); return false; }
	int i ;
 	for ( i = 0; i < tamLista; i++){
 		printf("\nDigite Elemento [%d]=? ", i); scanf("%d", &reg); 
 	    l->A[i] = reg;
 	    l->nroElemento++;
	 }
	 
	 printf("\nLista INSERIDA"); 
	 return true;
}

bool alterarLista(Lista* l, TipoChave chave, int pos){
 	if ( pos < 0 || pos > tamLista || pos > l->nroElemento-1 || l->nroElemento == 0 ) return false;

 	l->A[pos].chave = chave;
 	return true;  
 }

bool excluirLista(Lista* l, TipoChave chave){
    int pos = buscarLista(l, chave);
    if ( pos == -1 ) return false;
    int i ;
    for (  i = pos; i < l->nroElemento-1; i++)
	  l->A[i] = l->A[i+1];
 	
	l->nroElemento--;
    return true;
 }
 

 
bool SalvarLista(Lista* l){
	printf("[Modulo Salvar] Salvando Elemento ....... \n");
	
	if(l != NULL){
	 FILE *ArqLista;
	 ArqLista = fopen("ListaEstatica.txt", "wt");
	 if ( ArqLista == NULL ) { printf("Erro ao abrir o arquivo"); return false; };
	 int i;
	 for ( i = 0; i<l->nroElemento; i++){
	 
	 	int cv=l->A[i].chave;
	 	fprintf(ArqLista, "%d \n",cv);
	 
	 }	
	 fclose(ArqLista);
 	 printf("Arquivo gerado com sucesso...");
	 return true; 	
	}else{
	printf("Lista n�o inicializada");	
	}

	 return false;	
}

bool  RecuperarLista(Lista* l){
	if(l != NULL){
		
	   FILE* ArqLista;
  	   ArqLista = (FILE*) malloc(sizeof(FILE));	
  	   ArqLista = fopen("ListaEstatica.txt", "r");
  	   
  	    char  linha[200];
		char* result;
		
		  if ( ArqLista == NULL ) { printf("Erro ao abrir o arquivo"); };
			int i = 0;
		  while (!feof(ArqLista)) {
		     result = fgets(linha,200, ArqLista);
			
		     if (result){
		     	Registro numero;
		     	numero.chave = strtol(linha, NULL, 10);
		     	inserirLista(l,numero,i);
		     	i++;
			 }
		         
		  }
		
		  fclose(ArqLista);
  	   
		
	}
}
 
