#include <stdio.h>
#include <stdlib.h>
#include "InclusionNumbersIntegers.h"

int main(int argc, char *argv[]) {
	
	LISTA lista;
	REGISTRO registro;
	tipoChave chave;
	
	int opcao = 0, opcao2 = 0, opcao3 = 0, posicao;
	
	do{
        system("cls");
        printf("Seja bem-vindo ao Menu Principal!\n\n");
		printf("Selecione uma das opcoes abaixo:\n\n");
		printf("1 - Criar Lista\n0 - Fechar programa\n\n");
		printf("Digite a opcao: ");
		scanf("%d", &opcao);
		switch(opcao){
    		case 1:{
    	    	inicializarLista(&lista); 
				break;
			}
			case 0:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
    	        break;
    	    }
		}
	}while(opcao != 1);
	
	do{
		system("cls");
		printf("Seja bem-vindo ao Menu Secundario!\n\n");
		printf("Selecione uma das opcoes abaixo:\n\n");
		printf("1 - Inserir elemento\n2 - Alterar elemento\n");
		printf("3 - Excluir elemento\n4 - Buscar elemento\n");
		printf("5 - Salvar arquivo\n6 - Carregar arquivo\n");
		printf("7 - Exibir lista\n8 - Reinicializar lista\n");
		printf("9 - Sair\n\n");
		printf("Digite a opcao: ");
		scanf("%d", &opcao);
		switch(opcao){
			case 1:{
				system("cls");
				printf("CHAVE: ");
				scanf("%d", &registro.chave);
				system("cls");
				printf("Selecione onde deseja inserir o elemento:\n\n");
				printf("1 - Inicio\n2 - Final\n3 - Escolher posicao\n\n");
				printf("Digite a opcao: ");
				scanf("%d", &opcao2);
				switch(opcao2){
					case 1:{
						inserirInicio(&lista, registro);
						break;
					}
					case 2:{
						inserirFinal(&lista, registro);
						break;
					}
					case 3:{
						system("cls");
						printf("Informe a posicao: ");
						scanf("%d", &posicao);
						inserirPosicao(&lista, registro, posicao);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
					break;
				}
			}
			case 2:{
				printf("Informe a posicao para busca: ");
				scanf("%d", &posicao);
				editarChave(&lista, posicao);
				system("pause");
				break;
			}
			case 3:{
				printf("Informe a posicao para busca: ");
				scanf("%d", &posicao);
				excluirChave(&lista, posicao);
				system("pause");
				break;
			}
			case 4:{
				printf("Informe a posicao para busca: ");
				scanf("%d", &posicao);
    	    	buscarPorChave(&lista, posicao); 
    	    	printf("1 - Editar elemento chave\n");
				printf("2 - Excluir elemento chave\n");
				printf("0 - Sair\n");
				printf("Digite a opcao: ");
				scanf("%d", &opcao); 
    			switch(opcao){
					case 1:{
    					editarChave(&lista, posicao);
    					system("pause");
						break;
					}
					case 2:{
						excluirChave(&lista, posicao);
						system("pause");
						break;
					}
					case 0:{
						system("pause");
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 5:{
				salvarArquivo(&lista);
				system("pause");
				break;
			}
			case 6:{
				carregarListaArq(&lista);
				system("pause");
				break;
			}
			case 7:{
				do{
					system("cls");
					printf("O que deseja exibir?\n");
					printf("1 - Elementos da lista?\n");
					printf("2 - Quantidade de elementos na lista?\n\n");
					printf("Digite a opcao: ");
					scanf("%d", &opcao2);
					switch(opcao2){
						case 1:{
							imprimirLista(&lista);
							system("pause");
    	        			break;
    	    			}	
    	    			case 2:{
    	    				printf("Quantidade de elementos na lista: %d\n", imprimirQtdElemento(&lista));
    	    				system("pause");
							break;
						}
						default:{
    	        			system("cls");
    	        			printf("Erro, opcao invalida! Retorne ao menu!\n");
    	        			system("pause");
    	        			break;
    	   				}
					}
				}while(opcao2 != 1 && opcao2 != 2); 
    	        break;
			}
			case 8:{
				reinicializarLista(&lista);
				system("pause");
    			break;
			}
			case 9: {
				system("cls");
				printf("A lista sera fechada!\n");
				printf("Deseja salvar os elementos da lista em um arquivo?\n");
				printf("0 - Sim\n1 - Nao\n");
				printf("Digite a opcao: ");
    			scanf("%d", &opcao3);
    			system("cls");
    			switch(opcao3){
    				case 0:{
    					salvarArquivo(&lista);
    					system("cls");
						printf("A lista foi sava e e o app sera encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("O app foi encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			default:{
				system("cls");
				printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
				break;
			}
		}
	}while(opcao!=9);
	return 0;
}
