#include <stdio.h>
#include <stdlib.h>
#define MAX 10
#include "InclusionNumbersIntegers.h"


void inicializarLista(LISTA *lista){
	lista->numElem = 0;
	system("cls");
	printf("Estrutura Inicializada!\n");
	system("pause");
}

void reinicializarLista(LISTA *lista){
	lista->numElem = 0;
	printf("A lista foi reinicializada com sucesso!\n");
}

int QntElemLista(LISTA *lista){
	LISTA aux = *lista;
	return aux.numElem;
}

void buscarPorChave(LISTA *lista, int posicao){
	int opcao;
	system("cls");
    if(posicao < lista->numElem){
    	system("cls");
		printf("Indice %d - Chave: %d\n", posicao, lista->vet[posicao].chave);
    }else
    	printf("Essa posicao nao existe na lista!\n");
    system("pause");
}

void editarChave(LISTA *lista, int posicao){
	REGISTRO registro;
	system("cls");
	printf("Por favor, informe a nova chave:\n\nCHAVE: ");
    scanf("%d", &registro.chave);
    lista->vet[posicao] = registro;
}

void excluirChave(LISTA *lista, int posicao){
	int i = 0;
	system("cls");
	if(posicao < lista->numElem){
		printf("O item foi excluido com sucesso!\n");
		if(posicao == (lista->numElem-1))
			lista->numElem = lista->numElem-1;
		else{
			for(i = posicao; i < lista->numElem-1; i++){
				lista->vet[i] = lista->vet[i+1];
				lista->numElem = lista->numElem-1;	
			}
			printf("O item foi excluido com sucesso!\n");
		}
	}else
		printf("Essa posicao nao existe!\n");
	system("pause");
}

void inserirFinal(LISTA *lista, REGISTRO registro){
	system("cls");
	if(lista->numElem < MAX){
		lista->vet[lista->numElem] = registro;
    	lista->numElem = lista->numElem+1;
    	printf("Inserido com sucesso!\n");
	}else{
		printf("Erro! A lista est� cheia\n");
	}
	system("pause");
}

void inserirInicio(LISTA *lista, REGISTRO registro){
	inserirPosicao(lista, registro, 0);
}

void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao){
	int i;
	system("cls");
    if(posicao >= lista->numElem)
    	inserirFinal(lista,registro);
	else{
    	if(lista->numElem < MAX){
    		printf("Inserido com sucesso!\n");
        	for(i = lista->numElem; i > posicao; i--){
        	lista->vet[i] = lista->vet[i-1];
        	lista->vet[posicao] = registro;
        	lista->numElem++;
			}           	
    	}else
			printf("Erro! A lista est� cheia\n");
		system("pause");
    }
}

int imprimirQtdElemento(LISTA *lista){
	system("cls");
	if(lista->numElem == 0)
		printf("A lista est� vazia!\n");
	else{
		return lista->numElem;
	system("pause");		
	}
}

void imprimirLista(LISTA *lista){
	int i;
	system("cls");
	if(lista->numElem == 0){
		printf("A lista est� vazia!\n");
		system("pause");
	}else{
		for(i = 0; i < lista->numElem; i++){
			printf("Lista: \n");
			printf("Indice: %d - Chave: %d\n\n",i, lista->vet[i].chave);
		}
		system("pause");
	}
}

void salvarArquivo(LISTA *lista){
	int i;
	int tamanho = QntElemLista(lista);
	FILE *file;
	if(tamanho==0){
		system("cls");
		printf("A lista est� vazia e n�o possui elementos!\n");
		system("pause");
	}else{
		file = fopen ("InclusionNumbersIntegrersRegistro.txt","w");
		if(file==NULL){
			printf("Erro ao criar arquivo!\n");
			system("pause");
		}else{
			for(i=0;i<tamanho;i++)
				fprintf(file,"Indice: %d - Chave: %d\n",i,lista->vet[i].chave);
			system("cls");
			printf("Arquivo salvo com sucesso!\n");
			system("pause");
		}
		fclose(file);
	}
}

void carregarListaArq(LISTA *lista){
	FILE *file;
	REGISTRO registro;
	file = fopen("InclusionNumbersIntegrersRegistro.txt","r");
	if(file == NULL){
		system("cls");
		printf("Erro ao carregar arquivo!\n");
		system("pause");
	}else{
		while(fscanf(file,"%d",&registro.chave)!=EOF)
			inserirFinal(lista, registro);
		system("cls");
		printf("O arquivo foi carregado!\n");
		system("pause");
	}
	fclose(file);
}
