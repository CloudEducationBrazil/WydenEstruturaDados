typedef int tipoChave;

typedef struct tipoChave{
	tipoChave chave;
}REGISTRO;

typedef struct {
	REGISTRO vet[50];
	int numElem;
} LISTA;

void inicializarLista(LISTA *lista);
void reinicializarLista(LISTA *lista);
int QntElemLista(LISTA *lista);
void buscarPorChave(LISTA *lista, int posicao);
void editarChave(LISTA *lista,int posicao);
void excluirChave(LISTA *lista,int posicao);
void inserirFinal(LISTA *lista, REGISTRO registro);
void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao);
void inserirInicio(LISTA *lista, REGISTRO registro);
int imprimirQtdElemento(LISTA *lista);
void imprimirLista(LISTA *lista);
void excluirElementos(LISTA *lista, int posicao);
void salvarArquivo(LISTA *lista);
void carregarListaArq(LISTA *lista);
