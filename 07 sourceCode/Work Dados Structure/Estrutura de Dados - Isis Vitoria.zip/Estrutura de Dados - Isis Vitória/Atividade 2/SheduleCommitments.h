typedef int TIPOCHAVE;

typedef struct {
	TIPOCHAVE chave;
	int dia;
    int mes;
    int ano;
    char descricaoCompromisso[TAM_DESC];
}REGISTRO;

typedef struct lista{
    REGISTRO registro;
    struct lista *prox;
}*LISTA;

LISTA *criarAgenda();

int verificarAgenda(LISTA *lista, REGISTRO registro);
int imprimirQuantidade(LISTA *lista);
void imprimirAgenda(LISTA *lista);
void inserirInicio(LISTA *lista, REGISTRO registro);
void inserirFinal(LISTA *lista, REGISTRO registro);
void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao);
void buscarPosicao(LISTA *lista, int posicao);
void buscarChave(LISTA *lista, TIPOCHAVE chave);
void deletarPosicao(LISTA *lista, int posicao, int verificador);
void deletarChave(LISTA *lista, TIPOCHAVE chave);
void editarRegistro(LISTA *lista, int posicao);
void gravarArquivo(LISTA *lista);
void reiniciarLista(LISTA *lista);
