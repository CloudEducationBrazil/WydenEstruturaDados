#include <stdio.h>
#include <stdlib.h>
#define TAM_DESC 300
#include "SheduleCommitments.h"

LISTA *criarAgenda(){
	LISTA *lista = (LISTA*)malloc(sizeof(LISTA)); 
	if(lista != NULL)
        *lista = NULL;
	system("cls");
    printf("A agenda foi criada com sucesso!\n");
    system("pause");
    return lista;
}

int verificarAgenda(LISTA *lista, REGISTRO registro){
	LISTA aux;
	if(*lista == NULL)
		return 0;
	else{
		aux = *lista;
		while(aux->prox != *lista && registro.chave != aux->registro.chave){
			aux = aux->prox;
		}
		if(registro.chave == aux->registro.chave)
			return 1;
		else
			return 0;
	}
}

int imprimirQuantidade(LISTA *lista){
	LISTA aux = *lista;
    int contador = 0;
	if(lista == NULL || (*lista) == NULL)
        return 0;
    do{
        contador++;
        aux = aux->prox;
    } while(aux!=(*lista));
    return contador;
}

void imprimirAgenda(LISTA *lista){
	LISTA aux;
	int contador;
	system("cls");
	if(lista == NULL || (*lista) == NULL)
		printf("A agenda esta vazia!\n");
	else{ 
		aux = *lista;
		contador = 0;
		printf("Posicao - ID - Data - Compromisso\n");
		do{
			printf("%05d - %05d - %d/%d/%d - %s", contador, aux->registro.chave, aux->registro.dia, aux->registro.mes, aux->registro.ano, aux->registro.descricaoCompromisso);
			aux = aux->prox;
			contador++;
		} while(aux!=*lista);
	}
	system("pause");
}

void inserirInicio(LISTA *lista, REGISTRO registro){
	LISTA atual, aux;
	int verificador = verificarAgenda(lista, registro);
	if(verificador == 0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista == NULL){
			*lista = atual;
			atual->prox = atual;
		}else{
			aux = *lista;
			while(aux->prox!=*lista)
				aux = aux->prox;
			aux->prox = atual;
			atual->prox = *lista;
			*lista = atual;
		}
		system("cls");
		printf("O compromisso foi inserido com sucesso!\n");
		system("pause");
	}else{
		system("cls");
		printf("O compromisso ja havia sido inserido na agenda!\n");
		system("pause");
	}
}

void inserirFinal(LISTA *lista, REGISTRO registro){
	LISTA atual, aux;
	int verificador = verificarAgenda(lista, registro);
	if( verificador == 0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista == NULL){
			*lista = atual;
			atual->prox = atual;
		}else{
			aux = *lista;
			while(aux->prox!=*lista)
				aux = aux->prox;
			aux->prox = atual;
			atual->prox = *lista;
		}
		system("cls");
		printf("O compromisso foi inserido com sucesso!\n");
		system("pause");
	}else{
		system("cls");
		printf("O compromisso ja havia sido inserido na agenda!\n");
		system("pause");
	}
}

void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao){
	LISTA atual, aux, anterior;
	int verificador, tamanho, contador;
	verificador = verificarAgenda(lista, registro);
	tamanho = imprimirQuantidade(lista);
	contador = 0;
	if(verificador == 0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista == NULL){
			*lista = atual;
			atual->prox = atual;
		}else if(posicao == 0)
			inserirInicio(lista, registro);
		else if(posicao>=tamanho)
			inserirFinal(lista, registro);
		else{
			aux = *lista;
			while(aux->prox!=*lista && posicao!=contador){
				anterior = aux;
				aux = aux->prox;
				contador++;
			}
			atual->prox = aux;
			anterior->prox = atual;
			system("cls");
			printf("O compromisso foi inserido com sucesso!\n");
			system("pause");
		}
	}else{
		system("cls");
		printf("O compromisso ja havia sido inserido na agenda!\n");
		system("pause");
	}
}

void buscarPosicao(LISTA *lista, int posicao){
	LISTA aux;
	int contador, tamanho, opcao;
	tamanho = imprimirQuantidade(lista);
	system("cls");
	if(*lista == NULL){
		printf("A agenda esta vazia!\n");
		system("pause");
	}
	else if(posicao < tamanho){
		aux = *lista;
		contador = 0;
		while(posicao!=contador){ 
			aux = aux->prox;
			contador++;
		}
		printf("O registo foi encontrado!\n");
		printf("Posicao - ID - Data - Compromisso\n");
		printf("%05d - %05d - %d/%d/%d - %s", contador, aux->registro.chave, aux->registro.dia, aux->registro.mes, aux->registro.ano, aux->registro.descricaoCompromisso);
		printf("Selecione uma das opcoes abaixo:\n");
    	printf("1 - Editar Registro\n2 - Deletar Registro\n");
    	printf("9 - Sair\n\n");
    	printf("Digite a opcao: ");
    	scanf("%d",&opcao);
    	switch(opcao){
    		case 1:{
    			editarRegistro(lista, posicao);
				break;
			}
			case 2:{
				deletarPosicao(lista, posicao, 0);
				break;
			}
			case 9:{
				system("cls");
				printf("Retornar ao Menu!\n");
				system("pause");
				break;
			}
			default:{	
				system("cls");
				printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
				break;
			}
		}
	}else{
		printf("O registro nao foi encontrado!\n");
		system("pause");
	}
}

void buscarChave(LISTA *lista, TIPOCHAVE chave){
	LISTA aux;
	int contador;
	system("cls");
	if(*lista == NULL){
		printf("A lista esta vazia!\n");
		system("pause");
	}
	else{
		aux = *lista;
		contador = 0;
		while(chave != aux->registro.chave){
			aux = aux->prox;
			contador++;
		}
		if(chave == aux->registro.chave)
			buscarPosicao(lista, contador);
		else{
			printf("O registro nao foi encontrado!\n");
			system("pause");
		}
	}
}

void deletarPosicao(LISTA *lista, int posicao, int verificador){
	LISTA aux, anterior;
	int contador, tamanho;
	tamanho = imprimirQuantidade(lista);
	aux = *lista;
	system("cls");
	if(*lista == NULL){
		printf("A lista esta vazia!\n");
		system("pause");
	}else if((*lista) == (*lista)->prox){
        free(*lista);
        *lista = NULL;
    }
	else if(posicao == 0){ 
	    	while(aux->prox!=(*lista))
        		aux = aux->prox;
				anterior = *lista;
				aux->prox = anterior->prox;
				*lista = anterior->prox;
			free(anterior);
			if(verificador == 0)
				printf("O registro foi deletado com sucesso!\n");	
	}else if(posicao == tamanho-1){ 
		contador = 0;
		while(posicao != contador){ 
			anterior = aux;
			aux = aux->prox;
			contador++;
		}
		anterior->prox = *lista;
		free(aux);
		if(verificador == 0)
			printf("O registro foi deletado com sucesso!\n");
	}
	else if(posicao < tamanho){ 
		contador = 0;
		while(posicao!=contador){
			anterior = aux;
			aux = aux->prox;
			contador++;
		}
		anterior->prox = aux->prox;
		free(aux);
		if(verificador == 0)
			printf("O registro foi deletado com sucesso!\n");
	}else
		printf("O registro foi deletado com sucesso!\n");
	if(verificador == 0)
		system("pause");
}

void deletarChave(LISTA *lista, TIPOCHAVE chave){
	LISTA aux;
	int contador;
	system("cls");
	if(*lista == NULL){
		printf("A lista esta vazia!\n");
		system("pause");
	}
	else{
		aux = *lista;
		contador = 0;
		while(chave != aux->registro.chave){
			aux = aux->prox;
			contador++;
		}
		if(chave == aux->registro.chave)
			deletarPosicao(lista, contador, 0);
		else{
			printf("O registro nao foi encontrado!\n");
			system("pause");
		}
	}
}

void editarRegistro(LISTA *lista, int posicao){
	LISTA aux;
	REGISTRO registro;
	int contador, tamanho;
	tamanho = imprimirQuantidade(lista);
	system("cls");
	if(*lista == NULL)
		printf("A lista esta vazia!\n");
	else if(posicao < tamanho){
		aux = *lista;
		contador = 0;
		while(aux->prox!=*lista && posicao!=contador){
			aux = aux->prox;
			contador++;
		}
		printf("O registo foi encontrado!\n");
		printf("Posicao - ID - Data - Compromisso\n");
		printf("%05d - %05d - %d/%d/%d - %s", contador, aux->registro.chave, aux->registro.dia, aux->registro.mes, aux->registro.ano, aux->registro.descricaoCompromisso);
		printf("Informe o numero de chave na agenda: ");
		scanf("%d", &registro.chave);
		printf("Informe a data:\n");
		printf("\nInforme dia:");
		scanf("%d", &registro.dia);
		printf("\nInforme mes:");
		scanf("%d", &registro.mes);
		printf("\nInforme ano:");
		scanf("%d", &registro.ano);
		fflush(stdin);	
		fgets(registro.descricaoCompromisso, TAM_DESC, stdin);
		aux->registro = registro;
		system("cls");
		printf("O registro foi editado com sucesso!\n");
	}else
		printf("Erro! O registro n�o foi encontrado!\n");
	system("pause");
}

void gravarArquivo(LISTA *lista){
	FILE *arquivo;
	LISTA aux;
	int i, contador;
	system("cls");
	if(*lista == NULL)
		printf("A lista esta vazia! O arquivo n�o ser� criado!\n");
	else{
		arquivo = fopen ("ScheduleCommitments.txt","w");
		if(arquivo == NULL){
			printf("Erro ao criar arquivo.\n");
			system("pause");
		}else{
			aux = *lista;
			contador = 0;
			fprintf(arquivo, "Posicao - ID - Data - Compromisso\n");
			do{
				fprintf(arquivo,"%05d - %05d - %d/%d/%d - %s", contador, aux->registro.chave, aux->registro.dia, aux->registro.mes, aux->registro.ano, aux->registro.descricaoCompromisso);
				aux = aux->prox;
				contador++;
			} while(aux!=*lista);
			printf("O arquivo foi gerado com sucesso!\n");
		}
		fclose(arquivo);
	}
	system("pause");
}

void reiniciarLista(LISTA *lista){
	int opcao, tamanho, i;
	system("cls");
	printf("Tem certeza que deseja reinicializar a estrutura?\n");
	printf("0 - Sim\n");
	printf("1 - Nao\n");
    printf("Opcao: ");
    scanf("%d",&opcao);
    system("cls");
    switch(opcao){
    	case 0:{
			tamanho = imprimirQuantidade(lista);
			for(i = tamanho-1; i >= 0; i--){
				deletarPosicao(lista, i, 1); 
				printf("A lista foi reinicializada com sucesso!\n");
			}
			break;
		}
		case 1:{
			printf("Retorne ao menu!\n");
			break;
		}
		default:{
			printf("Erro, opcao invalida! Retorne ao menu!\n");
			break;
		}
	}
    system("pause");
}
