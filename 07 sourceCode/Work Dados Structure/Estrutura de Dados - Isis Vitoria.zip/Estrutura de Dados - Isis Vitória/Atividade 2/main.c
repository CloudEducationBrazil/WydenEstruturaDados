#include <stdio.h>
#include <stdlib.h>
#define TAM_DESC 300
#include "SheduleCommitments.h"

int main(int argc, char *argv[]) {	
	
	LISTA *lista;
    REGISTRO registro;
    TIPOCHAVE chave;
    
    int opcao = 0, opcao2, posicao, opcao3, tamanho;
	do{
		system("cls");
    	printf("Seja bem-vindo ao Menu Principal!\n\n");
		printf("Selecione uma das opcoes abaixo:\n\n");
		printf("1 - Criar uma Agenda\n0 - Sair\n\n");
		printf("Digite a opcao: ");
    	scanf("%d",&opcao);
    	switch(opcao){
    	    case 1:{
    	    	lista = criarAgenda();
				break;
			}
			case 0:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
    	        break;
    	    }
		}
	}while(opcao!=1);
			
	do{
		system("cls");
		printf("Seja bem-vindo ao Menu Secundario!\n\n");
		printf("Selecione uma das opcoes abaixo:\n\n");
    	printf("1 - Inserir registros\n2 - Editar registro\n");
    	printf("3 - Excluir Registro\n4 - Buscar Registro\n");
    	printf("5 - Exibir Registro\n6 - Gravar Registros em Arquivo\n");
    	printf("7 - Reinicializar a Estrutura\n8 - Sair\n\n");
    	printf("Digite a opcao: ");
    	scanf("%d",&opcao);
    	switch(opcao){
    	    case 1:{
    	    	system("cls");
				printf("Selecione onde deseja inserir o compromisso:\n\n");
				printf("1 - Inicio\n2 - Final\n3 - Escolher posicao\n\n");
				printf("Digite a opcao: ");
    	    	scanf("%d",&opcao3);
    	    	system("cls");
    	    	if(opcao3 == 1 || opcao3 == 2 || opcao3 == 3){
    	    		printf("Informe o numero de Chave na Agenda: "); 	    		
    	    		scanf("%d",&registro.chave);
					printf("Informe a data:\n");
					printf("\nInforme dia:");
					scanf("%d", &registro.dia);
					printf("\nInforme mes:");
					scanf("%d", &registro.mes);
					printf("\nInforme ano:");
					scanf("%d", &registro.ano);
					printf("\nInforme o compromisso:");
					fflush(stdin);	
					fgets(registro.descricaoCompromisso,TAM_DESC,stdin);
				}
    	    	switch(opcao3){
    	    		case 1:{
    	    			inserirInicio(lista,registro);
						break;
					}
					case 2:{
						inserirFinal(lista,registro);
						break;
					}
					case 3:{
						printf("Informe a posicao: ");
						scanf("%d", &posicao);
						inserirPosicao(lista, registro, posicao);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 2:{
				system("cls");
				printf("Informe a posicao do registro na Agenda: ");
				scanf("%d", &posicao);
				editarRegistro(lista, posicao);
				break;
			}
			case 3:{
				system("cls");
				printf("Selecione uma das opcoes abaixo:\n");
				printf("1 - Deletar pela chave\n2 - Deletar pela posicao\n");
				printf("Digite a opcao: ");
    	    	scanf("%d",&opcao3);
    	    	system("cls");
    	    	switch(opcao3){
    	    		case 1:{
						printf("Informe o numero da chave: ");
						scanf("%d", &chave);
						deletarChave(lista, chave);
						break;
					}
    	    		case 2:{
						printf("Informe a posicao:  ");
						scanf("%d", &posicao);
						deletarPosicao(lista, posicao, 0);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 4:{
				system("cls");
				printf("Selecione uma das opcoes abaixo: \n");
				printf("1 - Buscar por numero da Chave\n2 - Buscar por posicao\n");
				printf("Digite a opcao: ");
    	    	scanf("%d",&opcao3);
    	    	system("cls");
    	    	switch(opcao3){
    	    		case 1:{
						printf("Informe o numero da chave: ");
						scanf("%d", &chave);
						buscarChave(lista, chave);
						break;
					}
					case 2:{
						printf("Informe a posicao:  ");
    	    			scanf("%d", &posicao);
    	    			buscarPosicao(lista, posicao);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 5:{
				do{
					system("cls");
					printf("O que deseja exibir?\n");
					printf("1 - Registros na agenda?\n");
					printf("2 - Quantidade de registros na agenda?\n\n");
					printf("Digite a opcao: ");
					scanf("%d",&opcao2);
					switch(opcao2){
						case 1:{
							imprimirAgenda(lista);
							break;
						}
    	    			case 2:{
    	    				tamanho = imprimirQuantidade(lista);
    	    				printf("Quantidade de registros na agenda: %d\n", tamanho);
    	    				system("pause");
							break;
						}
						default:{
    	        			system("cls");
							printf("Erro, opcao invalida! Retorne ao menu!\n");
							system("pause");
							break;
    	   				}
					}
				}while(opcao2 != 1 && opcao2 != 2);
				break;
			}
			case 6:{
				gravarArquivo(lista);
				break;
			}
			case 7:{
				reiniciarLista(lista);
				break;
			}
			case 8:{
				system("cls");
				printf("A agenda sera fechada!\n");
				printf("Deseja gravar os registros em um arquivo?\n");
				printf("0 - Sim\n");
				printf("1 - Nao\n");
    			printf("Digite a opcao: ");
    			scanf("%d",&opcao3);
    			system("cls");
    			switch(opcao3){
    				case 0:{
    					gravarArquivo(lista);
    					system("cls");
						printf("A agenda foi encerrada!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			default:{
				system("cls");
				printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
				break;
			}
		}
	}while(opcao!=8);
	return 0;
}
