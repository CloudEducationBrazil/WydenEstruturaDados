#include <stdio.h>
#include <stdlib.h>
#include "AccessControlAcademicFila.h"

int main(int argc, char *argv[]){
	
	FILA *fila;
	REGISTRO registro;
	dadosPorteiro dados;
	FILE *file;
	
	int chave, indice, opcao, opcao2, opcao3;
		
	printf("Nome do Porteiro: ");
	fflush(stdin);
	fgets(dados.nomePorteiro,30,stdin);
	printf("Dia: ");
	scanf("%d",&dados.dataAccess.dia);
	printf("Mes: ");
	scanf("%d",&dados.dataAccess.mes);
	printf("Ano: ");
	scanf("%d",&dados.dataAccess.ano);
	
	file = fopen ("registrosPortaria.txt","w");
	if(file==NULL){
		printf("Erro ao criar arquivo!!!\n");
		system("pause");
	}else{
		fprintf(file,"Porteiro:%s Data:%d/%d/%d",dados.nomePorteiro,dados.dataAccess.dia,dados.dataAccess.mes,dados.dataAccess.ano);
	}
	fclose(file);
	
	do{
		system("cls");
		printf("Seja bem-vindo ao Menu Principal!\n\n");
		printf("Selecione uma das opcoes abaixo:\n");
		printf("1 - Criar uma estrutura\n");
 	  	printf("0 - Sair do Programa\n");
	   	printf("Digite a opcao: ");
	   	scanf("%d",&opcao);
	   	switch(opcao){
    	    case 1:{
    	    	fila = criarFila();
    	    	system("cls");
    	    	printf("A estrutura foi inicializada\n");
    	    	system("pause");
				break;
			}
			case 0:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Erro, opcao invalida! Retorne ao menu!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opcao != 1);
	
	do{
		
		printf("1 - Inserir registro\n2 - Editar registro\n");
		printf("3 - Excluir registro\n4 - Buscar registro\n");
		printf("5 - Exibir registro\n6 - Gravar registro\n");
		printf("7 - Carregar registros\n8 - Reinicializar estrutura\n");
		printf("9 - Sair\n\n");
		printf("Digite a opcao: ");
		scanf("%d",&opcao);
		switch(opcao){
			case 1:{
				system("cls");
				printf("Digite a chave: ");
    	    	scanf("%d", &registro.chave);
    	    	printf("Digite a matricula do aluno: ");
    	    	scanf("%d", &registro.matricula);
    	    	printf("Informe a ocorrencia: \n");
    	    	printf("Esqueceu/Perdeu/NaoPossui/Outros cartoes\n");
    	    	fflush(stdin);
    	    	fgets(registro.TipoOcorrencia,20,stdin);
    	    	system("cls");
				inserirRegistro(fila,registro);
				system("cls");
				printf("O registro foi inserido com sucesso!\n");
				system("pause");
				break;
			}
			case 2:{
				alterarRegistro(fila);
				break;
			}
			case 3:{
				excluirRegistro(fila);
				break;
			}
			case 4:{
				buscarElemento(fila);
				break;
			}
			case 5:{
				do{
					system("cls");
					printf("O que deseja exibir?\n");
					printf("1 - Registros na lista?\n");
					printf("2 - Quantidade de registros na lista?\n\n");
					scanf("%d",&opcao2);
					switch(opcao2){
						case 1:{
							imprimirElementos(fila);
							break;
    	    			}	
    	    			case 2:{
    	    				printf("Quantidade de registros na lista: %d\n", tamanhoFila(fila));
    	    				system("pause");
							break;
						}
						default:{
							system("cls");
							printf("Erro, opcao invalida! Retorne ao menu!\n");
							system("pause");
							break;
						}
					}
				}while(opcao2 != 1 && opcao2 != 2); 
				break;
			}
			case 6:{
				salvarArquivo(fila);
				break;
			}
			case 7:{
				carregarArquivo(fila);
				break;
			}
			case 8:{
				reinicializarFila(fila);
				break;
			}
			case 9:{
				system("cls");
				printf("O registro sera fechado!\n");
				printf("Deseja gravar os registros em um arquivo?\n");
				printf("0 - Sim\n");
				printf("1 - Nao\n");
    			printf("Digite a opcao: ");
    			scanf("%d",&opcao3);
    			system("cls");
    			switch(opcao3){
    				case 0:{
    					gravarArquivo(fila);
    					system("cls");
						printf("O registro foi encerrada!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						system("cls");
						printf("Erro, opcao invalida! Retorne ao menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			default:{
				system("cls");
				printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
				break;
			}
		}
	}while(opcao != 9);
	return 0;
}
