#include <stdio.h>
#include <stdlib.h>
#include "AccessControlAcademicFila.h"

FILA* criarFila(){
	FILA *fila = (FILA*)malloc(sizeof(FILA)); 
	if(fila!=NULL)
        *fila = NULL;
    return fila;
}

int tamanhoFila(FILA *fila){
	FILA auxiliar = *fila;
	int tamanho = 0;
	if(*fila==NULL)
		return 0;
	else{
		while(auxiliar!=NULL){
			auxiliar = auxiliar->prox;
			tamanho++;
		}
		return tamanho;
	}
}

void inserirRegistro(FILA *fila, REGISTRO registro){
	FILA novo;
	novo = (FILA)malloc(sizeof(struct fila));
	novo->registro = registro;
	novo->prox = *fila;
	*fila = novo;
}

void alterarRegistro(FILA *fila){
	FILA auxiliar = *fila;
	REGISTRO registro;
	if(*fila == NULL){
		system("cls");
		printf("Nao existem elementos na fila\n");
		system("pause");
	}else{
		while(auxiliar->prox!=NULL){
			auxiliar = auxiliar->prox;
		}
		system("cls");
		printf("Digite a chave: ");
		scanf("%d", &registro.chave);
		printf("Digite a matricula do aluno: ");
    	scanf("%d", &registro.matricula);
    	printf("Informe a ocorrencia: ");
    	fflush(stdin);
    	fgets(registro.TipoOcorrencia,20,stdin);
		auxiliar->registro = registro;
		system("cls");
		printf("Registro alterado com sucesso!\n");
		system("pause");
	}
}

void excluirRegistro(FILA *fila){
	FILA anterior, atual = *fila;
	if(*fila == NULL){
		system("cls");
		printf("Nao existem elementos na fila\n");
		system("pause");
	}else{
		if(atual->prox==NULL){
			*fila = atual->prox;
			free(atual);
		}else{
			while(atual->prox!=NULL){
				anterior = atual;
				atual = atual->prox;
			}
			anterior->prox = NULL;
			free(atual);
		}
		system("cls");
		printf("O registro foi excluido com sucesso!\n");
		system("pause");
	}
}

void buscarElemento(FILA *fila){
	FILA aux = *fila;
	int opcao1, contador = 0;
	if(*fila==NULL){
		system("cls");
		printf("Nao existem elementos na fila\n");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
			contador++;
		}
		system("cls");
		printf("Indice: %d - Chave: %d - Matricula: %d - Ocorrencia: %s\n",contador,aux->registro.chave,aux->registro.matricula,aux->registro.TipoOcorrencia);
    	printf("1 - Editar registro\n2 - Excluir registro\n");
    	printf("0 - Sair\n");
    	printf("Digite a opcao: ");
    	scanf("%d",&opcao1);
    	switch(opcao1){
    		case 1:{
    			alterarRegistro(fila);
				break;
			}
			case 2:{
				excluirRegistro(fila);
				break;
			}
			case 0:{
				break;
			}
			default:{
				system("cls");
				printf("Erro, opcao invalida! Retorne ao menu!\n");
				system("pause");
				break;
			}
		}
	}
}

void imprimirElementos(FILA *fila){
	FILA auxiliar = *fila;
	int contador = 0;
	system("cls");
	if(*fila==NULL)
		printf("Nao existem elementos na fila\n");
	else{
		while(auxiliar!=NULL){
			printf("Indice: %d - Chave: %d - Matricula: %d - Ocorrencia: %s\n",contador,auxiliar->registro.chave,auxiliar->registro.matricula,auxiliar->registro.TipoOcorrencia);
			auxiliar = auxiliar->prox;
			contador++;
		}
	}
	system("pause");
}

void salvarArquivo(FILA *fila){
	FILE *file;
	FILA aux;
	if(*fila==NULL){
		system("cls");
		printf("Nao existem elementos na fila\n");
		system("pause");
	}else{
		file = fopen ("AccessControlAcademicArq.txt","w");
		if(file==NULL){
			printf("Erro ao criar arquivo!!!\n");
			system("pause");
		}else{
			aux = *fila;
			while(aux!=NULL){
				fprintf(file,"Chave:%d - Matricula: %d - Ocorrencia:%[^\n]s\n",aux->registro.chave, aux->registro.matricula,aux->registro.TipoOcorrencia);
				aux = aux->prox;
			}
			system("cls");
			printf("O arquivo foi gerado com sucesso!\n");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(FILA *fila){
	FILE *file;
	REGISTRO registro;
	file = fopen("registrosFila.txt","r");
	if(file==NULL){
		system("cls");
		printf("ERRO ao carregar arquivo!!!\n");
		system("pause");
	}else{
		while(fscanf(file,"CHAVE:%d - MATRICULA: %d - OCORRENCIA:%[^\n]s",&registro.chave,&registro.matricula,registro.TipoOcorrencia)!=EOF){
			inserirRegistro(fila,registro);
		}
		system("cls");
		printf("O arquivo foi carregado com sucesso!\n");
		system("pause");
	}
	fclose(file);
}

void reinicializarFila(FILA *fila){
	FILA aux;
	while(*fila!=NULL){
		aux = *fila;
		*fila = aux->prox;
		free(aux);
	}
	system("cls");
	printf("A fila foi reinicializada!\n");
	system("pause");
}
