typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;

typedef struct {
	dataRef dataAccess;
	char nomePorteiro[30];
} dadosPorteiro;
	
typedef struct{
    TIPOCHAVE chave; 
    char matricula[6];
	char TipoOcorrencia[20];
} REGISTRO;

typedef struct fila{
    REGISTRO registro;
    struct fila *prox;
} *FILA;

FILA* criarFila();

int tamanhoFila(FILA *fila);
void inserirRegistro(FILA *fila, REGISTRO registro);
void alterarRegistro(FILA *fila);
void excluirRegistro(FILA *fila);
void buscarElemento(FILA *fila);
void imprimirElementos(FILA *fila);
void salvarArquivo(FILA *fila);
void carregarArquivo(FILA *fila);
void reinicializarFila(FILA *fila);
