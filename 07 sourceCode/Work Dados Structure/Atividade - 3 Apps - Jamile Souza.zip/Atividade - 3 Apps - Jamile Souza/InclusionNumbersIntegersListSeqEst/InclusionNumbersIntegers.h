typedef int tipoChave;

typedef struct tipoChave{
	tipoChave chave;
}REGISTRO;

typedef struct {
	REGISTRO vet[50];
	int numElem;
} LISTA;

void inicializarLista(LISTA *lista); //Inicializar a estrutura
void reinicializarLista(LISTA *lista);//Reinicializar a estrutura

int QntElemLista(LISTA *lista);

void buscarPorChave(LISTA *lista, int posicao);//Buscar por um elemento na estrutura

void editarChave(LISTA *lista,int posicao);//modifica a chave j� inserida

void excluirChave(LISTA *lista,int posicao);
//Inserir elementos na estrutura
void inserirFinal(LISTA *lista, REGISTRO registro);
void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao);
void inserirInicio(LISTA *lista, REGISTRO registro);

int imprimirQtdElemento(LISTA *lista);//Retornar a quantidade de elementos v�lidos
void imprimirLista(LISTA *lista);//Exibir os elementos da estrutura

void excluirElementos(LISTA *lista, int posicao);//Excluir elementos da estrutura

void salvarArquivo(LISTA *lista);//salvar os arquivos em .txt

void carregarListaArq(LISTA *lista);//adiciona mais elemento na lista j�  contida no arquivo
