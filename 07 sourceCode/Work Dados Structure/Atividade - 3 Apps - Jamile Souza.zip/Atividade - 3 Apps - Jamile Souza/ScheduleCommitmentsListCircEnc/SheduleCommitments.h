typedef int TIPOCHAVE;

/*typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;*/

typedef struct {
	TIPOCHAVE chave;// Controle ID
	//dataRef dataCompromisso; //Data Compromisso
    int dia;
    int mes;
    int ano;
    char descricaoCompromisso[TAM_DESC]; //Descri��o
}REGISTRO;

typedef struct lista{
    REGISTRO registro;
    struct lista *prox;
}*LISTA;

LISTA *criarAgenda();

int verificarAgenda(LISTA *lista, REGISTRO registro);

void inserirInicio(LISTA *lista, REGISTRO registro);
void inserirFinal(LISTA *lista, REGISTRO registro);
void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao);

int imprimirQuantidade(LISTA *lista);
void imprimirAgenda(LISTA *lista);

void buscarPosicao(LISTA *lista, int posicao);
void buscarChave(LISTA *lista, TIPOCHAVE chave);

void deletarPosicao(LISTA *lista, int posicao, int verificador);
void deletarChave(LISTA *lista, TIPOCHAVE chave);

void editarRegistro(LISTA *lista, int posicao);

void reiniciarLista(LISTA *lista);

void gravarArquivo(LISTA *lista);
