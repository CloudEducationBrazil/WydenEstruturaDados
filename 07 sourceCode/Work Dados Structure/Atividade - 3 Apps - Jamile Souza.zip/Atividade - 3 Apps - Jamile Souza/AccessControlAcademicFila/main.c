#include <stdio.h>
#include <stdlib.h>
#include "AccessControlAcademicFila.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]){
	FILA *fila;
	REGISTRO registro;
	int chave, indice, opc, opc2;
	dadosPortaria dados;
	FILE *file;
	
	printf("NOME DO PORTEIRO: ");
	fflush(stdin);
	fgets(dados.nomePorteiro,30,stdin);
	printf("DIA: ");
	scanf("%d",&dados.dataAccess.dia);
	printf("MES: ");
	scanf("%d",&dados.dataAccess.mes);
	printf("ANO: ");
	scanf("%d",&dados.dataAccess.ano);
	
	file = fopen ("registrosPortaria.txt","w");
	if(file==NULL){
		printf("Erro ao criar arquivo!!!\n");
		system("pause");
	}else{
		fprintf(file,"Porteiro:%s Data:%d/%d/%d",dados.nomePorteiro,dados.dataAccess.dia,dados.dataAccess.mes,dados.dataAccess.ano);
	}
	fclose(file);
	
	
	do{
		system("cls");
		printf("1 - CRIAR ESTRUTURA\n");
 	  	printf("0 - FECHAR PROGRAMA\n");
	   	printf("DIGITE A OPCAO: ");
	   	scanf("%d",&opc);
	   	switch(opc){
    	    case 1:{
    	    	fila = criarFila();
    	    	system("cls");
    	    	printf("ESTRUTURA INICIALIZADA\n");
    	    	system("pause");
				break;
			}case 0:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO, OPCAO INVALIDA!!!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opc != 1);
	
	do{
		printf("1 - IMPRIMIR REGISTRO\n");
 	  	printf("2 - BUSCAR REGISTRO NA FILA\n");
 	  	printf("3 - INSERIR REGISTRO NA FILA\n");
	   	printf("4 - ALTERAR REGISTRO NA FILA\n");
	   	printf("5 - EXCLUIR REGISTRO NA FILA\n");
	   	printf("6 - SALVAR REGISTRO DA FILA EM ARQUIVO\n");
 	  	printf("7 - CARREGAR REGISTRO DA FILA EM ARQUIVO\n");
 	  	printf("8 - REINICIALIZAR\n");
 	  	printf("9 - SAIR\n");
		scanf("%d",&opc);
	   	switch(opc){
		case 1:{
			do{
				system("cls");
				printf("O DESEJA IMPRIMIR?\n");
				printf("1 - QUANTIDADE DE REGISTROS NA LISTA?\n");
				printf("2 - OS REGISTROS NA LISTA?\n");
				scanf("%d",&opc2);
	  		 	switch(opc2){
					case 1:{
   	        		printf("QUANTIDADE DE REGISTROS NA LISTA: %d\n", tamanhoFila(fila));
   	        		system("pause");
    	        	break;
    	    		}	
    	    		case 2:{
    	    		imprimirElementos(fila);
					break;
					}default:{
    	        	system("cls");
    	        	printf("ERRO, OPCAO INVALIDA!!!\n");
    	        	system("pause");
    	        	break;
    	   			}
				}
			}while(opc2 != 1 && opc2 != 2); 
			break;
			}case 2:{
    	    	buscarElemento(fila);
				break;
			}case 3:{
				system("cls");
				printf("DIGITE A CHAVE: ");
    	    	scanf("%d",&registro.chave);
    	    	printf("MATRICULA: ");
    	    	scanf("%d",&registro.matricula);
    	    	printf("OCORRENCIA: \n");
    	    	printf("Esqueceu/Perdeu/NaoPossui/Outros cartoes\n");
    	    	fflush(stdin);
    	    	fgets(registro.TipoOcorrencia,20,stdin);
    	    	system("cls");
				inserirRegistro(fila,registro);
				system("cls");
				printf("REGISTRO INSERIDO COM SUCESSO!\n");
				system("pause");
				break;
			}
			case 4:{
				alterarRegistro(fila);
				break;
			}
			case 5:{
				excluirRegistro(fila);
				break;
			}
			case 6:{
				salvarArquivo(fila);
				break;
			}
			case 7:{
				carregarArquivo(fila);
				break;
			}
			case 8:{
    			reinicializarFila(fila);
    			break;
			}case 9:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO, OPCAO INVALIDA\n");
    	        system("pause");
    	        break;
    	    }
		}	
	}while(opc != 0); //ou 9 serve tamb�m
	return 0;
}
