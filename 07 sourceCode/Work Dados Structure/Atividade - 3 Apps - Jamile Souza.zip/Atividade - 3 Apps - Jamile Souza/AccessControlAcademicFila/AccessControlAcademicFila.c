#include <stdio.h>
#include <stdlib.h>
#include "AccessControlAcademicFila.h"

FILA* criarFila(){
	FILA *fila = (FILA*)malloc(sizeof(FILA)); 
	if(fila!=NULL)
        *fila = NULL;
    return fila;
}

int tamanhoFila(FILA *fila){
	FILA aux = *fila;
	int tamanho = 0;
	if(*fila==NULL)
		return 0;
	else{
		while(aux!=NULL){
			aux = aux->prox;
			tamanho++;
		}
		return tamanho;
	}
}

void imprimirElementos(FILA *fila){
	FILA aux = *fila;
	int cont = 0;
	system("cls");
	if(*fila==NULL){
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA!!!\n");
		system ("color 14");
	}else{
		while(aux!=NULL){
			printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s\n",cont,aux->registro.chave,aux->registro.matricula,aux->registro.TipoOcorrencia);
			aux = aux->prox;
			cont++;
		}
	}
	system("pause");
}

void buscarElemento(FILA *fila){
	FILA aux = *fila;
	int opc1, cont = 0;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA!!!\n");
		system ("color 14");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
			cont++;
		}
		system("cls");
		system ("color 1F");
		printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s\n",cont,aux->registro.chave,aux->registro.matricula,aux->registro.TipoOcorrencia);
    	printf("1 - EDITAR ELEMENTO NO REGISTRO DA FILA?\n");
    	printf("2 - EXCLUIR ELEMENTO NO REGISTRO DA FILA?\n");
    	printf("0 - SAIR\n");
    	printf("DIGITE A OPCAO: ");
    	scanf("%d",&opc1);
    	switch(opc1){
    		case 1:{
    			alterarRegistro(fila);
				break;
			}
			case 2:{
				excluirRegistro(fila);
				break;
			}
			case 0:{
				break;
			}
			default:{
				system("cls");
				printf("ERRO, OPCAO INVALIDA\n");
				system("pause");
				break;
			}
		}
	}
}

void inserirRegistro(FILA *fila, REGISTRO registro){
	FILA novo;
	novo = (FILA)malloc(sizeof(struct fila));
	novo->registro = registro;
	novo->prox = *fila;
	*fila = novo;
}

void alterarRegistro(FILA *fila){
	FILA aux = *fila;
	REGISTRO registro;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA\n");
		system ("color 14");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
		}
		system("cls");
		printf("DIGITE A CHAVE: ");
		scanf("%d",&registro.chave);
		printf("MATRICULA: ");
    	scanf("%d",&registro.matricula);
    	printf("OCORRENCIA: ");
    	fflush(stdin);
    	fgets(registro.TipoOcorrencia,20,stdin);
		aux->registro = registro;
		system("cls");
		printf("REGISTRO ALTERADO COM SUCESSO!!!\n");
		system ("color 16");
		system("pause");
	}
}

void excluirRegistro(FILA *fila){
	FILA anterior, atual = *fila;
	if(*fila==NULL){
		system("cls");
		printf("NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA!!!\n");
		system ("color 14");
		system("pause");
	}else{
		if(atual->prox==NULL){
			*fila = atual->prox;
			free(atual);
		}else{
			while(atual->prox!=NULL){
				anterior = atual;
				atual = atual->prox;
			}
			anterior->prox = NULL;
			free(atual);
		}
		system("cls");
		printf("REGISTRO EXCLUIDO COM SUCESSO!!!\n");
		system ("color 16");
		system("pause");
	}
}

void salvarArquivo(FILA *fila){
	FILE *file;
	FILA aux;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA!!!\n");
		system ("color 14");
		system("pause");
	}else{
		file = fopen ("AccessControlAcademicArq.txt","w");
		if(file==NULL){
			printf("Erro ao criar arquivo!!!\n");
			system ("color 04");
			system("pause");
		}else{
			aux = *fila;
			while(aux!=NULL){
				fprintf(file,"CHAVE:%d - MATRICULA: %d - OCORRENCIA:%[^\n]s\n",aux->registro.chave, aux->registro.matricula,aux->registro.TipoOcorrencia);
				aux = aux->prox;
			}
			system("cls");
			printf("ARQUIVO SALVO COM SUCESSO!!!\n");
			system ("color 16");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(FILA *fila){
	FILE *file;
	REGISTRO registro;
	file = fopen("registrosFila.txt","r");
	if(file==NULL){
		system("cls");
		printf("ERRO ao carregar o arquivo!!!\n");
		system ("color 04");
		system("pause");
	}else{
		while(fscanf(file,"CHAVE:%d - MATRICULA: %d - OCORRENCIA:%[^\n]s",&registro.chave,&registro.matricula,registro.TipoOcorrencia)!=EOF){ //& ???
			inserirRegistro(fila,registro);
		}
		system("cls");
		printf("ARQUIVO CARREGADO COM SUCESSO!!!\n");
		system ("color 16");
		system("pause");
	}
	fclose(file);
}

void reinicializarFila(FILA *fila){
	FILA aux;
	while(*fila!=NULL){
		aux = *fila;
		*fila = aux->prox;
		free(aux);
	}
	system("cls");
	printf("FILA REINICIALIZADA!!!\n");
	system ("color 17");
	system("pause");
}
