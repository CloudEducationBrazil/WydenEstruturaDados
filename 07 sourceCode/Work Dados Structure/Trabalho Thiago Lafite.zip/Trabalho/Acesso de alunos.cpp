#include<stdio.h>
#include<stdlib.h>

typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;

typedef struct {
	dataRef dataAccess; // Data de Acesso
	char nomePorteiro[30]; // Nome do Porteiro
} dadosPortaria;
	
typedef struct{
    TIPOCHAVE chave; 
    char matricula[6];
	char TipoOcorrencia[20];  //(Esqueceu/Perdeu/NaoPossui/Outros cart�o) 
} REGISTRO;

typedef struct fila{
    REGISTRO reg;
    struct fila *prox;
} *FILA;

FILA* criarFila(){
	FILA *fila = (FILA*)malloc(sizeof(FILA)); 
	if(fila!=NULL)
        *fila = NULL;
    return fila;
}

int tamanho_Fila(FILA *fila){
	FILA aux = *fila;
	int tamanho = 0;
	if(*fila==NULL)
		return 0;
	else{
		while(aux!=NULL){
			aux = aux->prox;
			tamanho++;
		}
		return tamanho;
	}
}

void imprimirElementos(FILA *fila){
	FILA aux = *fila;
	int cont = 0;
	system("cls");
	if(*fila==NULL){
		printf("FILA NAO POSSUI ELEMENTOS NOS reg DA FILA!!!\n");
		system ("color 14");
	}else{
		while(aux!=NULL){
			printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s\n",cont,aux->reg.chave,aux->reg.matricula,aux->reg.TipoOcorrencia);
			aux = aux->prox;
			cont++;
		}
	}
	system("pause");
}

void buscarElemento(FILA *fila){
	FILA aux = *fila;
	int opc1, cont = 0;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA!!!\n");
	system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
			cont++;
		}
		system("cls");
		system ("color 1F");
		printf("INDICE: %d - CHAVE: %d - MATRICULA: %d - OCORRENCIA: %s\n",cont,aux->reg.chave,aux->reg.matricula,aux->reg.TipoOcorrencia);
    	printf("1 - EDITAR ELEMENTO NO reg DA FILA?\n");
    	printf("2 - EXCLUIR ELEMENTO NO REGISTRO DA FILA?\n");
    	printf("0 - SAIR\n");
    	printf("DIGITE A OPCAO: ");
    	scanf("%d",&opc1);
    	switch(opc1){
    		case 1:
    			alterarRegistro(fila);
				break;
			
			case 2:
				excluirRegistro(fila);
				break;
			
			case 0:
				break;
			
			default:
				system("cls");
				printf("ERRO, OPCAO INVALIDA\n");
				system("pause");
				break;
			}
		}
	}


void inserirRegistro(FILA *fila, REGISTRO reg){
	FILA novo;
	novo = (FILA)malloc(sizeof(struct fila));
	novo->reg = reg;
	novo->prox = *fila;
	*fila = novo;
}

void alterarRegistro(FILA *fila){
	FILA aux = *fila;
	REGISTRO reg;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS REGISTRO DA FILA\n");
		system ("color 14");
		system("pause");
	}else{
		while(aux->prox!=NULL){
			aux = aux->prox;
		}
		system("cls");
		printf("DIGITE A CHAVE: ");
		scanf("%d",&reg.chave);
		printf("MATRICULA: ");
    	scanf("%d",&reg.matricula);
    	printf("OCORRENCIA: ");
    	fflush(stdin);
    	fgets(reg.TipoOcorrencia,20,stdin);
		aux->reg = reg;
		system("cls");
		printf("reg ALTERADO COM SUCESSO!!!\n");
		system ("color 16");
		system("pause");
	}
}

void excluirRegistro(FILA *fila){
	FILA anterior, atual = *fila;
	if(*fila==NULL){
		system("cls");
		printf("NAO POSSUI ELEMENTOS NOS reg DA FILA!!!\n");
		system ("color 14");
		system("pause");
	}else{
		if(atual->prox==NULL){
			*fila = atual->prox;
			free(atual);
		}else{
			while(atual->prox!=NULL){
				anterior = atual;
				atual = atual->prox;
			}
			anterior->prox = NULL;
			free(atual);
		}
		system("cls");
		printf("REGISTRO EXCLUIDO COM SUCESSO!!!\n");
		
		system("pause");
	}
}

void salvarArquivo(FILA *fila){
	FILE *file;
	FILA aux;
	if(*fila==NULL){
		system("cls");
		printf("FILA NAO POSSUI ELEMENTOS NOS reg DA FILA!!!\n");
		system ("color 14");
		system("pause");
	}else{
		file = fopen ("AccessControlAcademicArq.txt","w");
		if(file==NULL){
			printf("Erro ao criar arquivo!!!\n");
			system ("color 04");
			system("pause");
		}else{
			aux = *fila;
			while(aux!=NULL){
				fprintf(file,"CHAVE:%d - MATRICULA: %d - OCORRENCIA:%[^\n]s\n",aux->reg.chave, aux->reg.matricula,aux->reg.TipoOcorrencia);
				aux = aux->prox;
			}
			system("cls");
			printf("ARQUIVO SALVO COM SUCESSO!!!\n");
			system ("color 16");
			system("pause");
		}
		fclose(file);
	}
}

void carregarArquivo(FILA *fila){
	FILE *file;
	REGISTRO reg;
	file = fopen("registrosFila.txt","r");
	if(file==NULL){
		system("cls");
		printf("ERRO ao carregar o arquivo!!!\n");
		system ("color 04");
		system("pause");
	}else{
		while(fscanf(file,"CHAVE:%d - MATRICULA: %d - OCORRENCIA:%[^\n]s",&reg.chave,&reg.matricula,reg.TipoOcorrencia)!=EOF){ //& ???
			inserirRegistro(fila,reg);
		}
		system("cls");
		printf("ARQUIVO CARREGADO COM SUCESSO!!!\n");
		system ("color 16");
		system("pause");
	}
	fclose(file);
}

void reinicializarFila(FILA *fila){
	FILA aux;
	while(*fila!=NULL){
		aux = *fila;
		*fila = aux->prox;
		free(aux);
	}
	system("cls");
	printf("FILA REINICIALIZADA!!!\n");
	system("pause");
}

FILA* criarFila();

int tamanhoFila(FILA *fila);

void imprimirElementos(FILA *fila);

void buscarElemento(FILA *fila);

void inserirRegistro(FILA *fila, REGISTRO reg);

void alterarRegistro(FILA *fila);

void excluirregistro(FILA *fila);

void salvarArquivo(FILA *fila);

void carregarArquivo(FILA *fila);

void reinicializarFila(FILA *fila);
int main(){
	FILA *fila;
	Registro reg;
	int chave, indice, opc, opc2;
	dadosPortaria dados;
	FILE *file;
	
	printf("NOME DO PORTEIRO: ");
	fflush(stdin);
	fgets(dados.nomePorteiro,30,stdin);
	printf("DIA: ");
	scanf("%d",&dados.dataAccess.dia);
	printf("MES: ");
	scanf("%d",&dados.dataAccess.mes);
	printf("ANO: ");
	scanf("%d",&dados.dataAccess.ano);
	
	file = fopen ("registrosPortaria.txt","w");
	if(file==NULL){
		printf("Erro ao criar arquivo!!!\n");
		system("pause");
	}else{
		fprintf(file,"Porteiro:%s Data:%d/%d/%d",dados.nomePorteiro,dados.dataAccess.dia,dados.dataAccess.mes,dados.dataAccess.ano);
	}
	fclose(file);
	
	
	do{
		system("cls");
		printf("1 - CRIAR ESTRUTURA\n");
 	  	printf("0 - FECHAR PROGRAMA\n");
	   	printf("DIGITE A OPCAO: ");
	   	scanf("%d",&opc);
	   	switch(opc){
    	    case 1:{
    	    	fila = criarFila();
    	    	system("cls");
    	    	printf("ESTRUTURA INICIALIZADA\n");
    	    	system("pause");
				break;
			}case 0:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO, OPCAO INVALIDA!!!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opc != 1);
	
	do{
		printf("1 - IMPRIMIR reg\n");
 	  	printf("2 - BUSCAR REGISTRO NA FILA\n");
 	  	printf("3 - INSERIR REGISTRO NA FILA\n");
	   	printf("4 - ALTERAR REGISTRO NA FILA\n");
	   	printf("5 - EXCLUIR REGISTRO NA FILA\n");
	   	printf("6 - SALVAR REGISTRO DA FILA EM ARQUIVO\n");
 	  	printf("7 - CARREGAR REGISTRO DA FILA EM ARQUIVO\n");
 	  	printf("8 - REINICIALIZAR\n");
 	  	printf("9 - SAIR\n");
		scanf("%d",&opc);
	   	switch(opc){
		case 1:{
			do{
				system("cls");
				printf("O DESEJA IMPRIMIR?\n");
				printf("1 - QUANTIDADE DE regS NA LISTA?\n");
				printf("2 - OS REGISTROS NA LISTA?\n");
				scanf("%d",&opc2);
	  		 	switch(opc2){
					case 1:{
   	        		printf("QUANTIDADE DE regS NA LISTA: %d\n", tamanho_Fila(fila));
   	        		system("pause");
    	        	break;
    	    		}	
    	    		case 2:{
    	    		imprimirElementos(fila);
					break;
					}default:{
    	        	system("cls");
    	        	printf("ERRO, OPCAO INVALIDA!!!\n");
    	        	system("pause");
    	        	break;
    	   			}
				}
			}while(opc2 != 1 && opc2 != 2); 
			break;
			}case 2:{
    	    	buscarElemento(fila);
				break;
			}case 3:{
				system("cls");
				printf("DIGITE A CHAVE: ");
    	    	scanf("%d",&registro.chave);
    	    	printf("MATRICULA: ");
    	    	scanf("%d",&registro.matricula);
    	    	printf("OCORRENCIA: \n");
    	    	printf("Esqueceu/Perdeu/NaoPossui/Outros cartoes\n");
    	    	fflush(stdin);
    	    	fgets(reg.TipoOcorrencia,20,stdin);
    	    	system("cls");
				inserirRegistro(fila,reg);
				system("cls");
				printf("REGISTRO INSERIDO COM SUCESSO!\n");
				system("pause");
				break;
			}
			case 4:{
				alterarRegistro(fila);
				break;
			}
			case 5:{
				excluirregistro(fila);
				break;
			}
			case 6:{
				salvarArquivo(fila);
				break;
			}
			case 7:{
				carregarArquivo(fila);
				break;
			}
			case 8:{
    			reinicializarFila(fila);
    			break;
			}case 9:{
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO, OPCAO INVALIDA\n");
    	        system("pause");
    	        break;
    	    }
		}	
	}while(opc != 0); //ou 9 serve tamb�m
	return 0;
}






































