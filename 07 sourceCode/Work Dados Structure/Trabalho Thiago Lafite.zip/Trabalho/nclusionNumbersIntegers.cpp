#include <stdlib.h>
#include <stdio.h>

struct TipoCelula{
    int ch;
    TipoCelula *prox;
};

struct TipoPilha{
       TipoCelula *fundo, *topo;
       };
       
int Pilha_contador;
TipoCelula *Topo;


bool Pilha_Construtor(){
    Topo=NULL;
    Pilha_contador=0;
}

bool Pilha_Vazia(){
    if(Topo==NULL){
        return true;
    }else{
        return false;
    }
}

bool Pilha_Destrutor(){
    int Aux;
    TipoCelula *Temp;

    if( Pilha_Vazia() ){
        return false;
    }else{
        while(Topo!=NULL){
            Temp=Topo;
            Temp->prox=NULL;

            Topo=Topo->prox;

            free(Temp);
        }
        Pilha_contador=0;
        return true;
    }
}


int Pilha_Tamanho(){
    return Pilha_contador;
}

bool Pilha_Push(int valor){//Empilhar
    TipoCelula *Nova_celula = (TipoCelula*)malloc(sizeof(TipoCelula));

    if(Nova_celula==NULL){ //Caso o SO n�o forne�a mem�ria RAM
        return false;
    }else{
        Nova_celula->ch = valor;
        Nova_celula->prox = Topo;

        Topo=Nova_celula;

        Pilha_contador++;
        return true;
    }
}

bool Pilha_Pop(int &valor){ //Desempilhar
    TipoCelula *Temp;
    if(Pilha_Vazia()){
        return false;
    }else{
        valor = Topo->ch;

        Temp = Topo;
        Topo = Topo->prox;

        Temp->prox=NULL; //Medida de seguran�a para desligar a c�lula removida da pilha

        free(Temp);
        Pilha_contador--;
        return true;
    }
}

bool Pilha_Get(int &valor){ //Obt�m o elemento no topo da pilha
    if(Pilha_Vazia()){
        return false;
    }else{
        valor=Topo->ch;
        return true;
    }
}

    
     void imprimir(int &valor){
   TipoCelula *temp;
   
   if(temp!= NULL){
   
   for(temp= temp;temp!=NULL;temp=temp->prox){
   
     printf("\n%d ",temp->ch);
     }
   }else {
   
    printf("Pilha vazia\n");
    }

}


void Menu() 
{ 
    	printf ("|================================|\n");
		printf ("|       SELECINE UMA OPCAO       |\n");
		printf ("|1. Para Inserir um numero		  |\n");
		printf ("|2.  Listar os numeros           |\n");
		printf ("|3.  Remover os numeros          |\n");
		printf ("|4.  Tamanho da pilha      	  |\n");
		printf ("|5.  Localizar um numero   	  |\n");
		printf ("|6.  Encerrar a pilha            |\n");
		printf ("|================================|\n");
			printf(" Selecione uma opcao por favor: ");
				
}

int main(){
    int valor;
    int opc;
    TipoCelula Item;
    Pilha_Construtor();
    Menu();
    scanf("%d",&opc);
		while (opc != 7) 
    {

        switch (opc) 
        { 
            case 1: 
                printf( "insira o valor: "); 
                scanf("\n%d",&valor);
	         	 Pilha_Push(valor);
                printf("\n\n-----------Numero Inserido------------\n\n");
             	break; 
            case 2: 
              //MostrarPilha(valor);
              
              printf("\nelementos da pilha\n");
              imprimir(valor);
             break;
           case 3:
           	printf("\nExlcusao da pilha : \n\n");
            Pilha_Pop(valor);
            
            //	MostrarPilha(valor);
            	break;
			case 4:
				Pilha_Tamanho();
				printf("\n\nTamanho da pilha: %d \n\n",Pilha_Tamanho());
				break;
			case 5:
				printf("Selecione o item a ser localizado:\t");
				scanf("%d",&valor);
				Pilha_Get(valor);
				printf("Numero encontrado: %d",Pilha_Get(valor));
				break;
				
            default: 
                printf( "Escolha invalida.\n\n"); 
                Menu(); 
                break; 
        }

        scanf("%i", &opc);
	

     
    }

    system("pause");
    return 0;
}
