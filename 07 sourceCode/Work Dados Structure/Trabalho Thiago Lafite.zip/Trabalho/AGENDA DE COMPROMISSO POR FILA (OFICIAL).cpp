#include <stdio.h> 
#include <stdlib.h> 
#include <conio.h> 
#include <string.h>


struct Registro
{ 
    int chave; 
    char comp[50]; 
    char dia [50];
};

struct Item { 
    Registro registro; 
    struct Item *proximo; 
};

struct Fila 
{ 
    Item *inicio; 
    Item *fim; 
};

Fila *q;
void Inicializar(Fila* *fila) 
{ 
    // -> Recebe a fila por referencia 
    //    para inicializ�-la 
    *fila = (Fila *) malloc(sizeof(Fila)); 
    (*fila)->inicio = NULL; 
    (*fila)->fim = NULL; 
}

int EstaVazia(Fila *fila) 
{ 
    return fila->inicio == NULL; 
}

void Inserir(Fila *fila, Registro elemento) { 
    Item *novo; 
    novo = (Item *)malloc(sizeof(Item));  

    // -> Verifica se a mem�ria foi alocada com sucesso 
    if (novo != NULL) 
    { 
        strcpy(novo->registro.comp, elemento.comp);
		strcpy(novo->registro.dia, elemento.dia);  
        novo->registro.chave = elemento.chave; 
        novo->proximo = NULL;

        if(EstaVazia(fila)) 
        { 
            // -> Primeiro Item da Fila. 
            fila->inicio = novo; 
            fila->fim = novo; 
        } 
        else 
        { 
            // -> Ultimo item da Fila 
            fila->fim->proximo = novo; 
            fila->fim=novo; 
        } 
    } 
}

void Retirar(Fila *fila) 
{ 
    Item *item;

    if(!EstaVazia(fila)) 
    { 
        item = fila->inicio; 
        fila->inicio = item->proximo; 
        free(item);

        // -> Se a fila acabou devemos atualizar o final 
        if (fila->inicio == NULL) 
            fila->fim = NULL; 
    } 
}

void MostrarFila(Fila *fila) 
{ 
    int i = 0; 
    Item *item; 
   
    printf("\n\n Listando...\n\n"); 
    printf("---------------------------------\n");

    if (EstaVazia(fila)) 
    { 
        printf ("A Fila esta vazia!\n"); 
    } 
    else 
    {       
        item = fila->inicio;

        while(item != NULL) 
        { 
            i++; 
            printf("[%i] -> Commpromisso %i: %s ||| dia: %s \n", i, item->registro.chave, item->registro.comp,item->registro.dia); 
            item = item->proximo; 
        } 
    }
    

    printf("---------------------------------\n"); 
}

int Fila_Tamanho(Fila *fila){
/*Retorna o tamanho da fila*/
int cont = 0;
Item *item;
item = fila->inicio;
	while (item!= NULL){
	cont ++;
	item = item->proximo;
	}
	return cont;
	printf("\n\nTamanho: %d \n\n",cont);
}
int consulta(Fila* fila) {
  int valor;
  if(EstaVazia(fila)) {
      printf("FILA VAZIA!\n");
      return 0 ;
      }
  else {
  	
      printf("PRIMEIRO ELEMENTO: %d\n", q->inicio->registro.chave);
       
      return 1;
      }
  }



void Menu() 
{ 
    	printf ("|================================|\n");
		printf ("|       SELECINE UMA OPCAO       |\n");
		printf ("|1. Para cadastrar um compromisso|\n");
		printf ("|2.  Listar os compromissos      |\n");
		printf ("|3.  Remover os compromissos     |\n");
		printf ("|4.  Tamanho da Lista      	  |\n");
		printf ("|5.  Localizar compromisso    	  |\n");
		printf ("|6.  Encerrar compromissos       |\n");
		printf ("|================================|\n");
			printf(" Selecione uma opcao por favor: ");
}



int main() 
{    
    Fila *fila = NULL; 

    int opcao,i,cont=0; 
	Registro registro;

    Inicializar(&fila); 
    Menu(); 
    scanf("%i", &opcao);

    while (opcao != 7) 
    {

        switch (opcao) 
        { 
            case 1: 
                printf( "Digite um codigo para o compromisso: "); 
                scanf("\n%i", &registro.chave);
	            printf( "\nDigite o dia: "); 
                scanf("\n%s",&registro.dia);
				printf( "Digite o compromisso: "); 
                scanf("\n%s",&registro.comp);

                Inserir(fila, registro); 
                printf("\n\n-----------Compromisso Registrado------------\n\n");
                //MostrarFila(fila);

                break; 
            case 2: 
              MostrarFila(fila);
              

                break;
            case 3:
            	Retirar(fila); 
            	MostrarFila(fila);
            	break;
			case 4:
				Fila_Tamanho(fila);
				printf("\n\nTamanho da agenda: %d \n\n",Fila_Tamanho(fila));
				break;
			case 5:
				consulta(fila);
				printf("Compromisso  Encontrado: %d",consulta(fila));
				
            default: 
                printf( "Escolha invalida.\n\n"); 
                Menu(); 
                break; 
        }

        scanf("%i", &opcao);
	

     
    }

    system("pause"); 
}
