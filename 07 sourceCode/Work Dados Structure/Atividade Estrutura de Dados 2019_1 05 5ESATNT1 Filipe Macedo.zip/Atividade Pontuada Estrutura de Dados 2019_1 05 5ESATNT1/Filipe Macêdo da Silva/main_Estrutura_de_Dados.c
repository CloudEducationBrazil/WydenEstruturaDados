#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <locale.h>
#include <time.h>


//Aluno:Filipe Mac�do da Silva
//Matricula:152030269

/* ========================================================================= */
/*Controle de Acesso Acad�mico de Alunos*/
/* ========================================================================= */


typedef struct{
	int dia;
	int mes;
	int ano;
}TipoData;

typedef int TipoChave;

//ITENS
typedef struct{
	//*************************Controle de Acesso*****************************
	TipoChave chave; //Chave, ID...
	char matricula[15]; // Matr�cula do Aluno.
	char Ocorrencia[20]; // Descri��o da Ocorr�ncia (Esqueceu/Perdeu/NaoPossui/Outros cart�o).
	char Porteiro[20]; // Nome Porteiro
	TipoData dataAcesso; // Data de Acesso
	//********************Agenda de Compromissos****************************
	TipoData dataCompromisso; // Data Compromisso
    char Compromisso[300]; // Descri��o
    TipoChave inteiros; // n�meros
} TipoItem;

typedef struct TipoCelula *TipoApontador;

typedef struct TipoCelula {
  TipoItem item;
  TipoApontador Prox;
} TipoCelula;

typedef struct {
  TipoApontador Primeiro, Ultimo;
  int Tamanho;   //CONTADADOR PARA TAMANHDO DA LISTA
} TipoLista;

/* ========================================================================= */

//CRIA UMA LISTA*********************************************************
void FazLista(TipoLista *lista)
{ lista -> Primeiro = (TipoApontador) malloc(sizeof(TipoCelula));
  lista -> Ultimo = lista -> Primeiro;
  lista -> Primeiro -> Prox = NULL;
  lista -> Tamanho = 0;
}

//VERIFICA SE EST� VAZIA*************************************************
int Vazia(TipoLista lista){
	return (lista.Primeiro == lista.Ultimo);
}

//RETORNA QUANTIDADE DE ELEMENTOS NA LISTA*******************************

int Tamanho(TipoLista lista)
{return (lista.Tamanho); }

//INSERE ELEMENTO NA LISTA***********************************************
void Insere(TipoItem x, TipoLista *lista){
	lista->Ultimo->Prox = (TipoApontador)malloc(sizeof(TipoCelula));
	lista->Ultimo = lista->Ultimo->Prox;
	lista->Ultimo->item = x;
	lista->Ultimo->Prox = NULL;
	lista->Tamanho ++;
}

//EXIBIR ELEMENTOS DA LISTA (CONTROLE DE ACESSO)**********************************************
void ImprimeLista(TipoLista lista){
	TipoApontador aux;
	
	if(Vazia(lista)){
		printf("Erro Lista Esta VAZIA!!!\n");
		return;
	}
	
	aux = lista.Primeiro->Prox;
	
	while(aux != NULL){
		printf("ID:%d\n", aux->item.chave);
		printf("\tData de Acesso: %d/%d/%d\n", aux->item.dataAcesso.dia, aux->item.dataAcesso.mes, aux->item.dataAcesso.ano);
		printf("\tPorteiro Responsavel: %s", aux->item.Porteiro);
		printf("\tMatricula: %s", aux->item.matricula);
		printf("\tOcorrencia: %s\n", aux->item.Ocorrencia);
        aux = aux -> Prox;
	}
}

//EXIBIR ELEMENTOS DA LISTA (AGENDA DE COMPROMISSOS)**********************************************
void ImprimeLista1(TipoLista lista){
	TipoApontador aux;
	
	if(Vazia(lista)){
		printf("Erro Agenda Esta VAZIA!!!\n");
		return;
	}
	
	aux = lista.Primeiro->Prox;
	
	while(aux != NULL){
		printf("ID:%d\n", aux->item.chave);
		printf("\tData Compromisso: %d/%d/%d\n", aux->item.dataCompromisso.dia, aux->item.dataCompromisso.mes, aux->item.dataCompromisso.ano);
		printf("\tDescricao do Compromisso: %s", aux->item.Compromisso);
        aux = aux -> Prox;
	}
}

//EXIBIR ELEMENTOS DA FILA (INSER��O DE NUMEROS)**********************************************
void ImprimeLista2(TipoLista lista){
	TipoApontador aux;
	
	if(Vazia(lista)){
		printf("Erro Fila Esta VAZIA!!!\n");
		return;
	}
	
	aux = lista.Primeiro->Prox;
	
	while(aux != NULL){
		printf("ID:%d\n", aux->item.chave);
		printf("Numero : %d\n", aux->item.inteiros);
        aux = aux -> Prox;
	}
}

//VERIFICAR SE ELEMENTO CONSTA NA LISTA**********************************
TipoApontador BuscaLista(TipoLista *lista, TipoChave chave){
	TipoApontador aux = lista->Primeiro;
	
	while(aux != NULL){
		if(aux->item.chave == chave) return aux;
		aux = aux->Prox;
	}
	return NULL;
}

//BUSCAR EXCLUIR*********************************************************

int BuscaRemove(TipoLista *lista, TipoChave chave){
   TipoApontador p, q, aux;
   int i=1;
   
   p = lista->Primeiro;
   q = lista->Primeiro->Prox;
   while (q != NULL && q->item.chave != chave) {
      p = q;
      q = q->Prox;
      
   }
   if (q != NULL) {
      p->Prox = q->Prox;
      free (q);
	  lista->Tamanho--;  
   }
	return 1;
}
//REMOVE ELEMENTO FILA************************************************


int FilaRemove(TipoLista *lista){
	TipoApontador p, q;
    if (Vazia(*lista)) { printf("Erro fila esta vazia\n"); return 0; }
    
	q = lista->Primeiro;
	p = lista->Primeiro->Prox;
   	lista->Primeiro = p;
   	//*item = lista->Primeiro->item;
    free (q);
	lista->Tamanho--;  
	return 1;
}

//DESTROI A ESTRUTURA DE DADOS*********************************************

void ResetLista(TipoLista *lista){
    	TipoApontador aux = lista->Primeiro;
        while (aux != NULL){
            TipoApontador p = aux;
            aux = aux->Prox;
            free(aux);
	    } 
		lista->Primeiro = NULL; 
    }
		    
//REORGANIZAR CHAVE DA LISTA***********************************************
void ResetChave(TipoLista *lista){
	TipoApontador aux = lista->Primeiro;
	TipoItem item;
	int x=0;	
	while(aux != NULL){                                  
		aux->item.chave = x;
		aux = aux->Prox;
		x++;
	}
}
	
void menuprincipal(){
	printf("                ****Bem Vindo ao Menu Pincipal****\n\n");
	printf("   Escolha a Aplicacao Desejada    \n");
  	printf("   1 : Controle de Acesso Academico de Alunos\n");
  	printf("   2 : Agenda de Compromissos\n");
  	printf("   3 : Insercao de Numeros no sistema\n");
  	printf("   4 : Sair da Aplicacao\n");
}
	
	
	
//*************************MENU CONTROLE DE ACESSO***********************************************
void menu(){
  printf("****Controle de Acesso Academico de Alunos****\n");
  printf("             Bem Vindo ao Menu \n");
  printf("   1 : Criar Lista\n");
  printf("   2 : Inserir matricula\n");
  printf("   3 : Buscar\n");
  printf("   4 : Exibir lista de dados\n");
  printf("   5 : Destruir (zerar) lista\n");
  printf("   6 : Verificar Tamanho da Lista \n");
  printf("   7 : Exibir MENU Controle de Acesso\n");
  printf("   8 : Remover \n");
  printf("   9 : Alterar\n");
  printf("   0 : Sair do Programa Controle de Acesso\n");
  
  
  printf("\n");
}

//*************************AGENDA DE COMPROMISSOS***********************************************
void menu1(){
  printf("****Agenda de Compromissos****\n\n");
  printf("       Bem Vindo ao Menu \n");
  printf("   1 : Criar Agenda\n");
  printf("   2 : Inserir Compromisso\n");
  printf("   3 : Buscar\n");
  printf("   4 : Exibir lista de Compromissos\n");
  printf("   5 : Destruir (zerar) Agenda\n");
  printf("   6 : Verificar Tamanho da Agenda \n");
  printf("   7 : Exibir MENU Agenda\n");
  printf("   8 : Remover \n");
  printf("   9 : Alterar\n");
  printf("   0 : Sair do Programa\n");
  printf("   0 : Ir Para Programa Insercao de Numeros Inteiros\n");
  
  printf("\n");
}

//*************************INSER��O DE CHAVES***********************************************
void menu2(){
  printf("****Insercao de Numeros Inteiros****\n");
  printf("    Bem Vindo ao Menu \n");
  printf("   1 : Criar Fila\n");
  printf("   2 : Inserir Numero\n");
  printf("   3 : Buscar\n");
  printf("   4 : Exibir Fila de dados\n");
  printf("   5 : Destruir (zerar) Fila\n");
  printf("   6 : Verificar Tamanho da Fila \n");
  printf("   7 : Exibir MENU Insercao de Numeros\n");
  printf("   8 : Remover \n");
  printf("   9 : Alterar\n");
  printf("   0 : Sair do Programa\n");
  
  printf("\n");
}


int y=1;
//*************************************************BUSCAR ALTERAR CONTROLE DE ACESSO*********************************************************

TipoApontador BuscaAltera(TipoLista *lista, TipoChave chave){
	TipoApontador aux = lista->Primeiro;
	TipoItem item;
	int opc = -1;
	
	while(aux != NULL){                                  
		if(aux->item.chave == chave){
			do{
				system("CLS");
				printf("****Escolha qual dado quer alterar****\n");
				printf("   1 : Matricula\n");
            	printf("   2 : Ocorrencia\n");
	            printf("   3 : Voltar MENU\n");
	            
				printf("Digite Opcao de Alteracao: ");
	            scanf("%d",&opc);
		        printf("\n");
				
			    switch(opc) {
			        case 1:
			        	printf("Digite o Novo Numero de Matricula: ");
	                    fflush(stdin);                               
	                    fgets(aux->item.matricula, 15, stdin);
			    	    break;
			        case 2:
			    		printf("Digite a Nova Ocorrencia: ");
	                    fflush(stdin);                               
	                    fgets(aux->item.Ocorrencia, 15, stdin);
			    	    break;
			    	case 3:
			    		menu();
			    		opc=0;
			    		break;
    			}
			}while(opc !=0);
		}else printf("Chave incorreta ou nao se encontra na lista\n");
		
		aux = aux->Prox;
	}
	
	return NULL;
	
}


//****************************************************BUSCAR ALTERAR PARA AGENDA*********************************************************

TipoApontador BuscaAltera1(TipoLista *lista, TipoChave chave){
	TipoApontador aux = lista->Primeiro;
	TipoItem item;
	int opc = -1;
	
	while(aux != NULL){                                  
		if(aux->item.chave == chave){
			do{
				system("CLS");
				printf("****Escolha qual dado quer alterar****\n");
				printf("   1 : Data do Compromisso\n");
            	printf("   2 : Descri��o\n");
	            printf("   3 : Voltar MENU\n");
	            
				printf("Digite Opcao de Alteracao: ");
	            scanf("%d",&opc);
		        printf("\n");
				
			    switch(opc) {
			        case 1:
			        	printf("Dia: ");
			        	scanf("%d", &aux->item.dataCompromisso.dia);
			        	printf("Mes: ");
			        	scanf("%d", &aux->item.dataCompromisso.mes);
			    	    break;
			        case 2:
			    		printf("Digite a Nova Descricao de Compromisso: ");
	                    fflush(stdin);                               
	                    fgets(aux->item.Compromisso, 300, stdin);
			    	    break;
			    	case 3:
			    		menu1();
			    		opc=0;
			    		break;
    			}
			}while(opc !=0);
		}else printf("Chave incorreta ou nao se encontra na lista\n");
		
		aux = aux->Prox;
	}
	
	return NULL;
	
}

//****************************************************BUSCAR ALTERAR PARA INSER��O DE INTEIROS*********************************************************

TipoApontador BuscaAltera2(TipoLista *lista, TipoChave chave){
	TipoApontador aux = lista->Primeiro;
	TipoItem item;
	int opc = -1;
	
	while(aux != NULL){                                  
		if(aux->item.chave == chave){
			do{
				system("CLS");
				printf("****Escolha a opcao desejada****\n");
				printf("   1 : Alterar Numero\n");
	            printf("   2 : Voltar MENU\n");
	            
				printf("Digite Opcao de Alteracao: ");
	            scanf("%d",&opc);
		        printf("\n");
				
			    switch(opc) {
			        case 1:
			        	printf("Novo Numero: ");
			        	scanf("%d", &aux->item.inteiros);
			    	    break;
			    	case 2:
			    		menu1();
			    		opc=0;
			    		break;
    			}
			}while(opc !=0);
		}else printf("Chave incorreta ou nao se encontra na lista\n");
		
		aux = aux->Prox;
	}
	
	return NULL;
	
}

int main() {
	TipoChave ch;
	TipoLista lista, lista1, fila;
	TipoItem item;
	TipoApontador p;
	int opc=-1, opc0=-1, opc1=-1, opc2=-1;
	menuprincipal();
	time_t t;
	struct tm *local;
	

	do{
		printf("\nDigite Opcao do Menu Principal: ");
		scanf("%d",&opc);
		printf("\n");
		switch(opc){
			case 1://***************************************************************CONTROLE DE ACESSO***************************************************************
				menu();
				do{
					
					printf("Digite Opcao para o Controle de Acesso: ");
			        scanf("%d",&opc0);
				    printf("\n");
				    
					switch (opc0) {
						case 1 : FazLista(&lista);    //****************CRIAR*******************
						         if(lista.Primeiro->Prox==NULL){
						         	printf("*****Estrutura Criada com Sucesso*****\n\n");
								}else printf("Nao foi possivel ser criada tente novamente!!\n");
						 
			            case 2 :      //*********************INSERE***************************
							    	           	
			            	printf("Digite o Numero de Matricula: ");
			                fflush(stdin);                                 //INSERIR DADOS NI SISTEMA
			                fgets(item.matricula, 15, stdin);
			                
							printf("Descricao da Ocorrencia (Esqueceu/Perdeu/NaoPossui/Outros cartao)\n");  
							printf("Digite a Ocorrencia: ");
			                fflush(stdin);
			                fgets(item.Ocorrencia, 20, stdin);
			                
			                printf("Porteiro: ");
			                fflush(stdin);
			                fgets(item.Porteiro, 20, stdin);
			                
			                //*********DATA ACESSO***********//
							t= time(NULL);
							local=localtime(&t);	
			                item.dataAcesso.dia=local->tm_mday;
			                item.dataAcesso.mes=local->tm_mon+1;
			                item.dataAcesso.ano=local->tm_year+1900;
			                
			                item.chave = y;
			                Insere(item, &lista);
			                if(item.chave!=NULL){
			                	    system("CLS");
			                	    menu();
			                        printf("Matricula %d inserido com sucesso.\n",item.chave);
			                }else printf("Nao foi possivel inserir matricula.\n \n");
			                y++;
							break; 
							 
			            case 3 :  		//********************BUSCAR*****************************
						    
			                printf("Digite ID "); 
			                scanf("%d",&ch);
			                
			                TipoApontador posicao = BuscaLista(&lista, ch);
			                if (posicao != NULL) {
			                	    system("CLS");                                        //FAZER UMA BUSCA APENAS PARA VERIFICAR DADO
			                	    menu();
			                	printf("Elemento %d encontrado.\n",ch);
			                	printf("ID %d: Matricula:%s Ocorrencia:%s\n",item.chave, item.matricula, item.Ocorrencia);
							}else printf("Nao foi possivel encontrar elemento %d.\n \n",ch);
						    
							break;
			            case 4 : ImprimeLista(lista); break;   //********************EXIBIR*******************
			        
			            case 5 :      //********************************DESTRUIR ESTRUTURA*********************
						    ResetLista(&lista);
			                system("CLS");
			                menu();
			                break;
			            case 6 : 
							printf ("Quantidade de elementos na Lista: %d \n\n", Tamanho(lista));
							break;
				        case 7 : 
				        	system("CLS");
							menu(); 
							break;
			            case 8 : 
						    printf("Digite o ID para remocao: "); 
			                scanf("%d",&ch);
			                BuscaRemove(&lista, ch);
							if (BuscaRemove(&lista, ch)){
			                	system("CLS");
			                	menu();
			                  	printf("Elemento %i excluido corretamente.\n",ch);
			                  	ResetChave(&lista);
								y--;
							} else printf("Nao foi possivel excluir elemento %i.\n \n",ch);
							
							
						    break;
			            case 9 : 
						    printf("Digite o ID para Alteracao: "); 
			                scanf("%d",&ch);
			                BuscaAltera(&lista, ch);
			                system("CLS");
						    break;
				    }
			    }while (opc0 != 0);
				system("CLS");
				menuprincipal();
			break;
			
			
			case 2://*******************************************************AGENDA DE COMPROMISSOS****************************************************
				menu1();
				do{
					
					printf("Digite Opcao para Agenda de Compromissos: ");
			        scanf("%d",&opc1);
				    printf("\n");
				    
					switch (opc1) {
						case 1 : FazLista(&lista1); 
						         if(lista1.Primeiro->Prox==NULL){
						         	printf("*****Agenda Criada com Sucesso*****\n\n");
								}else printf("Nao foi possivel ser criada tente novamente!!\n");
						 
			            case 2 :      //*********************INSERE***************************
							   	           	
			            	printf("Dia do Compromisso: ");
						    scanf("%d", &item.dataCompromisso.dia);
						    printf("Mes: ");
						    scanf("%d", &item.dataCompromisso.mes);
						    t= time(NULL);
							local=localtime(&t);
							item.dataCompromisso.ano=local->tm_year+1900;
			                  
							printf("Descricao do Compromisso: ");
			                fflush(stdin);
			                fgets(item.Compromisso, 300, stdin);
			                
			                item.chave = y;
			                Insere(item, &lista1);
			                if(item.chave!=NULL){
			                	    system("CLS");
			                	    menu1();
			                        printf("Compromisso %d inserido com sucesso.\n",item.chave);
			                }else printf("Nao foi possivel inserir o compromisso.\n \n");
			                y++;
							break; 
							 
			            case 3 : 
						    
			                printf("Digite a chave do Compromisso desejado? "); 
			                scanf("%d",&ch);
			                
			                TipoApontador posicao = BuscaLista(&lista1, ch);
			                if (posicao != NULL) {
			                	    system("CLS");                                        //FAZER UMA BUSCA APENAS PARA VERIFICAR DADO
			                	    menu1();
			                	printf("Compromisso de chave %d encontrado.\n",ch);
			                	printf("\tData Compromisso: %d/%d/%d\n", item.dataCompromisso.dia, item.dataCompromisso.mes, item.dataCompromisso.ano);
			                	printf("\tDescricao do Compromisso", item.Compromisso);
							}else printf("Nao foi possivel encontrar o compromisso %d.\n \n",ch);
						    
							break;
			            case 4 : ImprimeLista1(lista1); break;
			        
			            case 5 : 
						    ResetLista(&lista1);
			                system("CLS");
			                menu1();
			                break;
			            case 6 : 
							printf ("Quantidade de Compromissos na Agenda: %d \n\n", Tamanho(lista1));
							break;
				        case 7 :
							system("CLS"); 
							menu1(); 
							break;
			            case 8 : 
						    printf("Digite a chave para remocao: "); 
			                scanf("%d",&ch);
			                BuscaRemove(&lista1, ch);
							if (BuscaRemove(&lista1, ch)){
			                	system("CLS");
			                	menu1();
			                  	printf("Compromisso %d excluido corretamente.\n",ch);
			                  	ResetChave(&lista1);
								y--;
							} else printf("Nao foi possivel excluir Compromisso %d.\n \n",ch);
							
							
						    break;
			            case 9 : 
						    printf("Digite a chave do Compromisso para Alteracao: "); 
			                scanf("%d",&ch);
			                BuscaAltera1(&lista1, ch);
			                system("CLS");
						    break;
				    }
			    }while (opc1 != 0);
			    system("CLS");
				menuprincipal();
			break;
			
			case 3://****************************************************INSER��O DE CHAVES*************************************************
				menu2();	
				do{
					
					printf("Digite Opcao para Insercao de Numeros: ");
			        scanf("%d",&opc2);
				    printf("\n");
				    
					switch (opc2) {
						case 1 : FazLista(&fila);    //****************CRIAR*******************
						         if(fila.Primeiro->Prox==NULL){
						         	printf("*****Estrutura Fila Criada com Sucesso*****\n\n");
								}else printf("Nao foi possivel ser criada tente novamente!!\n");
						 
			            case 2 :      //*********************INSERE***************************
							    	           	
			            	printf("Digite um Numero para insercao: ");
			                scanf("%d", &item.inteiros);                                 //INSERIR DADOS NI SISTEMA
			                item.chave = y;
			                Insere(item, &fila);
			                if(item.chave!=NULL){
			                	    system("CLS");
			                	    menu2();
			                        printf("Item %d inserido com sucesso.\n",item.chave);
			                }else printf("Nao foi possivel inserir o numero.\n \n");
			                y++;
							break; 
							 
			            case 3 :  		//********************BUSCAR*****************************
						    
			                printf("Digite ID? "); 
			                scanf("%d",&ch);
			                
			                TipoApontador posicao = BuscaLista(&fila, ch);
			                if (posicao != NULL) {
			                	    system("CLS");                                        //FAZER UMA BUSCA APENAS PARA VERIFICAR DADO
			                	    menu();
			                	printf("Elemento %d encontrado.\n",ch);
			                	printf("ID %d: Numero: %d\n",item.inteiros);
							}else printf("Nao foi possivel encontrar elemento %d.\n \n",ch);
						    
							break;
			            case 4 : ImprimeLista2(fila); break;   //********************EXIBIR*******************
			        
			            case 5 :      //********************************DESTRUIR ESTRUTURA*********************
						    ResetLista(&fila);
			                system("CLS");
			                menu2();
			                break;
			            case 6 : 
							printf ("Quantidade de elementos na Fila: %d \n\n", Tamanho(fila));
							break;
				        case 7 : 
							system("CLS"); 
							menu2(); 
							break;
			            case 8 : 
			            	
						    FilaRemove(&fila);
							if (FilaRemove(&fila)){
			                	system("CLS");
			                	menu2();
			                  	printf("Elemento da Fila excluido corretamente.\n");
			                  	ResetChave(&fila);
								y--;
							} else printf("Nao foi possivel excluir elemento %d.\n \n");
						
							
						    break;
			            case 9 : 
						    printf("Digite o ID para Alteracao: "); 
			                scanf("%d",&ch);
			                BuscaAltera2(&fila, ch);
			                system("CLS");
						    break;
				    }
			    }while (opc2 != 0);
				system("CLS");
				menuprincipal();
			break;
		}
		
	}while (opc != 0);
	
	
	return 0;
}
