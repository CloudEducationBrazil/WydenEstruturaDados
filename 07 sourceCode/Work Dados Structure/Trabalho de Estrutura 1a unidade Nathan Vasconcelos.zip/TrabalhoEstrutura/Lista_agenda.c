#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 50
#define false 0
#define true 1

typedef int TIPOCHAVE;

typedef struct{
   int dia;
   int mes;
   int ano;
}S_data;

typedef struct{ 
   TIPOCHAVE ch;                
   S_data data;
   char descricaoCompromisso[300]; 
} REGISTRO;

typedef struct { 
   REGISTRO A[MAX];
   int nroElemento;
} LISTA;

void menu();
void inicializaLista(LISTA* l);
void tamanhoLista(LISTA* l);
void exibeLista(LISTA* l);
bool inserirLista(LISTA* l, REGISTRO reg, int posicao);
bool alterarLista(LISTA *l, REGISTRO reg, int posicao);
bool excluirLista(LISTA* l, TIPOCHAVE ch);
int buscarLista(LISTA* l, TIPOCHAVE ch);
void SalvarLista(LISTA* l);
void CarregarLista(LISTA* l);

int main(){
	REGISTRO reg;
	LISTA l; 

	inicializaLista(&l);	
	int opc;
	int posicao;
	int ch;
	
	do {
		menu();
	    printf("Faca sua escolha: "); scanf("%d", &opc);
	    switch (opc) {
	    	case 0: printf("Agenda inicializada!\n"); inicializaLista(&l); break;
	    	case 1: printf("Tamanho da agenda!\n"); tamanhoLista(&l); break;
	    	case 2: printf("Exibindo a agenda!\n"); exibeLista(&l); break;

	    	case 3: printf("Informe o ID do evento:");
			        scanf("%d", &reg); 
			        printf("Informe a data do evento (DD/MM/AA):");
			        scanf("%d %d %d", &reg.data.dia, &reg.data.mes, &reg.data.ano); 
			        printf("Informe a descricao do evento:");
			        fflush(stdin); gets(reg.descricaoCompromisso);
	    	        printf("Informe a posicao? (Inicie com 0)");scanf("%d", &posicao); 
			        if ( inserirLista(&l, reg, posicao) == true ) printf ("Compromisso inserido!"); 
					else printf("Posicao invalida. Nao houve evento inserido nesta posicao"); 
					break;

	    	case 4: printf("Digite o ID a ser alterado:");
			        scanf("%d", &ch); 
			        printf("Informe a nova data do evento (DD/MM/AA):");
			        scanf("%d %d %d", &reg.data.dia, &reg.data.mes, &reg.data.ano); 
			        printf("Informe a nova descricao do compromisso:");
			        fflush(stdin); gets(reg.descricaoCompromisso);
			        printf("Digite Posicao a ser alterada:"); scanf("%d", &posicao); 
					if (alterarLista(&l, reg, posicao) == true ) printf("Elemento alterado!"); 
					else printf("Posicao invalida!"); 
					break;

	    	case 5: printf("Informe o ID do evento a ser excluido?");
			        scanf("%d", &ch); 
				    if (excluirLista(&l, ch) == true) printf("Evento excluido!"); 
					else printf("Evento nao encontrado!"); 
					break;
				    
	    	case 6: printf("Informe o ID do evento a ser consultado?");scanf("%d", &ch);
			        if ( buscarLista(&l, ch) >= 0 ) printf("\n Registro encontrado"); 
					else printf("\n Registro nao encontrado"); 
					break;
					
			case 7: SalvarLista(&l);
			        break;
			
			case 8: CarregarLista(&l);
			        break;
			        
	    	case 9: exit(1); break;
	    	default:
	        printf("Opcao Invalida\n");
			}
			printf("\n\n");
		    system("PAUSE");  
	   } while ( opc != 9 );
	return 0;
}

void menu() {
		system("CLS");
		printf("BEM-VINDO A AGENDA DE COMPROMISSOS! \n");
		printf("0 - Inicializar agenda \n");
		printf("1 - Exibir Tamanho da agenda \n");
		printf("2 - Exibir lista de compromissos \n");
		printf("3 - Inserir compromisso na agenda \n");
		printf("4 - Alterar compromissos \n");
		printf("5 - Excluir compromisso \n");
		printf("6 - Buscar compromisso na lista (VIA ID) \n");
		printf("7 - Salvar agenda \n");
		printf("8 - Carregar agenda \n");
		printf("9 - Sair da agenda \n");
};

void inicializaLista(LISTA* l) {
	l->nroElemento = 0;
}

void tamanhoLista(LISTA* l){
	printf("\nA quantidade de elementos na agenda eh: = %d \n", l->nroElemento);
}

void exibeLista(LISTA* l){
    printf("\n\n");
    if ( l->nroElemento == 0 ) printf("Agenda vazia!\n");

	for (int i = 0; i<l->nroElemento; i++){
	  printf("ID do evento [%d]=%d\n", i, l->A[i].ch);
	  printf("Data do evento =%d/%d/%d\n", l->A[i].data.dia, l->A[i].data.mes, l->A[i].data.ano);
	  printf("Evento =%s\n", l->A[i].descricaoCompromisso);
	  }
	  
    if ( l->nroElemento < MAX)
	  printf("\n A proxima posicao livre da agenda eh = %d", l->nroElemento);
	else
	  printf("\n Agenda preenchida!");
};

bool inserirLista(LISTA* l, REGISTRO reg, int posicao){
 	if (l->nroElemento == MAX || posicao > l->nroElemento || posicao < 0 || posicao > MAX) return false;
 
 	for (int i = l->nroElemento; i > posicao; i--)
 	  l->A[i] = l->A[i-1];
 	  
 	l->A[posicao] = reg;
 	l->nroElemento++;
 	return true;  
 }

bool alterarLista(LISTA* l, REGISTRO reg, int posicao){
 	if (posicao < 0 || posicao > MAX || posicao > l->nroElemento-1 || l->nroElemento == 0) return false;
 	l->A[posicao]=reg;
 	return true;  
 }

bool excluirLista(LISTA* l, TIPOCHAVE ch){
    int posicao = buscarLista(l, ch);
    if (posicao == -1) return false;
    
    for (int i = posicao; i < l->nroElemento-1; i++)
	  l->A[i] = l->A[i+1];
 	
	l->nroElemento--;
    return true;
 }
 
 int buscarLista(LISTA* l, TIPOCHAVE ch){
 	for (int posicao=0; posicao < l->nroElemento; posicao++)
 	  if (ch == l->A[posicao].ch)
	    return posicao;
	return -1;
 }
 
 void SalvarLista(LISTA* l){
	int i;
	FILE *File;
	File = fopen("agenda.txt","w");
	if(File == NULL){
	  perror("Erro:");
	  getchar();
	  exit(1);
	}
	for(i=0;i<l->nroElemento;i++){	
       fprintf(File,"Chave: %d\n Evento: %s\n Data do Evento: %d/%d/%d \n", l->A[i].ch,l->A[i].descricaoCompromisso,l->A[i].data.dia,l->A[i].data.mes,l->A[i].data.ano);
	}
	fclose(File);
	system("cls");
	printf("Agenda salva em .txt!");
}
 
 void CarregarLista(LISTA* l){
	int i;
	printf("Lista:");
	for (i=0; i < l->nroElemento; i++){
		printf("Chave: %d", l->A[i].ch);
		
	}
	}


