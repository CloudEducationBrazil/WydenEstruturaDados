#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define ERRO -1
#define true 1
#define false 0
#define MAX 50

typedef int TIPOCHAVE;

typedef struct {
  TIPOCHAVE chave;
} REGISTRO;

typedef struct {
  REGISTRO A[MAX];
  int inicio;
  int nroElemento;
} FILA;

void menu();
void inicializaFila(FILA* f);
int tamanhoFila(FILA* f);
void exibeFila(FILA* f);
bool inserirFila(FILA* f, REGISTRO reg);
bool excluirFila(FILA* f, REGISTRO* reg);
int buscarFila(FILA* f, TIPOCHAVE ch);
void salvarFila(FILA* f);
void carregarFila(FILA* f);
void reinicializarFila(FILA* f);

int main(){
	REGISTRO reg;
	FILA f; 
	TIPOCHAVE ch;
	inicializaFila(&f);	
	int opc;
	do {
		menu();
	    printf("Faca sua escolha: "); scanf("%d", &opc);
	    switch (opc) {
	    	case 0: printf("Sistema inicializado!"); inicializaFila(&f); break;
	    	case 1: printf("Tamanho do sistema!"); tamanhoFila(&f); break;
	    	case 2: printf("Exibindo fila!"); exibeFila(&f); break;
	    	
	    	case 3: printf("[Inserindo elemento]Informe o ID de controle:");
	    	        scanf("%d", &reg);
			        if (inserirFila(&f, reg) == true ) printf ("Elemento inserido!"); 
					else printf("Posicao invalida. Nao houve evento inserido nesta posicao"); 
					break;

	    	case 4: printf("[Excluindo primeiro elemento...]");
				    if (excluirFila(&f, &reg) == true) printf("Elemento excluido!"); 
					else printf("Elemento nao encontrado!"); 
					break;
				    
	    	case 5: printf("[Consultando elemento]Informe o ID do acesso a ser consultado?");scanf("%d", &ch);
			        if ( buscarFila(&f, ch) >= 0 ) printf("\n Registro encontrado"); 
					else printf("\n Registro nao encontrado"); 
					break;
					
			case 6: salvarFila(&f);
			        break;
			
			case 7: carregarFila(&f);
			        break;
			        
			case 8: reinicializarFila(&f);
			break;
			        
	    	case 9: exit(1); break;
	    	default:
	        printf("Opcao Invalida\n");
			}
			printf("\n\n");
		    system("PAUSE");  
	   } while ( opc != 9 );
	return 0;
}

void menu() {
		system("CLS");
		printf("BEM-VINDO AO SISTEMA! \n");
		printf("0 - Inicializar sistema \n");
		printf("1 - Exibir numero de elementos \n");
		printf("2 - Exibir fila\n");
		printf("3 - Inserir\n");
		printf("4 - Excluir\n");
		printf("5 - Buscar acesso\n");
		printf("6 - Salvar\n");
		printf("7 - Carregar\n");
		printf("8 - Reinicializar\n");
		printf("9 - Sair do sistema \n");
};

void inicializaFila(FILA* f){
  f->inicio=0;
  f->nroElemento=0;
} 

int tamanhoFila(FILA* f) {
  return f->nroElemento;
} 

void exibeFila(FILA* f){
   printf("Fila de numeros: ");
   int i = f->inicio;
   int temp;
   for (temp = 0; temp < f->nroElemento; temp++){
      printf("%i ", f->A[i].chave); 
      i = (i + 1) % MAX;
    }
}

bool inserirFila(FILA* f, REGISTRO reg) {
if (f->nroElemento >= MAX) return false;
int posicao = (f->inicio + f->nroElemento) % MAX;
f->A[posicao] = reg;
f->nroElemento++;
return true;
}

bool excluirFila(FILA* f, REGISTRO* reg) {
if (f->nroElemento==0) return false;
*reg = f->A[f->inicio];
f->inicio = (f->inicio+1) % MAX;
f->nroElemento--;
return true;
}

int buscarFila(FILA* f, TIPOCHAVE ch){
   int i = f->inicio;
   int temp;
   for (temp = 0; temp < f->nroElemento; temp++){
      if (f->A[i].chave == ch) return i;
      i = (i + 1) % MAX;
    }
  return ERRO;
}

 void salvarFila(FILA* f){
	int i;
	FILE *File;
	File = fopen("Fila.txt","w");
	if(File == NULL){
	  perror("Erro:");
	  getchar();
	  exit(1);
	}
	for(i=0;i<f->nroElemento;i++){	
       fprintf(File,"Chave: %d\n", f->A[i].chave);
	}
	fclose(File);
	system("cls");
	printf("Fila salva em .txt!");
}
 
 void carregarFila(FILA* f){
	int i;
	printf("Lista:");
	for (i=0; i < f->nroElemento; i++){
		printf("Chave: %d", f->A[i].chave);
		}	
	}

void reinicializarFila(FILA* f) {
f->inicio=0;
f->nroElemento=0;
}


