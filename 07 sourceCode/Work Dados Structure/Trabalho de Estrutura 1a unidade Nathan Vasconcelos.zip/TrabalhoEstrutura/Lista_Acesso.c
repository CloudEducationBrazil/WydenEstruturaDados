#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX 50
#define false 0
#define true 1

typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
}S_data;

typedef struct {
	S_data data;
	char nomePorteiro[200]; 
}dadosHeaderf;

typedef struct{ 
   TIPOCHAVE chave;
	char matricula[20];
	char TipoOcorrencia[12]; 
}REGISTRO;

typedef struct { 
   REGISTRO A[MAX];
   int nroElemento;
}LISTA;

void menu();
void inicializaLista(LISTA* l);
void tamanhoLista(LISTA* l);
void exibeLista(LISTA* l);
bool inserirLista(LISTA* l, REGISTRO reg, int posicao);
bool alterarLista(LISTA *l, REGISTRO reg, int posicao);
bool excluirLista(LISTA* l, TIPOCHAVE ch);
int buscarLista(LISTA* l, TIPOCHAVE ch);
void SalvarLista(LISTA* l, dadosHeaderf *dados);
void CarregarLista(LISTA* l);

int main(){
	REGISTRO reg;
	LISTA l; 
	TIPOCHAVE ch;
	dadosHeaderf dados;
	inicializaLista(&l);	
	int opc;
	int posicao;
	printf("Informe o nome do porteiro: ");
	gets(dados.nomePorteiro);
	printf("Informe a data atual (DD/MM/AA):");
	scanf("%d %d %d", &dados.data.dia, &dados.data.mes, &dados.data.ano); 
	do {
		menu();
	    printf("Faca sua escolha: "); scanf("%d", &opc);
	    switch (opc) {
	    	case 0: printf("Sistema inicializado!\n"); inicializaLista(&l); break;
	    	case 1: printf("Tamanho do sistema!\n"); tamanhoLista(&l); break;
	    	case 2: printf("Exibindo acessos!\n"); exibeLista(&l); break;
	    	
	    	case 3: printf("Informe o ID de controle:");
			        scanf("%d", &reg); 
			        printf("Informe a matricula do aluno:");
			        fflush(stdin); gets(reg.matricula);
			        printf("Informe o tipo de ocorrencia: (Esqueceu/Perdeu/NaoPossui/OutroCartao)");
			        fflush(stdin); gets(reg.TipoOcorrencia);
	    	        printf("Informe a posicao? (Inicie com 0)");scanf("%d", &posicao); 
			        if ( inserirLista(&l, reg, posicao) == true ) printf ("Acesso inserido!"); 
					else printf("Posicao invalida. Nao houve acesso inserido nesta posicao"); 
					break;

	    	case 4: printf("Digite o ID do acesso a ser alterado:");
			        scanf("%d", &ch); 
			        printf("Informe a nova matricula do aluno:");
			        fflush(stdin); gets(reg.matricula);
			        printf("Informe o novo tipo de ocorrencia: (Esqueceu/Perdeu/NaoPossui/OutroCart�o)");
			        fflush(stdin); gets(reg.TipoOcorrencia);
			        printf("Digite Posicao a ser alterada:"); scanf("%d", &posicao); 
					if (alterarLista(&l, reg, posicao) == true ) printf("Elemento alterado!"); 
					else printf("Posicao invalida!"); 
					break;

	    	case 5: printf("Informe o ID do acesso a ser excluido?");
			        scanf("%d", &ch); 
				    if (excluirLista(&l, ch) == true) printf("Acesso excluido!"); 
					else printf("Acesso nao encontrado!"); 
					break;
				    
	    	case 6: printf("Informe o ID do acesso a ser consultado?");scanf("%d", &ch);
			        if ( buscarLista(&l, ch) >= 0 ) printf("\n Registro encontrado"); 
					else printf("\n Registro nao encontrado"); 
					break;
					
			case 7: SalvarLista(&l, &dados);
			        break;
			
			case 8: CarregarLista(&l);
			        break;
			        
	    	case 9: exit(1); break;
	    	default:
	        printf("Opcao Invalida\n");
			}
			printf("\n\n");
		    system("PAUSE");  
	   } while ( opc != 9 );
	return 0;
}

void menu() {
		system("CLS");
		printf("BEM-VINDO AO SISTEMA DE CONTROLE DE ACESSO! \n");
		printf("0 - Inicializar sistema \n");
		printf("1 - Exibir numero de acessos \n");
		printf("2 - Exibir lista de acessos\n");
		printf("3 - Inserir acesso no sistema \n");
		printf("4 - Alterar acesso \n");
		printf("5 - Excluir acesso \n");
		printf("6 - Buscar acesso na lista (VIA ID) \n");
		printf("7 - Salvar lista de acessos \n");
		printf("8 - Carregar acessos realizados \n");
		printf("9 - Sair do sistema \n");
};

void inicializaLista(LISTA* l) {
	l->nroElemento = 0;
}

void tamanhoLista(LISTA* l){
	printf("\nA quantidade de elementos no sistema eh: = %d \n", l->nroElemento);
}

void exibeLista(LISTA* l){
	int i;
    printf("\n\n");
    if ( l->nroElemento == 0 ) printf("Sistema vazio!\n");

	for (int i = 0; i<l->nroElemento; i++){
	  printf("ID de controle [%d]=%d\n", i, l->A[i].chave);
	  printf("Matricula =%s\n", l->A[i].matricula);
	  printf("Elemento =%s\n", l->A[i].TipoOcorrencia);
	  }
	  
    if ( l->nroElemento < MAX)
	  printf("\n A proxima posicao livre do controle eh = %d", l->nroElemento);
	else
	  printf("\n Controle preenchido!");
};

bool inserirLista(LISTA* l, REGISTRO reg, int posicao){
 	if (l->nroElemento == MAX || posicao > l->nroElemento || posicao < 0 || posicao > MAX) return false;
 
 	for (int i = l->nroElemento; i > posicao; i--)
 	  l->A[i] = l->A[i-1];
 	  
 	l->A[posicao] = reg;
 	l->nroElemento++;
 	return true;  
 }

bool alterarLista(LISTA* l, REGISTRO reg, int posicao){
 	if (posicao < 0 || posicao > MAX || posicao > l->nroElemento-1 || l->nroElemento == 0) return false;
 	l->A[posicao]=reg;
 	return true;  
 }

bool excluirLista(LISTA* l, TIPOCHAVE ch){
    int posicao = buscarLista(l, ch);
    if (posicao == -1) return false;
    
    for (int i = posicao; i < l->nroElemento-1; i++)
	  l->A[i] = l->A[i+1];
 	
	l->nroElemento--;
    return true;
 }
 
 int buscarLista(LISTA* l, TIPOCHAVE chave){
 	for (int posicao=0; posicao < l->nroElemento; posicao++)
 	  if (chave == l->A[posicao].chave)
	    return posicao;
	return -1;
 }
 
 void SalvarLista(LISTA* l, dadosHeaderf* dados){
	int i;
	FILE *File;
	File = fopen("acesso.txt","w");
	if(File == NULL){
		perror("Erro:");
		getchar();
		exit(1);
	}
	fprintf(File,"\n Seguranca: %s \n Data: %d/%d/%d\n\n",dados->nomePorteiro, dados->data.dia, dados->data.mes, dados->data.ano);
	for(i=0;i<l->nroElemento;i++){
		
		fprintf(File,"Chave: %d\n Matricula: %s\n Ocorrencia: %s \n", l->A[i].chave, l->A[i].matricula, l->A[i].TipoOcorrencia);
	}
	fclose(File);
	system("cls");
	printf("\n Sistema salvo em .txt!\n");
}
 
 void CarregarLista(LISTA* l){
	int i;
	printf("Lista:\n\n");
	for (i=0; i < l->nroElemento; i++){
		printf(" Chave: %d\n", l->A[i].chave);
		
	}
	}



