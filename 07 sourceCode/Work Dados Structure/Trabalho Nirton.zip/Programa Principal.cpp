//******* FAZER ALTERA��ES NAS LINHAS 24 E 29 **********************


#include <stdio.h>
#include <stdlib.h>

int main(){
	
	int opc;
    opc=0;

    do{
		system("cls");
    	printf("Seja bem vindo ao Menu Principal!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
   		printf("1 - Abrir Questao 02\n");
   		printf("2 - Abrir Questao 03\n");
		printf("9 - Sair\n");		
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    	    case 1:{
    	    	//*********************  COLOCAR O LOCAL ONDE SE ENCONTRA O PROGRAMA "exe." DA QUEST�O 03  ****************************
    	    	system("\"C:\\Users\\nirto\\OneDrive\\Documentos\\MATERIAL GERAL ENG. COMPUTA��O\\III SEMESTRE\\Estrutura de dados\\Trabalho\\Questao 03.exe\"");
				break;
			}
			case 2:{
				//*********************  COLOCAR O LOCAL ONDE SE ENCONTRA O PROGRAMA "exe." DA QUEST�O 02  ****************************
				system("\"C:\\Users\\nirto\\OneDrive\\Documentos\\MATERIAL GERAL ENG. COMPUTA��O\\III SEMESTRE\\Estrutura de dados\\Trabalho\\Questao 02.exe\"");
				break;
			}
			case 9:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opc!=1 && opc!=2);
	
	
return 0;
}

