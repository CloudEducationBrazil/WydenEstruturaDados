//************************************************  FAZER ALTERA��ES NAS LINHAS   ******* 286 ******** 294 ********* 697 *****************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Estruturas

#define MAX_NOME 30

typedef int TIPOCHAVE;

typedef struct{
    TIPOCHAVE Telefone;
    TIPOCHAVE DDD;
    char Nome[MAX_NOME];
} REGISTRO;

typedef struct lista{
    REGISTRO registro;
    struct lista *prox;
} *LISTA;

//Declara��o de Fun��es

void criarLista(LISTA *lista);

int verificar_Numero(LISTA *lista, REGISTRO registro);

void Inserir_Inicio(LISTA *lista, REGISTRO registro);
void Inserir_Final(LISTA *lista, REGISTRO registro);
void Inserir_Posicao(LISTA *lista, REGISTRO registro, int posicao);

int Quantidade_Contatos(LISTA *lista);
void Imprimir_Agenda(LISTA *lista);

void Buscar_Posicao(LISTA *lista, int posicao);
void Buscar_Telefone(LISTA *lista, TIPOCHAVE DDD,TIPOCHAVE Telefone);

void Deletar_Posicao(LISTA *lista, int posicao, int verificador);
void deletar_Telefone(LISTA *lista, TIPOCHAVE DDD, TIPOCHAVE Telefone);

void Editar_Agenda(LISTA *lista, int posicao);

void reiniciarLista(LISTA *lista);

void gravarArquivo(LISTA *lista);
void abrir_Arquivo();

//PROGRAMA PRINCIPAL;

int main(){
    LISTA lista;
    REGISTRO registro;
    TIPOCHAVE Telefone;
    TIPOCHAVE DDD;
    int opc, posicao, opcAux, tamanho;
    opc=0;

    do{
		system("cls");
    	printf("Seja bem vindo ao Menu!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
   		printf("1 - Criar Agenda\n");
   		printf("2 - Abrir Agenda\n");
		printf("9 - Sair\n");		
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    	    case 1:{
    	    	criarLista(&lista);
				break;
			}
			case 2:{
				abrir_Arquivo();
				break;
			}
			case 9:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opc!=1 && opc!=2);
			
	do{
        system("cls");
    	printf("Seja bem vindo ao Menu!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
    	printf("1 - Exibir Quantidade de Registros\n");
    	printf("2 - Exibir Registros\n");
    	printf("3 - Buscar\n");
    	printf("4 - Inserir Registro\n");
    	printf("5 - Editar Registro\n");
    	printf("6 - Excluir Registro\n");
    	printf("7 - Gravar Registros em Arquivo\n");
    	printf("8 - Reinicializar a Estrutura\n");
    	printf("9 - Sair\n");
    	printf("10 - Programa Principal\n");
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    	    case 1:{
    	        tamanho = Quantidade_Contatos(&lista);
    	        system("cls");
    	        if(tamanho==0)
    	        	printf("Lista vazia!\n");
    	        else
    	        	printf("Quantidade de Registros: %d\n",tamanho);
    			system("pause");
    	        break;
    	    }	
    	    case 2:{
    	    	Imprimir_Agenda(&lista);
				break;
			}
			case 3:{
				system("cls");
    	       	printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Buscar por numero de Telefone\n");
    	       	printf("2 - Buscar por indice da Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	switch(opcAux){
    	    		case 1:{
						printf("Informe o DDD do Telefone: ");
						scanf("%d",&DDD);
						printf("Informe o numero do Telefone: ");
						scanf("%d",&Telefone);
						Buscar_Telefone(&lista,DDD,Telefone);
						break;
					}
					case 2:{
						printf("Informe o indice da Posicao: ");
    	    			scanf("%d",&posicao);
    	    			Buscar_Posicao(&lista,posicao);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 4:{
				system("cls");
    	       	printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Inserir no Inicio\n");
    	       	printf("2 - Inserir no Fim\n");
    	       	printf("3 - Inserir em uma Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	if(opcAux==1 || opcAux==2 || opcAux==3){
    	    		printf("Informe o DDD do Telefone: ");
    	    		scanf("%d",&registro.DDD);
    	    		printf("Informe o numero do Telefone: ");
    	    		scanf("%d",&registro.Telefone);
    	    		printf("Informe o Nome do Contato: ");
    	    		fflush(stdin);
    	    		fgets(registro.Nome,MAX_NOME,stdin);
				}
    	    	switch(opcAux){
    	    		case 1:{
    	    			Inserir_Inicio(&lista,registro);
						break;
					}
					case 2:{
						Inserir_Final(&lista,registro);
						break;
					}
					case 3:{
						printf("Informe o indice da Posicao: ");
						scanf("%d",&posicao);
						Inserir_Posicao(&lista,registro,posicao);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 5:{
				system("cls");
				printf("Informe o indice da Posicao do Registro: ");
				scanf("%d",&posicao);
				Editar_Agenda(&lista,posicao);
				break;
			}
			case 6:{
				system("cls");
				printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Deletar pelo numero do Telefone\n");
    	       	printf("2 - Deletar pelo indice da Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	switch(opcAux){
    	    		case 1:{
						printf("Informe o numero do Telefone:  ");
						scanf("%d",&Telefone);
						deletar_Telefone(&lista,DDD,Telefone);
						break;
					}
    	    		case 2:{
						printf("Informe o indice da Posicao:  ");
						scanf("%d",&posicao);
						Deletar_Posicao(&lista,posicao,0);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 7:{
				gravarArquivo(&lista);
				break;
			}
			case 8:{
				reiniciarLista(&lista);
				break;
			}
			case 9:{
				system("cls");
				printf("Programa sera fechado!\n");
				printf("Deseja gravar os registros em Arquivo?\n");
				printf("0 - SIM\n");
				printf("1 - NAO\n");
    			printf("Opcao: ");
    			scanf("%d",&opcAux);
    			system("cls");
    			switch(opcAux){
    				case 0:{
    					gravarArquivo(&lista);
    					system("cls");
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}
			case 10:{
				system("cls");
				printf("Programa sera fechado!\n");
				printf("Deseja gravar os registros em Arquivo?\n");
				printf("0 - SIM\n");
				printf("1 - NAO\n");
    			printf("Opcao: ");
    			scanf("%d",&opcAux);
    			system("cls");
    			switch(opcAux){
    				case 0:{
    					gravarArquivo(&lista);
    					system("cls");
						printf("Programa encerrado!\n");
						system("pause");
					//*********************  COLOCAR O LOCAL ONDE SE ENCONTRA O PROGRAMA "exe." DO PROGRAMA PRINCIPAL  ****************************
						system("\"C:\\Users\\nirto\\OneDrive\\Documentos\\MATERIAL GERAL ENG. COMPUTA��O\\III SEMESTRE\\Estrutura de dados\\Trabalho\\Programa Principal.exe\"");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						//****************  COLOCAR O LOCAL ONDE SE ENCONTRA O PROGRAMA "exe." DO PROGRAMA PRINCIPAL  *********************
						system("\"C:\\Users\\nirto\\OneDrive\\Documentos\\MATERIAL GERAL ENG. COMPUTA��O\\III SEMESTRE\\Estrutura de dados\\Trabalho\\Programa Principal.exe\"");
						exit(1);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				
				break;
				}
    	    default:{
				system("cls");
				printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
				system("pause");
				break;
			}
		}
	}while(opc!=10);
    return 0;
}

//Fun��es

void criarLista(LISTA *lista){
	*lista = NULL; 
	system("cls");
    printf("Lista criada com sucesso!\n");
    system("pause");
}

int verificar_Numero(LISTA *lista, REGISTRO registro){ 
	LISTA auxiliar; 
	if(*lista==NULL) 
		return 0; 
	else{
		auxiliar = *lista; 
		while((auxiliar!=NULL)&& (registro.Telefone!=auxiliar->registro.Telefone)) 
			auxiliar = auxiliar->prox;
		if(auxiliar==NULL) 
			return 0; 
		else if((registro.Telefone==auxiliar->registro.Telefone)) 
			return 1; 
	}
}

void Inserir_Inicio(LISTA *lista, REGISTRO registro){
	LISTA novo, auxiliar;
	auxiliar = *lista; 
	int verificador = verificar_Numero(&auxiliar,registro); 
	if(verificador==0){
		novo = (LISTA)malloc(sizeof(struct lista)); 
		novo->prox = *lista; 
		*lista = novo; 
		novo->registro = registro; 
		system("cls");
		printf("Registro inserido com sucesso!\n");
		system("pause");
	}else{
		system("cls");
		printf("Numero de Telefone ja inserido na lista!\n");
		system("pause");
	}
}

void Inserir_Final(LISTA *lista, REGISTRO registro){
	LISTA auxiliar, novo; 
	int verificador;
	auxiliar = *lista;
	verificador = verificar_Numero(&auxiliar,registro);
	if(verificador==0){
		if(*lista==NULL)
			Inserir_Inicio(&auxiliar,registro);
		else{ 
			while(auxiliar->prox!=NULL)
				auxiliar = auxiliar->prox; 
			novo = (LISTA)malloc(sizeof(struct lista));
			novo->prox = NULL; 
			auxiliar->prox = novo; 
			novo->registro = registro;
			system("cls");
			printf("Registro inserido com sucesso!\n");
			system("pause");
		}
	}else{
		system("cls");
		printf("Numero de Telefone ja inserido na lista!\n");
		system("pause");
	}
}

void Inserir_Posicao(LISTA *lista, REGISTRO registro, int posicao){
	LISTA auxiliar, anterior, novo;
	int tamanho, cont, verificador;
	auxiliar = *lista;
	tamanho = Quantidade_Contatos(lista); 
	verificador = verificar_Numero(&auxiliar,registro);
	if(verificador==0){
		if(posicao==0) 
			Inserir_Inicio(&(*lista),registro); 
		else if(posicao>=tamanho) 
			Inserir_Final(&(*lista),registro); 
		else{
			cont = 0; 
			while(auxiliar->prox!=NULL && posicao!=cont){
				anterior = auxiliar; 
				auxiliar = auxiliar->prox; 
				cont++;
			}
			novo = (LISTA)malloc(sizeof(struct lista));
			novo->prox = auxiliar; 
			anterior->prox = novo; 
			novo->registro = registro;
			system("cls");
			printf("Registro inserido com sucesso!\n");
			system("pause");
		}
	}else{
		system("cls");
		printf("Numero de Telefone ja inserido na lista!\n");
		system("pause");
	}
}

int Quantidade_Contatos(LISTA *lista){
	LISTA auxiliar;
	int cont=0;
	if(*lista==NULL)
		return 0;
	else{
		auxiliar = *lista;
		while(auxiliar!=NULL){
			auxiliar = auxiliar->prox;
			cont++;
		}
		return cont; 
	}
}

void Imprimir_Agenda(LISTA *lista){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(*lista==NULL) 
		printf("Lista vazia!\n");
	else{ 
		auxiliar = *lista; 
		cont = 0; 
		printf("POSICAO - Telefone - NOME\n");
		while(auxiliar!=NULL){ 
			printf("%03d - (%03d)%d - %s",cont,auxiliar->registro.DDD,auxiliar->registro.Telefone,auxiliar->registro.Nome); 
			auxiliar = auxiliar->prox;
			cont++;
		}
	}
	system("pause");
}

void Buscar_Posicao(LISTA *lista, int posicao){
	LISTA auxiliar;
	int cont, tamanho, opc;
	tamanho = Quantidade_Contatos(&(*lista));
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("pause");
	}
	else if(posicao<tamanho){ 
		auxiliar = *lista;
		cont = 0;
		while(auxiliar!=NULL && posicao!=cont){ 
			auxiliar = auxiliar->prox;
			cont++;
		}
		printf("Registo encontrado!\n");
		printf("POSICAO - Telefone - NOME\n");
		printf("%03d - (%03d)%d - %s\n",posicao,auxiliar->registro.DDD,auxiliar->registro.Telefone,auxiliar->registro.Nome);
		printf("Selecione uma das opcoes abaixo:\n\n");
    	printf("1 - Editar Registro\n");
    	printf("2 - Deletar Registro\n");
    	printf("9 - Sair\n");
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    		case 1:{
    			Editar_Agenda(lista,posicao);
				break;
			}
			case 2:{
				Deletar_Posicao(lista,posicao,0);
				break;
			}
			case 9:{
				system("cls");
				printf("Voce Voltara ao Menu!\n");
				system("pause");
				break;
			}
			default:{
				system("cls");
				printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
				system("pause");
				break;
			}
		}
	}else{
		printf("Registro nao encontrado!\n");
		system("pause");
	}
}

void Buscar_Telefone(LISTA *lista, TIPOCHAVE DDD,TIPOCHAVE Telefone){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("pause");
	}
	else{
		auxiliar = *lista;
		cont = 0;
		while(auxiliar->prox!=NULL && Telefone!=auxiliar->registro.Telefone && DDD!=auxiliar->registro.DDD){
			auxiliar = auxiliar->prox;
			cont++;
		}
		if(Telefone==auxiliar->registro.Telefone && DDD==auxiliar->registro.DDD)
			Buscar_Posicao(lista,cont);
		else{
			printf("Registro nao encontrado!\n");
			system("pause");
		}
	}
}

void Deletar_Posicao(LISTA *lista, int posicao, int verificador){
	LISTA auxiliar, anterior; 
	int cont, tamanho;
	tamanho = Quantidade_Contatos(&(*lista));
	auxiliar = *lista;
	system("cls"); 
	if(*lista==NULL) 
		printf("Lista Vazia!\n");
	else if(posicao==0){ 
			*lista = auxiliar->prox; 
			free(auxiliar);
			if(verificador==0) 
				printf("Registro deletado com sucesso!\n");
	}else if(posicao==tamanho-1){ 
		cont = 0;
		while(auxiliar!=NULL && posicao!=cont){ 
			anterior = auxiliar;
			auxiliar = auxiliar->prox;
			cont++;
		}
		
		anterior->prox = NULL;
		free(auxiliar);
		if(verificador==0)
			printf("Registro deletado com sucesso!\n");
	}
	else if(posicao<tamanho){
		cont = 0;
		while(auxiliar!=NULL && posicao!=cont){
			anterior = auxiliar;
			auxiliar = auxiliar->prox;
			cont++;
		}
		
		anterior->prox = auxiliar->prox;
		free(auxiliar);
		if(verificador==0)
			printf("Registro deletado com sucesso!\n");
	}else
		printf("Registro nao encontrado!\n");
	if(verificador==0)
		system("pause");
}

void deletar_Telefone(LISTA *lista, TIPOCHAVE DDD,TIPOCHAVE Telefone){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("pause");
	}
	else{
		auxiliar = *lista;
		cont = 0;
		while(auxiliar!=NULL && Telefone!=auxiliar->registro.Telefone && DDD!=auxiliar->registro.DDD){
			auxiliar = auxiliar->prox;
			cont++;
		}
		if(Telefone==auxiliar->registro.Telefone && DDD==auxiliar->registro.DDD)
			Deletar_Posicao(lista,cont,0);
		else{
			printf("Registro nao encontrado!\n");
			system("pause");
		}
	}
}

void Editar_Agenda(LISTA *lista, int posicao){ 
	LISTA auxiliar;
	REGISTRO registro;
	int cont, tamanho;
	tamanho = Quantidade_Contatos(&(*lista));
	system("cls");
	if(*lista==NULL)
		printf("Lista Vazia!\n");
	else if(posicao<tamanho){
		auxiliar = *lista;
		cont = 0;
		while(auxiliar!=NULL && posicao!=cont){
			auxiliar = auxiliar->prox;
			cont++;
		}
		printf("Registo encontrado!\n");
		printf("POSICAO - Telefone - NOME\n");
		printf("%03d - (%03d)%d - %s\n",posicao,auxiliar->registro.DDD,auxiliar->registro.Telefone,auxiliar->registro.Nome);
		printf("Informe o DDD do Telefone: ");
		scanf("%d",&registro.DDD);
		printf("Informe o numero do Telefone: ");
		scanf("%d",&registro.Telefone);
		printf("Informe o Nome do Contato: ");
		fflush(stdin);
		fgets(registro.Nome,MAX_NOME,stdin);
		auxiliar->registro = registro;
		system("cls");
		printf("Registro editado com sucesso!\n");
	}else{
		printf("Erro!\n");
		printf("Registro nao encontrado!\n");
	}
	system("pause");
}

void reiniciarLista(LISTA *lista){ 
	int opc, tamanho, i;
	system("cls");
	printf("Voce tem certeza que deseja Reinicializar a Estrurua?\n");
	printf("0 - SIM\n");
	printf("1 - NAO\n");
    printf("Opcao: ");
    scanf("%d",&opc);
    system("cls");
    switch(opc){
    	case 0:{
			tamanho = Quantidade_Contatos(&(*lista));
			for(i=tamanho-1;i>=0;i--)
				Deletar_Posicao(&(*lista),i,1);
			printf("Lista reinicializada com Sucesso!\n");
			break;
		}
		case 1:{
			printf("Voce voltara ao Menu!\n");
			break;
		}
		default:{
			printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
			break;
		}
	}
    system("pause");
}

void gravarArquivo(LISTA *lista){
	FILE *arquivo;
	LISTA auxiliar;
	int i, cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista vazia!\n");
		printf("Arquivo nao sera criado!\n");
	}else{
		arquivo = fopen ("Agenda Telefonica.txt","w");
		if(arquivo==NULL){
			printf("Erro ao criar arquivo.\n");
			system("pause");
		}else{
			auxiliar = *lista;
			cont = 0;
			fprintf(arquivo,"POSICAO - Telefone - NOME\n");
			while(auxiliar!=NULL){
				fprintf(arquivo,"%03d - (%03d)%d - %s",cont,auxiliar->registro.DDD,auxiliar->registro.Telefone,auxiliar->registro.Nome);
				auxiliar = auxiliar->prox;
				cont++;
			}
			printf("\tArquivo gravado com sucesso!\n");
		}
		fclose(arquivo);
	}
	system("pause");
}

void abrir_Arquivo(){
	system("cls");
   
   
	FILE* ArqLista;
	ArqLista = (FILE*) malloc(sizeof(FILE));
//*****************************  COLOCAR O LOCAL ONDE SE ENCONTRA O ARQUIVO ****** "Agenda Telefonica.txt" ***********************************
	ArqLista = fopen("C:/Users/nirto/OneDrive/Documentos/MATERIAL GERAL ENG. COMPUTA��O/III SEMESTRE/Estrutura de dados/Trabalho/Agenda Telefonica.txt", "r");
	char  linha[200];
	char* result;

	if ( ArqLista == NULL ) { printf("Erro ao abrir o arquivo"); };

	while ( !feof(ArqLista) ) {
		result = fgets(linha, 100, ArqLista);

	if ( result )
	printf("%s \n", linha);
	}
	system("pause");
	fclose(ArqLista);
}
