#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include "crudlista.h"
#include "lista.h"

//Inserir um registro na lista
void inserir(LISTA *lista){
	TIPOCHAVE ch;
	REGISTRO registro;
	printf("Digite a chave: "); scanf("%i",&ch);
	printf("Nome:"); fflush(stdin); gets(registro.nome);
	printf("Matricula:"); fflush(stdin); gets(registro.matricula);
	printf("Ocorr�ncia:"); fflush(stdin); gets(registro.ocorrencia);
	registro.chave = ch;
	if (inserirElemetnoListaOrdenado(lista, registro)){
		printf("Aluno de chave %i inserido corretamente.\n",ch);
	}
	else{
		printf("N�o foi possivel inserir aluno de chave %i.\n \n",ch);
	}
	fflush(stdin);
	getchar();  
}
//Consultar se existe aquele registro.
void consultar(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: "); scanf("%i",&ch);
	PONT posicao = buscaSequencialOrd(lista,ch);
	if (posicao != NULL){
		printf("Aluno da chave %i encontrado no endereco %p.\n", ch, posicao);
	}
  	else{
		printf("N�o foi possivel encontrar o aluno de chave %i.\n \n",ch);
	}
	fflush(stdin);
	getchar();
}

/**
	@return void
	Exibe os registros de uma lista.
*/
void exibirElementosLista(LISTA *lista){
	PONT endereco = lista -> inicio;
	printf("\nChaves: ");
	while(endereco !=NULL){
		printf("%i \t", endereco -> registro.chave);
		endereco = endereco -> proximo;
	}
	fflush(stdin);
	getchar();
}

void exibir(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: "); 
	scanf("%i",&ch);
	PONT posicao = buscaSequencialOrd(lista,ch);
	if (posicao != NULL){
		printf("Nome: %s \t Matricula: %s \t Ocorr�ncia: %s \n", 
		posicao->registro.nome, posicao->registro.matricula, posicao->registro.ocorrencia);
	}
  	else{
		printf("N�o foi possivel encontrar o aluno procurado.");
	}
	fflush(stdin);
	getchar();
}
//Listar� todos alunos
void exibirTodos(DADOSHEADERF *dataControle, LISTA *lista){
	printf("Porteiro: %s \n", dataControle -> nomePorteiro);
	printf("Data de abertura: %i/%i/%i\n", dataControle->dataAcesso.dia, dataControle->dataAcesso.mes, dataControle->dataAcesso.ano);
	PONT posicao = lista -> inicio;
	while(posicao != NULL){
		printf("Nome: %s \t Matricula: %s \t Ocorr�ncia: %s \n", 
		posicao->registro.nome, posicao->registro.matricula, posicao->registro.ocorrencia);
		posicao = posicao -> proximo;
	}
	fflush(stdin);
	getchar();
}

void excluir(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: ");
	scanf("%i",&ch);
	if (excluirElementoEmLista(lista,ch)) printf("O aluno de chave %i foi excluido corretamente.\n",ch);
	else printf("N�o foi possivel excluir o registro de chave %i.\n \n",ch);
	getchar();  
}

void alterar(LISTA *lista){
	TIPOCHAVE chave;
	PONT anterior, posicao;
	printf("Digite a chave para o registro que deseja alterar: ");
	scanf("%d", &chave);
	posicao = buscaSenquencialExc(lista, chave, &anterior);
	if(posicao != NULL){
		printf("\nNome: "); fflush(stdin); gets(posicao -> registro.nome);
		printf("\nMatricula: "); fflush(stdin); gets(posicao -> registro.matricula);
		printf("\nMatricula: "); fflush(stdin); gets(posicao -> registro.ocorrencia);
		printf("Registro alterado com sucesso.");
	}else{
		printf("Essa registro n�o esxite para ser alterado.");
	}
	fflush(stdin);
	getchar();
}

void salvar(DADOSHEADERF *dataControle, LISTA *lista, FILE *file){
	file = fopen("Lista.txt", "w");
	fprintf(file, "Nome do porteiro: %s\n", dataControle -> nomePorteiro);
	fprintf(file, "Data de abertura: %i/%i/%i\n", dataControle->dataAcesso.dia, dataControle->dataAcesso.mes, dataControle->dataAcesso.ano);
	dataControle->list = *lista;
	PONT posicao = lista -> inicio;
	while(posicao != NULL){
		fprintf(file, "%i\t %s\t %s\t %s\n", 
		posicao->registro.chave, posicao->registro.nome, posicao->registro.matricula, posicao->registro.ocorrencia);
		posicao = posicao -> proximo;
	}
	fclose(file);
	printf("Lista salva com sucesso!");
	fflush(stdin);
	getchar();
}
// Ajustar o c�digo para somente carregar.
// Fun��o nescess�ria para puxar os dados do arquivo para a mem�ria.
//N�o est� funionando
void carregar(DADOSHEADERF *dataControle, LISTA *lista, FILE *file){
	file = fopen("Lista.txt", "r");
	REGISTRO registro;
	fscanf(file, "Nome do porteiro %100[^\n]");
	fscanf(file, "Data de abertura: %i/%i/%i\n", &dataControle->dataAcesso.dia, &dataControle->dataAcesso.mes, &dataControle->dataAcesso.ano);
	destruir(lista);
	while(!feof(file)){
		fscanf(file, "%d\t %s\t %s\t %20[^\n]", 
		&registro.chave, registro.nome, registro.matricula, registro.ocorrencia);
		if(inserirElemetnoListaOrdenado(lista, registro) == true){
			printf("Dados carragados na mem�ria com sucesso\n");
		}else{
			printf("Erro ao carregar dados na mem�ria\n");
		}
	}
	fclose(file);
	fflush(stdin);
	getchar();
}

void destruir(LISTA *lista){
	reinicializarLista(lista);
	printf("Lista zerada.\n");
	fflush(stdin);
	getchar();
}
//Fun��o para instruir o usu�rio
void help(){
  system("CLS");

  printf("Comandos v�lidos: \n");
  printf("	i : Inserir resgistro na lista\n");
  printf("	x : Excluir resgistro da lista\n");
  printf("	a : Alterar resgistro da lista\n");
  printf("	d : Destruir a lista e reinicializar\n");
  printf("	t : Exibir toda a lista\n");
  printf("	u : Exibir dados de um registro expec�fico\n");
  printf("	h : Consultar se exite a chave desejada na lista\n");
  printf("	s : Salvar a lista\n");
  printf("	c : Carregar a lista\n");
  printf("	l : Tamanho da lista\n");
  printf("	q : Sair do programa\n");
  
  printf("\n");
}
