#ifndef CRUDLISTA_H
#define CRUDLISTA_H
#include "lista.h"

void inserir(LISTA *lista);
void consultar(LISTA *lista);
void exibirElementosLista(LISTA *lista);
void exibir(LISTA *lista);
void exibirTodos(DADOSHEADERF *dataControle, LISTA *lista);
void excluir(LISTA *lista);
void alterar(LISTA *lista);
void salvar(DADOSHEADERF *dataControle, LISTA *lista, FILE *file);
void carregar(DADOSHEADERF *dataControle, LISTA *lista, FILE *file);
void destruir(LISTA *lista);
void help();

#endif
