#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "lista.h"

void inicializarLista(LISTA *lista){
	lista -> inicio = NULL;
}

/**
	Retorna o tamnho da lista, com a quantidade de elementos
*/
int tamanho(LISTA *lista){
	PONT endereco = lista -> inicio;
	int tam = 0;
	while(endereco != NULL){
		tam++;
		endereco = endereco -> proximo;
	}
	return tam;
}

/**
	Lista desordenada.
	Retorna o endere�o de memoria que est� a chave desejada.
	Busca aleat�ria do registro pela chave.
*/
// OBS Fazer uma poss�vel modifica��a para se adaptar ao CRUD
PONT buscaSequencial(LISTA* lista, TIPOCHAVE ch) {
	PONT posicao = lista -> inicio;
	while (posicao != NULL) {
		if (posicao -> registro.chave == ch) {
			return posicao;
		}
		posicao = posicao -> proximo;
	}
	return NULL;
}
/**
	lista ordenada pelos valores das chaves dos registros.
	Retorna o endere�o de memoria que est� a chave desejada.
	Busca ordenada do registro pela chave.
*/
// OBS Fazer uma poss�vel modifica��a para se adaptar ao CRUD
PONT buscaSequencialOrd(LISTA* lista, TIPOCHAVE ch) {
	PONT posicao = lista -> inicio;
	while (posicao != NULL && posicao -> registro.chave < ch){
		posicao = posicao -> proximo;
	}
	if (posicao != NULL && posicao->registro.chave == ch) {
		return posicao;
	}
	return NULL;
}

/**
	Fun��o auxiliar para buscar o endere�o anterior a partir da chave buscada.
*/
PONT buscaSenquencialExc(LISTA *lista, TIPOCHAVE ch, PONT *enderecoAnterior){
	*enderecoAnterior = NULL;
	PONT enderecoAtual = lista -> inicio;
	while(enderecoAtual != NULL && enderecoAtual -> registro.chave < ch){
		*enderecoAnterior = enderecoAtual;
		enderecoAtual = enderecoAtual -> proximo;
	}
	if(enderecoAtual != NULL && enderecoAtual -> registro.chave == ch) return enderecoAtual;
	return NULL;
}

/**
	Inseri um elemento da lista.
*/
bool inserirElemetnoListaOrdenado(LISTA *lista, REGISTRO registro){
	TIPOCHAVE ch = registro.chave;
	PONT anterior, atual;
	atual = buscaSenquencialExc(lista, ch, &anterior);
	if(atual != NULL) return false;
	atual = (PONT) malloc(sizeof(ELEMENTO));
	atual -> registro = registro;
	if(anterior == NULL){
		atual -> proximo = lista -> inicio;
		lista -> inicio = atual;
	} else{
		atual -> proximo = anterior -> proximo;
		anterior -> proximo = atual;
	}
	return true;
}

/**
	Exclui um elemento da lista 
*/
bool excluirElementoEmLista(LISTA *lista, TIPOCHAVE ch){
	PONT anterior, atual;
	atual = buscaSenquencialExc(lista, ch, &anterior);
	if(atual == NULL) return false;
	if(anterior == NULL) lista -> inicio = atual -> proximo;
	else anterior -> proximo = atual -> proximo;
	free(atual);
	return true;
}
/**
	Reinicializa a lista.
*/
void reinicializarLista(LISTA *lista){
	PONT endereco = lista -> inicio;
	while (endereco != NULL){
		PONT apagar = endereco;
		endereco = endereco -> proximo;
		free(apagar);
	}
	lista -> inicio = NULL;
}
