#ifndef LISTA_H
#define LISTA_H
#include <stdbool.h>
typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} DATA;

typedef struct {
	TIPOCHAVE chave; // Controle de ID
	char matricula[9]; // Matricula do aluno
	char nome[20]; // Nome do aluno
	char ocorrencia[20]; // Descri��o da Ocorr�ncia (Esqueceu/Perdeu/NaoPossui/Outros cart�o)
} REGISTRO;

typedef struct aux {
	REGISTRO registro;
	//Esta linha serve para o compilador enteder que o ponteiro
	//� do mesmo tipo do que a estrutura ELEMENTO;
	struct aux *proximo;
} ELEMENTO;

typedef ELEMENTO* PONT;

typedef struct {
	PONT inicio;
} LISTA;

typedef struct {
	LISTA list; 
	DATA dataAcesso; // Data de Acesso
	char nomePorteiro[100]; // Nome Porteiro
} DADOSHEADERF;

void inicializarLista(LISTA *lista);
int tamanho(LISTA *lista);
PONT buscaSequencial(LISTA* lista, TIPOCHAVE ch);
PONT buscaSequencialOrd(LISTA* lista, TIPOCHAVE ch);
PONT buscaSenquencialExc(LISTA *lista, TIPOCHAVE ch, PONT *enderecoAnterior);
bool inserirElemetnoListaOrdenado(LISTA *lista, REGISTRO registro);
bool excluirElementoEmLista(LISTA *lista, TIPOCHAVE ch);
void reinicializarLista(LISTA *lista);
#endif

