#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "CRUDLista.h"
#include "Lista.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	setlocale(LC_ALL, "Portuguese");
	FILE *file; LISTA lista;
	char comando = ' ';
	file = fopen("ListaNome.txt", "a");
	inicializarLista(&lista);
	while (comando != 'q'){	
		help();
		printf("Digite a op��o: ");
		scanf("%c",&comando);
		switch (comando) {
    		case 'i' :
    			inserir(&lista);
    			break;
    		case 'x':
    			excluir(&lista);
    			break;
    		case 'a':
    			alterar(&lista);
    			break;
    		case 'd':
    			destruir(&lista);
    			break;
    		case 't':
    			exibirTodos(&lista);
    			break;
    		case 'u':
    			exibir(&lista);
    			break;
    		case 'h':
    			consultar(&lista);
    			break;
    		case 's':
    			salvar(&lista, file);
    			break;
    		case 'c':
    			carregar(&lista, file);
    			break;
    		case 'l':
    			printf("A lista possui %d elemnetos", tamanho(&lista));
    			fflush(stdin);
    			getchar();
    			break;
    		case 'q':
    			printf("Voc� saiu do programa.");
				break;
			default: {
				printf("Comando inv�lido!");
			}
		}
	}
	fclose(file);
	return 0;
}
