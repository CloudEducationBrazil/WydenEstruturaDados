#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include "CRUDLista.h"
#include "Lista.h"

void inserir(LISTA *lista){
	TIPOCHAVE ch;
	REGISTRO registro;
	printf("Digite a chave: "); scanf("%i",&ch);
	printf("Digite seu nome: "); fflush(stdin); gets(registro.nome);
	registro.chave = ch;
	if (inserirElemListaOrd(lista, registro)){
		printf("Registro inserido na lista");
	}
	else{
		printf("Erro ao inserir registro na lista!");
	}
	fflush(stdin);
	getchar();
	printf("\n-----------------------------------------------------------------------------------");
}

void excluir(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: ");
	scanf("%i",&ch);
	if (excluirElemLista(lista, ch)) printf("Registro excluido!");
	else printf("N�o foi poss�vel exculir o registro!");
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin); 
	getchar();
}

void alterar(LISTA *lista){
	TIPOCHAVE chave;
	REGISTRO registro;
	printf("Digite a chave: "); scanf("%i",&chave);
	PONT posicao = buscaSequencial(lista, chave);
	if(posicao != NULL){
		printf("Digite seu nome: "); fflush(stdin); gets(posicao->reg.nome);
		printf("Registro alterado com sucesso.");
	}else{
		printf("Essa registro n�o esxite para ser alterado!");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void consultar(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: "); scanf("%i",&ch);
	PONT posicao = buscaSequencial(lista, ch);
	if (posicao != NULL){
		printf("Registro encontrado na lista");
	}
  	else{
		printf("Registro n�o encontrado na lista");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();  
}

void exibir(LISTA *lista){
	TIPOCHAVE ch;
	printf("Digite a chave: "); 
	scanf("%i",&ch);
	PONT posicao = buscaSequencial(lista,ch);
	if (posicao != NULL){
		printf("Chave: %i\tNome: %s\n", posicao->reg.chave, posicao->reg.nome);
	}
  	else{
		printf("N�o foi possivel encontrar o registro");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void exibirTodos(LISTA *lista){
	PONT posicao = lista -> inicio;
	while(posicao != NULL){
		printf("Chave: %i\tNome: %s\n", posicao->reg.chave, posicao->reg.nome);
		posicao = posicao -> prox;
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void destruir(LISTA *lista){
	reinicializarLista(lista);
	printf("Lista vazia");
	fflush(stdin);
	getchar();
	printf("\n-----------------------------------------------------------------------------------");
}

void salvar(LISTA *lista, FILE *file){
	file = fopen("ListaNome.txt", "w");
	PONT posicao = lista->inicio;
	while(posicao != NULL){
		fprintf(file, "Chave: %i\tNome: %s\n", posicao->reg.chave, posicao->reg.nome);
		posicao = posicao->prox;
	}
	fclose(file);
	printf("Agenda salva com sucesso!");
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void carregar(LISTA *lista, FILE *file){
	file = fopen("ListaNome.txt", "r");
	REGISTRO registro;
	destruir(lista);
	while(!feof(file)){
		fscanf(file, "Chave %i\tNome: %50[^\n]", registro.chave, registro.nome);
		if(inserirElemListaOrd(lista, registro)){
			printf("Dados carragados na mem�ria com sucesso!");
		}else{
			printf("Erro ao carregar os dados!");
		}
	}
	fclose(file);
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void help(){
  system("CLS");

  printf("Comandos v�lidos: \n");
  printf("	i : Inserir resgistro na lista\n");
  printf("	x : Excluir resgistro da lista\n");
  printf("	a : Alterar resgistro da lista\n");
  printf("	d : Destruir a lista e reinicializar\n");
  printf("	t : Exibir toda a lista\n");
  printf("	u : Exibir dados de um registro expec�fico\n");
  printf("	h : Consultar se exite a chave desejada na lista\n");
  printf("	s : Salvar a lista\n");
  printf("	c : Carregar a lista\n");
  printf("	l : Tamanho da lista\n");
  printf("	q : Sair do programa\n");
  
  printf("\n");
}
