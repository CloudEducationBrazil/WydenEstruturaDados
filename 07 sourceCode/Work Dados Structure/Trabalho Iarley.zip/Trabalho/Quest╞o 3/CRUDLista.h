#ifndef CRUDLISTA_H
#define CRUDLISTA_H
#include "Lista.h"

void inserir(LISTA *lista);
void excluir(LISTA *lista);
void alterar(LISTA *lista);
void consultar(LISTA *lista);
void exibir(LISTA *lista);
void exibirTodos(LISTA *lista);
void destruir(LISTA *lista);
void salvar(LISTA *lista, FILE *file);
void carregar(LISTA *lista, FILE *file);
void help();

#endif
