#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

void inicializarFila(FILA *fila) {
	fila -> primeiro = NULL;
	fila -> ultimo = NULL;
}

int tamanho(FILA *fila) {
	PONT endereco = fila->primeiro;
	int tam = 0;
	while (endereco != NULL){
		tam++;
		endereco = endereco -> proximo;
	}
	return tam;
}

void destruirFila(FILA *fila) {
	PONT endereco = fila->primeiro;
	while (endereco != NULL){
		PONT apagar = endereco;
		endereco = endereco->proximo;
		free(apagar);
	}
	fila -> primeiro = NULL;
	fila -> ultimo = NULL;
}

PONT retornarPrimeiro(FILA *fila) {
	return fila -> primeiro;
}

PONT retornarUltimo(FILA *fila) {
	if (fila->primeiro == NULL) return NULL;
	return fila->ultimo;
}

bool inserirNaFila(FILA *fila,REGISTRO reg) {
	PONT novo = (PONT) malloc(sizeof(ELEMENTO));
	novo -> registro = reg;
	novo -> proximo = NULL;
	if (fila -> primeiro == NULL){
    	fila -> primeiro = novo;
	}else{
    	fila -> ultimo -> proximo = novo;
	}
	fila -> ultimo = novo;
	return true;
}

bool excluirDaFila(FILA *fila) {
	if (fila -> primeiro == NULL){
		return false;                     
	}
	PONT apagar = fila -> primeiro;
	fila -> primeiro = fila -> primeiro -> proximo;
	free(apagar);
	if (fila -> primeiro == NULL){
    	fila -> ultimo = NULL;
	}
	return true;
}

void exibirFila(FILA *fila){
	PONT endereco = fila -> primeiro;
	printf("Fila: ");
	while (endereco != NULL){
		printf("%d\t", endereco -> registro.chave); // soh lembrando TIPOCHAVE = int
		endereco = endereco -> proximo;
	}
}

PONT buscaSeq(FILA *fila, TIPOCHAVE ch){
	PONT posicao = fila -> primeiro;
	while (posicao != NULL){
		if (posicao -> registro.chave == ch) return posicao;
		posicao = posicao -> proximo;
	}
	return NULL;
}
