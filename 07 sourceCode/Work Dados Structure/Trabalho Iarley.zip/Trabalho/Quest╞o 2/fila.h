#ifndef FILA_H
#define FILA_H
#include <stdbool.h>

typedef int TIPOCHAVE;

typedef struct{
	TIPOCHAVE chave;
	char dataCompromisso[11];
	char descricaoCompromisso[200];
}REGISTRO;

typedef struct aux {
	REGISTRO registro;
	//Esta linha serve para o compilador enteder que o ponteiro
	//� do mesmo tipo do que a estrutura ELEMENTO;
	struct aux *proximo;
} ELEMENTO;

typedef ELEMENTO* PONT;

typedef struct {
	PONT primeiro;
	PONT ultimo;
} FILA;

typedef struct {
	FILA fila; // Data de Acesso
	char nomeAgenda[200]; // Nome Agenda
} DADOSHEADERF;

void inicializarFila(FILA *fila);
int tamanho(FILA *fila);
void destruirFila(FILA *fila);
PONT retornarPrimeiro(FILA *fila);
PONT retornarUltimo(FILA *fila);
bool inserirNaFila(FILA *fila,REGISTRO reg);
bool excluirDaFila(FILA *fila);
void exibirFila(FILA *fila);
PONT buscaSeq(FILA *fila, TIPOCHAVE ch);

#endif
