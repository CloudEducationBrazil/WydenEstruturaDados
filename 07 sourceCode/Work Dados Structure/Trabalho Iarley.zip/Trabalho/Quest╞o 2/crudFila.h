#ifndef CRUDFILA_H
#define CRUDFILA_H
#include "fila.h"

void inserir(FILA *fila);
void excluir(FILA *fila);
void alterar(FILA *fila);
void consultar(FILA *fila);
void exibirCompormisso(FILA *fila);
void exibirAgenda(DADOSHEADERF *dataControle, FILA *fila);
void destruir(FILA *fila);
void salvar(DADOSHEADERF *dataControle, FILA *fila, FILE *file);
void carregar(DADOSHEADERF *dataControle, FILA *fila, FILE *file);
void help();

#endif
