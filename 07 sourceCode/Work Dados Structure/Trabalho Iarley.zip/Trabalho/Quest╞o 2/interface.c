#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include "fila.h"
#include "crudFila.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	setlocale(LC_ALL, "Portuguese");
	DADOSHEADERF dataControle; FILE *file; FILA fila;
	char comando = ' ';
	file = fopen("Agenda.txt", "a");
	inicializarFila(&fila);
	printf("Nome da Agenda: "); fflush(stdin); gets(dataControle.nomeAgenda);
	while (comando != 'q'){	
		help();
		printf("Digite a droga da op��o: ");
		scanf("%c",&comando);
		switch (comando) {
    		case 'i' :
    			inserir(&fila);
    			break;
    		case 'x':
    			excluir(&fila);
    			break;
    		case 'a':
    			alterar(&fila);
    			break;
    		case 'd':
    			destruir(&fila);
    			break;
    		case 't':
    			exibirAgenda(&dataControle, &fila);
    			break;
    		case 'u':
    			exibirCompromisso(&fila);
    			break;
    		case 'h':
    			consultar(&fila);
    			break;
    		case 's':
    			salvar(&dataControle, &fila, file);
    			break;
    		case 'c':
    			carregar(&dataControle, &fila, file);
    			break;
    		case 'l':
    			printf("A agenda possui %d compromissos", tamanho(&fila));
    			break;
    		case 'q':
    			printf("Voc� saiu do programa.");
				break;
		}
	}
	fclose(file);
	return 0;
}
