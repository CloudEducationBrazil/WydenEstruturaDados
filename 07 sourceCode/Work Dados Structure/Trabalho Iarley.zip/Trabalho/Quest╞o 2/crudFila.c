#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <locale.h>
#include "crudFila.h"
#include "fila.h"

void inserir(FILA *fila){
	TIPOCHAVE ch;
	REGISTRO registro;
	printf("Digite a chave: "); scanf("%i",&ch);
	printf("Formato da data: dd/mm/aaaa\n");
	printf("Data do compromisso:"); fflush(stdin); gets(registro.dataCompromisso);
	printf("Descri��o do compromisso:"); fflush(stdin); gets(registro.descricaoCompromisso);
	registro.chave = ch;
	if (inserirNaFila(fila, registro)){
		printf("Compromisso inserido na agenda!");
	}
	else{
		printf("Erro ao inserir compromisso na agenda!");
	}
	fflush(stdin);
	getchar();
	printf("\n-----------------------------------------------------------------------------------");
}

void excluir(FILA *fila){
	TIPOCHAVE ch;
	printf("Digite a chave: ");
	scanf("%i",&ch);
	if (excluirDaFila(fila)) printf("Compromisso excluido!");
	else printf("N�o foi poss�vel exculir o compromisso!");
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin); 
	getchar();
}

void alterar(FILA *fila){
	TIPOCHAVE chave;
	PONT posicao;
	printf("Digite a chave para o registro que deseja alterar: ");
	scanf("%d", &chave);
	posicao = buscaSeq(fila, chave);
	if(posicao != NULL){
		printf("Data do compromisso:"); fflush(stdin); gets(posicao->registro.dataCompromisso);
		printf("Descri��o do compromisso:"); fflush(stdin); gets(posicao->registro.descricaoCompromisso);
		printf("Registro alterado com sucesso.");
	}else{
		printf("Essa registro n�o esxite para ser alterado!");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void consultar(FILA *fila){
	TIPOCHAVE ch;
	printf("Digite a chave: "); scanf("%i",&ch);
	PONT posicao = buscaSeq(fila, ch);
	if (posicao != NULL){
		printf("Compromisso encontrado na agenda");
	}
  	else{
		printf("Compromisso n�o econtrado na agenda!");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();  
}

void exibirCompromisso(FILA *fila){
	TIPOCHAVE ch;
	printf("Digite a chave: "); 
	scanf("%i",&ch);
	PONT posicao = buscaSeq(fila,ch);
	if (posicao != NULL){
		printf("Chave: %i\tData do compromisso: %s\nDescri��o do comporomisso: %s\n", 
		posicao->registro.chave, posicao->registro.dataCompromisso, posicao->registro.descricaoCompromisso);
	}
  	else{
		printf("N�o foi possivel encontrar o compromisso na agenda!");
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void exibirAgenda(DADOSHEADERF *dataControle, FILA *fila){
	printf("Agenda: %s\n", dataControle->nomeAgenda);
	PONT posicao = fila -> primeiro;
	while(posicao != NULL){
		printf("Chave: %i\tData do compromisso: %s\nDescri��o do comporomisso: %s\n", 
		posicao->registro.chave, posicao->registro.dataCompromisso, posicao->registro.descricaoCompromisso);
		posicao = posicao -> proximo;
	}
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void destruir(FILA *fila){
	destruirFila(fila);
	printf("Agenda vazia!");
	getchar();
	fflush(stdin);
	printf("\n-----------------------------------------------------------------------------------");
}

void salvar(DADOSHEADERF *dataControle, FILA *fila, FILE *file){
	file = fopen("Agenda.txt", "w");
	fprintf(file, "Agenda: %s\n", dataControle -> nomeAgenda);
	dataControle->fila = *fila;
	PONT posicao = fila -> primeiro;
	while(posicao != NULL){
		fprintf(file, "Chave: %i\tData do compromisso: %s\nDescri��o do comporomisso: %s\n", 
		posicao->registro.chave, posicao->registro.dataCompromisso, posicao->registro.descricaoCompromisso);
		posicao = posicao -> proximo;
	}
	fclose(file);
	printf("Agenda salva com sucesso!");
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void carregar(DADOSHEADERF *dataControle, FILA *fila, FILE *file){
	file = fopen("Agenda.txt", "r");
	REGISTRO registro;
	fscanf(file, "Agenda: %200[^\n]");
	destruir(fila);
	while(!feof(file)){
		fscanf(file, "Chave: %i\tData: %s\n", &registro.chave, registro.dataCompromisso);
		fscanf(file, "Descri��o: %200[^\n]", registro.descricaoCompromisso);
		if(inserirNaFila(fila, registro)){
			printf("Dados carragados na mem�ria com sucesso!");
		}else{
			printf("Erro ao carregar os dados!");
		}
	}
	fclose(file);
	printf("\n-----------------------------------------------------------------------------------");
	fflush(stdin);
	getchar();
}

void help(){
  system("CLS");

  printf("Comandos v�lidos: \n");
  printf("	i : Inserir compromisso na agenda\n");
  printf("	x : Excluir compromisso na agenda\n");
  printf("	a : Alterar compromisso da lista\n");
  printf("	d : Destruir a lista e reinicializar\n");
  printf("	t : Exibir agenda\n");
  printf("	u : Exibir compromisso expec�fico\n");
  printf("	h : Consultar se compromisso exite pela chave\n");
  printf("	s : Salvar a agenda\n");
  printf("	c : Carregar a agenda\n");
  printf("	l : Tamanho da agenda\n");
  printf("	q : Sair do programa\n");
  
  printf("\n");
}
