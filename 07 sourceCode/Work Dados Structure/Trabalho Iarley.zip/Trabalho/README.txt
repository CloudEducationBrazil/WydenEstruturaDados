Aluno: Iarley Porto Cruz Moraes
Matr�cula: 161030416
Obs: Abrir no DevC++
Executar o arquivo *.dev para abrir o projeto.