#ifndef FILE_H_INCLUDED
#define FILE_H_INCLUDED
#define MAX 50

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content Header
 * @descricao Cabe�alho
 * @data Abril de 2019
 * @matricula 161031173
*/

void mensagemDeErro();
void mensagemAtencao();
void menu();
void Credits();
#endif // FILE_H_INCLUDED
