#include<stdio.h>
#include<stdlib.h>
#include<locale.h>
#include <stdlib.h>
#include <malloc.h>

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content Main
 * @descricao Arquivo principal
 * @data Abril de 2019
 * @matricula 161031173
*/

int main(){
int x;
setlocale(LC_ALL,"");
system("cls");
system("color 07");
printf("###########################################\n");
printf("# Digite o n�mero referente ao programa:  #\n");
printf("# 1 - InclusionNumbersIntegers;           #\n");
printf("# 2 - ScheduleCommitments;                #\n");
printf("# 3 - AccessControlAcademic;              #\n");
printf("# 4 - Credits;                            #\n");
printf("# 0 - Sair;                               #\n");
printf("###########################################\n");
printf("Opcao: ");
scanf("%d", &x);
switch(x){
case 0 :{
    exit(0);
}
case 1 :{
    InclusionNumbersIntegers();
    break;
}
case 2: {
    ScheduleCommitments();
    break;
}
case 3: {
    AccessControlAcademic();
    break;
}
case 4:{
    Credits();
    break;
}
default :{
    mensagemDeErro();
    break;
}
}
}
