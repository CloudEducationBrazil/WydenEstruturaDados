#include "File.h"
#include <stdlib.h>
#include <malloc.h>
#include<stdio.h>

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content Functions
 * @descricao Fun��es da biblioteca
 * @data Abril de 2019
 * @matricula 161031173
*/

void mensagemDeErro(){
    system("cls");
    system("color 04");
    printf("#######################################\n");
    printf("#            OPCAO INVALIDA!!!        #\n");
    printf("# POR FAVOR DIGITE UMA OPCAO VALIDA!! #\n");
    printf("#######################################\n");
    system("pause");
}

void mensagemAtencao(){
    system("cls");
    system("color 06");
    printf("#########################################\n");
    printf("#                 WARNING!!!            #\n");
    printf("# FACA BACKUP DO ULTIMO ARQUIVO SALVO!! #\n");
    printf("#########################################\n");
    system("pause");
}

void menu(){
printf("##################################\n");
printf("# Selecione uma op��o:           #\n");
printf("# 1- Reinicializar;              #\n");
printf("# 2- Inserir item;               #\n");
printf("# 3- Buscar item;                #\n");
printf("# 4- Listar itens;               #\n");
printf("# 5- Ver tamanho;                #\n");
printf("# 6- Apagar item;                #\n");
printf("# 7- Modificar item;             #\n");
printf("# 8- Salvar dados em arquivo;    #\n");
printf("# 9- Carregar dados do arquivo;  #\n");
printf("# 0- Retornar ao menu;           #\n");
printf("##################################\n");
printf("Opcao: ");
}

void Credits(){
    system("cls");
    system("color 97");
    printf("#################################################\n");
    printf("# @author    * EMANUEL OLIVEIRA SALVADOR SOUZA  #\n");
    printf("# @matricula * 161031173                        #\n");
    printf("# @data      * Abril de 2019                    #\n");
    printf("#################################################\n");
    system("pause");
    main();
}
