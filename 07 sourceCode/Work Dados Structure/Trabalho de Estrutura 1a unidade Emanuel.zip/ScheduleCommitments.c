#include<stdio.h>
#include<locale.h>
#include "File.h"
#define MAX 10

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content ScheduleCommitments (Agenda de Compromissos)
 * @descricao Pilha estatica
 * @data Abril de 2019
 * @matricula 161031173
*/

typedef int TIPOCHAVE;

typedef struct {
    int dia;
	int mes;
	int ano;
}dataRef;

typedef struct {
	TIPOCHAVE chave;                // Controle ID
	dataRef dataCompromisso;        // Data Compromisso
    char descricaoCompromisso[300]; // Descri��o
} REGISTRO;


typedef struct {
    REGISTRO A[MAX];
    int topo;
}PILHA;

void inicializarPilha(PILHA* p) {
p->topo = -1;
}

void tamanhoPilha(PILHA* p) {
int i, x, y, t;
x=((p->topo+1)*100)/MAX;
if(p->topo==-1){
system("color 02");
printf("[                                                   ]\t0%%\n");
printf("\n Lista Vazia!!\n");
}
else{
   printf("[");
   for(i=0;i<(p->topo+1);i++){
    printf("#");
   }
        for (y=MAX-(p->topo+1);y>0;y--){
            printf("-");
        }
    printf("]");
        if(x<=50){
        system("color 02");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", p->topo+1);
    }
        else if (x<=99){
        system("color 06");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", p->topo+1);
        }
        else{
        system("color 04");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", p->topo+1);
        printf("\nPilha Cheia !!!\n");
        }
}
}

void exibirPilha(PILHA* p) {
int i;
if(p->topo==-1) {
    printf("\n PILHA VAZIA!!\n");
    system("pause");
}
else {
    printf("\tPILHA:  ");
    for (i=p->topo;i>=0;i--) {
    printf("\nElemento: %i", p->A[i].chave);
    printf("\nDia: %i ", p->A[i].dataCompromisso.dia);
    printf("\nM�s: %i ", p->A[i].dataCompromisso.mes);
    printf("\nAno: %i ", p->A[i].dataCompromisso.ano);
    printf("\nDescri��o: %s ", p->A[i].descricaoCompromisso);
    printf("\n------------------------------");
    }
printf("\"\n");
}
}
int buscaSequencialPilha(PILHA *p, REGISTRO reg){
int j=0;
for(j=0;j<(p->topo+1);j++){
		if(reg.chave==p->A[j].chave){
            system("color 02");
			printf("\nElemento %i localizado !!\n", p->A[j]);
			printf("\nElemento: %i", p->A[j].chave);
            printf("\nDia: %i ", p->A[j].dataCompromisso.dia);
            printf("\nM�s: %i ", p->A[j].dataCompromisso.mes);
            printf("\nAno: %i ", p->A[j].dataCompromisso.ano);
            printf("\nDescri��o: %s ", p->A[j].descricaoCompromisso);
            printf("\n------------------------------\n");
			return 1;
        }
}
return 0;
}

int inserirElementoPilha(PILHA* p, REGISTRO reg) {
if (p->topo >= MAX-1) return 0;
p->topo = p->topo+1;
p->A[p->topo] = reg;
return 1;
}

int excluirElementoPilha(PILHA* p) {
if (p->topo == -1) return 0;
//*reg = p->A[p->topo];
p->topo = p->topo-1;
return 1;
}

void atualizarELEMPilha(PILHA *p, REGISTRO reg, int posicao){
REGISTRO u;
if((posicao>p->topo+1)|| (posicao<0)){
    system("color 04");
    printf("\nPosi��o %d inexistente!!\n", posicao);
}
else{
    u=p->A[posicao];
    p->A[posicao] = reg;
    system("color 02");
    printf("\nElemento %d foi substituido !!\n", u,p->A[posicao]);
}
}

int SalvarScheduleCommitments(PILHA *p){
FILE *ArqLista;
int i;
  ArqLista = fopen("ScheduleCommitments.txt", "w");
if ( ArqLista == NULL ) {
        system("color 04");
        printf("\nErro ao abrir o arquivo\n");
        system("pause");
    return 0;
}
else{
    fputs("\tPILHA:", ArqLista);
    for (i=p->topo;i>=0;i--) {
         fprintf(ArqLista,"\nElemento: %i", p->A[i].chave);
         fprintf(ArqLista,"\nDia: %i ", p->A[i].dataCompromisso.dia);
         fprintf(ArqLista,"\nM�s: %i ", p->A[i].dataCompromisso.mes);
         fprintf(ArqLista,"\nAno: %i ", p->A[i].dataCompromisso.ano);
         fprintf(ArqLista,"\nDescri��o: %s ", p->A[i].descricaoCompromisso);
         fprintf(ArqLista,"\n------------------------------");
    }
fclose(ArqLista);
system("color 02");
printf("\nArquivo gerado com sucesso!!\n");
system("pause");
return 0;
}
}

int CarregarScheduleCommitments(){
FILE* ArqLista;

ArqLista = (FILE*) malloc(sizeof(FILE));
ArqLista = fopen("ScheduleCommitments.txt", "r");
char  linha[200];
char* result;
if ( ArqLista == NULL ) {
printf("Erro ao abrir o arquivo");
};
while ( !feof(ArqLista) ) {
     result = fgets(linha, 100, ArqLista);
	if ( result )
       printf("%s \n", linha);
}
system("pause");
fclose(ArqLista);
return 0;
}


int ScheduleCommitments(){
int x, i, posicao, y=1, tam, t;
TIPOCHAVE chave;
PILHA p;
REGISTRO reg;
setlocale(LC_ALL,"");
inicializarPilha(&p);
system("color 02");
system("cls");
printf("####################################\n");
printf("# PILHA INICIALIZADA COM SUCESSO!! #\n");
printf("####################################\n");
system("pause");
while(y!=0){
system("cls");
system("color 07");
menu();
scanf("%d", &x);
switch(x){
case 0: {
    main();
}
case 1: {
    inicializarPilha(&p);
    system("cls");
    system("color 02");
    printf("\nPilha reinicializada!!\n");
    system("pause");
    break;
}
case 2:{
    printf("\nDigite a chave do item:");
    scanf("%d", &reg.chave);
    printf("\nDigite o dia do evento:");
    scanf("%d", &reg.dataCompromisso.dia);
    printf("\nDigite o m�s do evento:");
    scanf("%d", &reg.dataCompromisso.mes);
    printf("\nDigite o ano do evento:");
    scanf("%d", &reg.dataCompromisso.ano);
    printf("\nDigite a descri��o do evento (limite de 300 caracteres):");
    fflush(stdin);
    gets(reg.descricaoCompromisso);
    t=inserirElementoPilha(&p,reg);
    if(t==1) {
    system("color 02");
     printf("Elemento %d foi inserido com sucesso!!", reg);
     system("pause");
    }
    else {
        system("color 04");
     printf("Pilha cheia!!\n Por Favor Descarregue!!", reg);
     system("pause");
    }
    break;
}
case 3:{
    printf("\nInforme a Chave do Registro que deseja Buscar: ");
    scanf("%d",&reg.chave);
    i=buscaSequencialPilha(&p,reg);
    if (i==0) {
            system("color 04");
            printf("\nItem n�o localizado!!\n");
    }
    system("pause");
    break;
}
case 4:{
    system("cls");
    exibirPilha(&p);
    system("pause");
    break;
}
case 5:{
    system("cls");
    tamanhoPilha(&p);
    system("pause");
    break;
}
case 6:{
    system("cls");
    t=excluirElementoPilha(&p);
    if(t==1){
            printf("\n O �ltimo registro removido com sucesso!!\n");
            printf("");
            system("pause");
    }
    else
        printf("\n PILHA vazia!!\n Nenhum elemento foi removido !!\n");
        system("pause");
    break;
}
case 7:{
    system("cls");
    printf("\nInforme a posi��o do registro que deseja modificar: ");
    scanf("%d",&posicao);
    printf("\nInforme a Chave do Registro que deseja acrescentar: ");
    scanf("%d",&reg.chave);
    atualizarELEMPilha(&p, reg, posicao);
    system("pause");
    break;
}
case 8: {
    mensagemAtencao();
    SalvarScheduleCommitments(&p);
    break;
}
case 9: {
    system("cls");
    CarregarScheduleCommitments();
    break;
}
default:{
    mensagemDeErro();
    break;
}
}
}
return 0;
}


