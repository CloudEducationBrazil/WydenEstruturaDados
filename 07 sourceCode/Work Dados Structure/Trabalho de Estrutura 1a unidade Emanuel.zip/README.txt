/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content Todos os arquivos do projeto
 * @descricao Softwares com aplica��es de Fila din�mica, Pilha estatica e Lista estatica
 * @data Abril de 2019
 * @matricula 161031173
 * Arquivo de execu��o principal -> bin -> Debug -> Biblioteca.exe
 * Os 3 softwares est�o em uma unica aplica��o
 * O codigo fonte do trabalho � composto por AccessControlAcademic.c, File.c, File.h, InclusionNumbersIntegers.c, ScheduleCommitments.c e main.c
*/