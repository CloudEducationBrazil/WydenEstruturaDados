#include <stdio.h>
#define MAX 50
#include "File.h"

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content InclusionNumbersIntegers
 * @descricao Lista estatica
 * @data Abril de 2019
 * @matricula 161031173
*/

typedef int TIPOCHAVE;
typedef struct {
    TIPOCHAVE chave;      // Controle ID
}REGISTRO;
typedef struct {
    REGISTRO A[MAX];
    int nELEM;
}LISTA;

void inicializarLista(LISTA *lista){
lista->nELEM=0;
}

void tamanhoLista(LISTA *lista){
int i, x, y, t;
x=(lista->nELEM*100)/MAX;
if(lista->nELEM ==0){
system("color 02");
printf("[                                                   ]\t0%%\n");
printf("\n Lista Vazia!!\n");
}
else{
   printf("[");
   for(i=0;i<lista->nELEM;i++){
    printf("#");
   }
        for(y=(MAX-lista->nELEM);y>0;y--){
            printf("-");
        }
    printf("]");
        if(x<=50){
        system("color 02");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", lista->nELEM);
    }
        else if (x<=99){
        system("color 06");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", lista->nELEM);
        }
        else{
        system("color 04");
        printf("\t%d%%", x);
        printf("\nTamanho: %d itens\n", lista->nELEM);
        printf("\nLista Cheia !!!\n");
        }
}
}

void exibirLista(LISTA *lista){
int i;
if(lista->nELEM ==0) printf("\n Lista Vazia!!\n");
else {
printf("Lista:\n");
printf("\tREGISTRO  --  POSI��O");
for(i=0;i<lista->nELEM;i++){
    printf("\n\t   %d      --  \t%d ", lista->A[i].chave,i);
}
printf("\nFIM\n");
}
}

int buscaSequencial(LISTA *lista, REGISTRO reg){
int j=0;
for(j=0;j<lista->nELEM;j++){
		if(reg.chave==lista->A[j].chave){
            system("color 02");
			printf("\nElemento %d localizado na posic�o %d \n", reg,j);
			return 1;
        }
}
return 0;
}

int validarELEMLista(LISTA *lista, REGISTRO reg){
int j;
if((lista->nELEM>=MAX) || (lista->nELEM<0)){
   return 2;
}
for(j=0;j<lista->nELEM;j++){
		if(reg.chave==lista->A[j].chave){
			return 1;
   }
   }
return 0;
}

int inserirELEMLista(LISTA *lista, REGISTRO reg){
lista->A[lista->nELEM] = reg;
lista->nELEM++;
system("color 02");
printf("\nSucesso!");
printf("\nItem %d inserido na posic�o %d\n", reg, lista->nELEM-1);
return 1;
}

void apagarELEMLista(LISTA *lista, int posicao){
int i;
if(posicao<lista->nELEM){
		    system("color 02");
		printf("Sucesso!\n");
		if(posicao==(lista->nELEM-1))
			lista->nELEM = lista->nELEM-1;
		else{
			for(i=posicao;i<lista->nELEM-1;i++)
				lista->A[i] = lista->A[i+1];
			lista->nELEM= lista->nELEM-1;
		}
	}else{
		system("color 04");
		printf("Posicao nao existe!\n");
	}
	system("pause");
}

void atualizarELEMLista(LISTA *lista, REGISTRO reg, int posicao){
REGISTRO p;
if((posicao>MAX)|| (posicao<0)){
    system("color 04");
    printf("\nPosi��o %d inexistente!!\n", posicao);
}
else{
    p=lista->A[posicao];
    lista->A[posicao] = reg;
    system("color 02");
    printf("\nElemento %d foi substituido por %d com sucesso!!\n", p, lista->A[posicao]);
}
}

int SalvarInclusionNumbersIntegers(LISTA *lista){
FILE *ArqLista;
int i;
  ArqLista = fopen("InclusionNumbersIntegers.txt", "w");
if ( ArqLista == NULL ) {
        system("color 04");
        printf("\nErro ao abrir o arquivo\n");
        system("pause");
    return 0;
}
else{
        fputs("Lista:\n", ArqLista);
        fputs("\tREGISTRO  --  POSICAO", ArqLista);
        for(i=0;i<lista->nELEM;i++){
            fprintf(ArqLista,"\n\t   %d      --  \t%d ", lista->A[i].chave,i);
            }
        fputs("\nFIM\n", ArqLista);
}
fclose(ArqLista);
system("color 02");
printf("\nArquivo gerado com sucesso!!\n");
system("pause");
return 0;
}
int CarregarInclusionNumbersIntegers(){
FILE* ArqLista;

ArqLista = (FILE*) malloc(sizeof(FILE));
ArqLista = fopen("InclusionNumbersIntegers.txt", "r");
char  linha[200];
char* result;
if ( ArqLista == NULL ) {
printf("Erro ao abrir o arquivo");
};
while ( !feof(ArqLista) ) {
     result = fgets(linha, 100, ArqLista);
	if ( result )
       printf("%s \n", linha);
}
system("pause");
fclose(ArqLista);
return 0;
}

int InclusionNumbersIntegers(){
int x, i, posicao, y=1, tam, t;
TIPOCHAVE chave;
LISTA lista;
REGISTRO reg;
inicializarLista(&lista);
system("cls");
system("color 02");
printf("####################################\n");
printf("# LISTA INICIALIZADA COM SUCESSO!! #\n");
printf("####################################\n");
system("pause");
while(y!=0){
system("cls");
system("color 07");
menu();
scanf("%d", &x);
switch(x){
case 0: {
    main();
}
case 1: {
    inicializarLista(&lista);
    system("cls");
    system("color 02");
    printf("\nLista reinicializada!!\n");
    system("pause");
    break;
}
case 2:{
    printf("\nDigite a chave do item:");
    scanf("%d", &reg.chave);
    t=validarELEMLista(&lista,reg);
    if(t==0) inserirELEMLista(&lista,reg);
    else if (t==1) {
            system("color 04");
            printf("\nErro!\n Chave de Registro ja inserida na lista!\n");
    }
    else {
        system("color 04");
        printf("\nItem %d nao valido; //\no vetor esta cheio \n ",reg);
    }
    system("pause");
    break;
}
case 3:{
    printf("\nInforme a Chave do Registro que deseja Buscar: ");
    scanf("%d",&reg.chave);
    i=buscaSequencial(&lista,reg);
    if (i==0) {
            system("color 04");
            printf("\nItem nao localizado!!\n");
    }
    system("pause");
    break;
}
case 4:{
    system("cls");
    exibirLista(&lista);
    system("pause");
    break;
}
case 5:{
    system("cls");
    tamanhoLista(&lista);
    system("pause");
    break;
}
case 6:{
    system("cls");
    printf("\nInforme a posicao do registro que deseja remover: ");
    scanf("%d",&posicao);
    apagarELEMLista(&lista, posicao);
    break;
}
case 7:{
    system("cls");
    printf("\nInforme a posicao do registro que deseja modificar: ");
    scanf("%d",&posicao);
    printf("\nInforme a Chave do Registro que deseja acrescentar: ");
    scanf("%d",&reg.chave);
    atualizarELEMLista(&lista, reg, posicao);
    system("pause");
    break;
}
case 8: {
    mensagemAtencao();
    SalvarInclusionNumbersIntegers(&lista);
    break;
}
case 9: {
    system("cls");
    CarregarInclusionNumbersIntegers();
    break;
}
default:{
    mensagemDeErro();
    break;
}
return 0;
}
}
}
