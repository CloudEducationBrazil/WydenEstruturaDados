#include <stdio.h>
#include<locale.h>
#include "File.h"

/**
 *
 * @author Emanuel Oliveira Salvador Souza
 * @content AccessControlAcademic (Controle de Acesso Acad�mico de Alunos)
 * @descricao Fila din�mica
 * @data Abril de 2019
 * @matricula 161031173
*/

typedef int TIPOCHAVE;

typedef struct {
	TIPOCHAVE chave;                 // Controle ID
	char matricula[20];              // Matr�cula do Aluno
    char TipoOcorrencia[300];         // Descri��o da Ocorr�ncia (Esqueceu/Perdeu/NaoPossui/Outros cart�o)
} REGISTRO;

typedef struct aux {
 REGISTRO reg;
 struct aux* prox;
} ELEMENTO,* PONT;

typedef struct {
 PONT inicio;
 PONT fim;
} FILA;

void inicializarFila(FILA* f) {
f->inicio = NULL;
f->fim = NULL;
}

void reinicializarFila(FILA* f) {
PONT end = f->inicio;
while (end != NULL) {
PONT apagar = end;
end = end->prox;
free(apagar);
}
f->inicio = NULL;
f->fim = NULL;
}

int tamanho(FILA* f) {
PONT end = f->inicio;
int tam = 0;
while (end != NULL) {
tam++;
end = end->prox;
}
return tam;
}

int exibirFila(FILA* f) {
PONT end = f->inicio;
if(f->inicio==NULL) {
        printf("\nFila vazia!!\n");
return 0;
}
else{
printf("\tFila:  ");
while (end != NULL) {
printf("\nElemento:           %i ", end->reg.chave);
printf("\nMatricula:          %s ", end->reg.matricula);
printf("\nTipo de ocorr�ncia: %s ", end->reg.TipoOcorrencia);
printf("\n----------------------------------------------\n");
end = end->prox;
}
printf("\"\n");
}
}

int inserirNaFila(FILA* f,REGISTRO reg) {
PONT novo = (PONT) malloc(sizeof(ELEMENTO));
novo->reg = reg;
novo->prox = NULL;
if (f->inicio==NULL) f->inicio = novo;
else f->fim->prox = novo;
f->fim = novo;
return 1;
}

int excluirDaFila(FILA* f, REGISTRO* reg) {
if (f->inicio==NULL) return 0;
*reg = f->inicio->reg;
PONT apagar = f->inicio;
f->inicio = f->inicio->prox;
free(apagar);
if (f->inicio == NULL) f->fim = NULL;
return 1;
}

PONT buscaSequencialFila(FILA* f, TIPOCHAVE ch) {
PONT pos = f->inicio;
while (pos != NULL) {
if (pos->reg.chave == ch){
    system("color 02");
    system("cls");
    printf("\nElemento %d encontrado! \n",*pos);
    printf("\nMatricula:          %s ", pos->reg.matricula);
    printf("\nTipo de ocorr�ncia: %s ", pos->reg.TipoOcorrencia);
    printf("\n----------------------------------------------\n");
    return pos;
} else
pos = pos->prox;
}
system("color 04");
printf("\nElemento %d n�o encontrado!!\n", ch);
return 0;
}

void atualizarELEMFila(FILA* f, TIPOCHAVE ch){
PONT pos = f->inicio;
while (pos != NULL) {
if (pos->reg.chave == ch){
    printf("\nDigite o novo n�mero de registro:\n");
    scanf("%d", &pos->reg.chave);
    system("color 02");
    printf("\nN�mero de registro alterado com sucesso:\n");
    return pos;
} else
pos = pos->prox;
}
system("color 04");
printf("\nElemento %d n�o encontrado!!", ch);
printf("\n Nenhum item alterado!!\n");
return 0;
}

int SalvarAccessControlAcademic(FILA *f){
FILE *ArqLista;
PONT end = f->inicio;
int i;
  ArqLista = fopen("AccessControlAcademic.txt", "w");
if ( ArqLista == NULL ) {
        system("color 04");
        printf("\nErro ao abrir o arquivo\n");
        system("pause");
    return 0;
}
else{
    if(f->inicio==NULL) {
        printf("\nFila vazia!!\n");
        return 0;
    }
    else{
    fputs("\tFila:  ", ArqLista);
    while (end != NULL) {
    fprintf(ArqLista,"\nElemento:           %i ", end->reg.chave);
    fprintf(ArqLista,"\nMatricula:          %s ", end->reg.matricula);
    fprintf(ArqLista,"\nTipo de ocorr�ncia: %s ", end->reg.TipoOcorrencia);
    fprintf(ArqLista,"\n----------------------------------------------\n");
    end = end->prox;
}
fclose(ArqLista);
system("color 02");
printf("\nArquivo gerado com sucesso!!\n");
system("pause");
return 0;
}
}
}

int CarregarAccessControlAcademic(){
FILE* ArqLista;

ArqLista = (FILE*) malloc(sizeof(FILE));
ArqLista = fopen("AccessControlAcademic.txt", "r");
char  linha[200];
char* result;
if ( ArqLista == NULL ) {
printf("Erro ao abrir o arquivo");
};
while ( !feof(ArqLista) ) {
     result = fgets(linha, 100, ArqLista);
	if ( result )
       printf("%s \n", linha);
}
system("pause");
fclose(ArqLista);
return 0;
}


int AccessControlAcademic(){
int x, i, posicao, y=1, tam, t;
TIPOCHAVE chave;
FILA f;
REGISTRO reg;
setlocale(LC_ALL,"");
inicializarFila(&f);
system("cls");
system("color 02");
printf("####################################\n");
printf("# FILA INICIALIZADA COM SUCESSO!!  #\n");
printf("####################################\n");
system("pause");
while(y!=0){
system("cls");
system("color 07");
menu();
scanf("%d", &x);
switch(x){
case 0: {
    main();
}
case 1: {
    reinicializarFila(&f);
    system("cls");
    system("color 02");
    printf("\nFILA reinicializada!!\n");
    system("pause");
    break;
}
case 2:{
    printf("\nDigite a chave do item:");
    scanf("%d", &reg.chave);
    printf("\nDigite o numero de matricula:");
    fflush(stdin);
    gets(reg.matricula);
    printf("\nDescri��o da Ocorr�ncia:Esqueceu/Perdeu/NaoPossui (cartao) ou Outros:");
    fflush(stdin);
    gets(reg.TipoOcorrencia);
    i=inserirNaFila(&f,reg);
    if(i==1) printf("\nElemento inserido com sucesso!!\n");
    else printf("\nHouve um erro tente novamente mais tarde!\n");
    system("pause");
    break;
}
case 3:{
    printf("\nInforme a Chave do Registro que deseja Buscar: ");
    scanf("%d",&reg.chave);
    buscaSequencialFila(&f,reg.chave);
    system("pause");
    break;
}
case 4:{
    system("cls");
    exibirFila(&f);
    system("pause");
    break;
}
case 5:{
    system("cls");
    printf("\nA fila possui %d objeto(s)\n",tamanho(&f));
    system("pause");
    break;
}
case 6:{
    system("cls");
    t=excluirDaFila(&f,&reg);
    if(t==0) {
        system("color 04");
        printf("\nNenhum item removido, fila vazia!\n");
    }
    else {
        system("color 02");
        printf("\n O 1 item da fila foi removido!\n");
    }
    system("pause");
    break;
}
case 7:{
    system("cls");
    printf("\nInforme a Chave do Registro que deseja substituir: ");
    scanf("%d",&reg.chave);
    atualizarELEMFila(&f, reg.chave);
    system("pause");
    break;
}
case 8: {
    mensagemAtencao();
    SalvarAccessControlAcademic(&f);
    break;
}
case 9: {
    system("cls");
    CarregarAccessControlAcademic();
    break;
}
default:{
    mensagemDeErro();
    break;
}
return 0;
}
}
}


