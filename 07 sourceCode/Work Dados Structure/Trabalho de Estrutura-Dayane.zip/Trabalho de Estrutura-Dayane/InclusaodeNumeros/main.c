#include <stdio.h>
#include <stdlib.h>
#include "InclusionNumbersIntegers.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {	
	LISTA lista;
	REGISTRO registro;
	tipoChave chave;
	int opc, opc2=0, opc3=0, posicao;
	opc=0;
	do{
        system("cls");
        printf("Seja Bem-vindo ao Menu!\n\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
		system("color 0D");
		printf("1 - CRIAR\n\n");
 	  	printf("0 - FECHAR PROGRAMA\n");
 	  	printf("\n\n");
	   	printf("DIGITE A OPCAO: ");
	   	scanf("%d",&opc);
	   	switch(opc){
    	    case 1:{
    	    	inicializarLista(&lista); 
				break;
			}case 0:{
				system("color 84");
				exit(1);
				break;
			}default:{
    	        system("cls");
    	        printf("ERRO, OPCAO INVALIDA\n");
    	        system("color 84");
				system("pause");
    	        break;
    	    }
		}
	}while(opc!=1);
	
	do{
		system("cls");
		printf("Seja bem-vindo ao Menu!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
		printf("1 - IMPRIMIR\n");
	  	printf("2 - BUSCAR ELEMENTO\n");
 	  	printf("3 - INSERIR ELEMENTO\n");
	   	printf("4 - ALTERAR ELEMENTO\n");
	   	printf("5 - EXCLUIR ELEMENTO\n");
	   	printf("6 - SALVAR ARQUIVO\n");
 	  	printf("7 - CARREGAR ARQUIVO\n");
 	  	printf("8 - REINICIALIZAR\n");
 	  	printf("9 - SAIR DA LISTA\n");
 	  	printf("DIGITE A OPCAO: ");
	   	scanf("%d",&opc);
 	  	switch(opc){
		case 1:{
			do{
				system("cls");
				printf("O DESEJA IMPRIMIR?\n");
				printf("1 - QUANTIDADE DE REGISTROS NA LISTA?\n");
				printf("2 - OS REGISTROS NA LISTA?\n");
				printf("DIGITE A OPCAO: ");
				scanf("%d",&opc2);
	  		 	switch(opc2){
					case 1:{
   	        		printf("QUANTIDADE DE REGISTROS NA LISTA: %d\n", imprimirQtdElemento(&lista));
   	        		system("pause");
    	        	break;
    	    		}	
    	    		case 2:{
    	    		imprimirLista(&lista);
					break;
					}default:{
    	        	system("cls");
    	        	printf("ERRO, OPCAO INVALIDA!!!\n");
    	        	system("pause");
    	        	break;
    	   			}
				}
			}while(opc2 != 1 && opc2 != 2); 
    	        break;
    	    }case 2:{
				printf("INFORME A POSICAO PARA BUSCA: ");
				scanf("%d",&posicao);
    	    	buscarPorChave(&lista,posicao); 
    	    		printf("1 - EDITAR ELEMENTO CHAVE\n");
    				printf("2 - EXCLUIR ELEMENTO CHAVE\n");
    				printf("0 - SAIR\n");
    				printf("DIGITE A OPCAO: ");
    				scanf("%d",&opc); 
    			switch(opc){ 
    			case 1:{
    				editarChave(&lista,posicao);
					break;
				}
				case 2:{
					excluirChave(&lista,posicao);
					break;
				}
				case 0:{
					break;
				}
				default:{
					system("cls");
					printf("ERRO, OPCAO INVALIDA");
					system("pause");
					break;
				}  	
				break;
			}
			case 3:{
				system("cls");
				printf("CHAVE: ");
    	    	scanf("%d",&registro.chave);
    	    	system("cls");
    	       	printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Inserir no Inicio\n");
    	       	printf("2 - Inserir no Fim\n");
    	       	printf("3 - Inserir por Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opc2);
    	    	switch(opc2){
    	    		case 1:{
    	    			inserirInicio(&lista,registro);
						break;
					}case 2:{
						inserirFinal(&lista,registro);
						break;
					}case 3:{
						system("cls");
						printf("INFORME POSICAO: ");
						scanf("%d",&posicao);
						inserirPosicao(&lista,registro,posicao);
						break;
					}
				}
				break;
			}
			case 4:{
				printf("INFORME A POSICAO PARA BUSCA: ");
				scanf("%d",&posicao);
				editarChave(&lista,posicao);
				break;
			}
			case 5:{
				printf("INFORME A POSICAO PARA BUSCA: ");
				scanf("%d",&posicao);
				excluirChave(&lista,posicao);
				break;
			}
			case 6:{
				salvarArquivo(&lista);
				break;
			}
			case 7:{
				carregarListaArq(&lista);
				break;
			}
			case 8:{
				reinicializarLista(&lista);
    			break;
			}case 9: {
				system("cls");
				printf("LISTA SERA FECHADA!\n");
				printf("Deseja gravar os registros da lista em Arquivo?\n");
				printf("0 - SIM\n");
				printf("1 - NAO\n");
    			printf("Opcao: ");
    			scanf("%d",&opc3);
    			system("cls");
    			switch(opc3){
    				case 0:{
    					salvarArquivo(&lista);
    					system("cls");
						printf("LISTA SALVA & ENCERRADA!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("pause");
						break;
					}
				}
				break;
			}default:{
					system("cls");
					printf("ERRO, OPCAO INVALIDA");
					system("pause");
					break;
				} 
			}
		}
	}while(opc!=9);
	
		return 0;
}

