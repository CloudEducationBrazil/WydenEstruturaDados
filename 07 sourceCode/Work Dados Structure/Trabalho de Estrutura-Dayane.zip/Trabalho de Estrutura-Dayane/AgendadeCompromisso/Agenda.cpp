#include <stdio.h>
#include <stdlib.h>
#define TAM_DESC 300
#include "Agenda.h"

LISTA* criarAgenda(){
	LISTA *lista = (LISTA*)malloc(sizeof(LISTA)); 
	if(lista != NULL)
        *lista = NULL;
	system("cls");
    printf("Agenda criada com sucesso!\n");
    system("pause");
    return lista;
}

int verificarAgenda(LISTA *lista, REGISTRO registro){
    LISTA auxiliar;
    if(*lista==NULL){
        return 0;
    }else{
        auxiliar = *lista;
        while(auxiliar->prox!= *lista && registro.chave!=auxiliar->registro.chave){
            auxiliar=auxiliar->prox;
        }
            if(registro.chave == auxiliar->registro.chave){
             return 1;   
            }else{
                return 0;
            }
        }
    }
    

void inserirInicio(LISTA *lista, REGISTRO registro){
	LISTA atual, auxiliar;
	int verificador = verificarAgenda(lista,registro);
	if(verificador==0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista==NULL){
			*lista = atual;
		    atual->prox = atual;
		}else{
			auxiliar = *lista;
			while(auxiliar->prox!=*lista)
				auxiliar = auxiliar->prox;
			auxiliar->prox = atual;
			atual->prox = *lista;
			*lista = atual;
		}
		system("cls");
		printf("Comprimisso inserido com sucesso!\n");
		system("color 01");
		system("pause");
	}else{
		system("cls");
		printf("Comprimisso ja inserido na Agenda!\n");
		system("color 01");
		system("pause");
	}
}

void inserirFinal(LISTA *lista, REGISTRO registro){
	LISTA atual, auxiliar;
	int verificador = verificarAgenda(lista,registro);
	if(verificador==0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista==NULL){
			*lista = atual;
			atual->prox = atual;
		}else{
			auxiliar = *lista;
			while(auxiliar->prox!=*lista){
				auxiliar = auxiliar->prox;
			}
			auxiliar->prox = atual;
			atual->prox = *lista;
		}
		system("cls");
		printf("Compromisso inserido com sucesso!\n");
		system("color 01");
		system("pause");
	}else{
		system("cls");
		printf("Compromisso ja inserido na Agenda!\n");
		system("color 01");
		system("pause");
	}
}

void inserirPosicao(LISTA *lista, REGISTRO registro, int posicao){
	LISTA atual, auxiliar, anterior;
	int verificador, tamanho, cont;
	verificador = verificarAgenda(lista,registro);
	tamanho = imprimirQuantidade(lista);
	cont = 0;
	if(verificador==0){
		atual = (LISTA)malloc(sizeof(struct lista));
		atual->registro = registro;
		if(*lista==NULL){
			*lista = atual;
			atual->prox = atual;
		}else if(posicao==0)
			inserirInicio(lista,registro);
		else if(posicao>=tamanho)
			inserirFinal(lista,registro);
		else{
			auxiliar = *lista;
			while(auxiliar->prox!=*lista && posicao!=cont){
				anterior = auxiliar;
				auxiliar = auxiliar->prox;
				cont++;
			}
			atual->prox = auxiliar;
			anterior->prox = atual;
			system("cls");
			printf("Comprimisso inserido com sucesso!\n");
			system("color 01");
			system("pause");
		}
	}else{
		system("cls");
		printf("Comprimisso ja inserido na Agenda!\n");
		system("color 01");
		system("pause");
	}
}


int imprimirQuantidade(LISTA *lista){
	LISTA auxiliar = *lista;
    int cont = 0;
	if(lista == NULL || (*lista) == NULL)
        return 0;
    do{
        cont++;
        auxiliar = auxiliar->prox;
    } while(auxiliar!=(*lista));
    return cont;
}

void imprimirAgenda(LISTA *lista){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(lista == NULL || (*lista) == NULL){
		system("color 84");
		printf("Agenda vazia!!!\n");
	}
	else{ 
		auxiliar = *lista;
		cont = 0;
		printf("POSICAO - ID - DATA - COMPROMISSO\n");
		do{
			printf("%05d - %05d - %d/%d/%d - %s",cont,auxiliar->registro.chave,auxiliar->registro.dia,auxiliar->registro.mes, auxiliar->registro.ano,auxiliar->registro.descricaoCompromisso);
			auxiliar = auxiliar->prox;
			cont++;
		} while(auxiliar!=*lista);
	}
	system("pause");
}

void buscarPosicao(LISTA *lista, int posicao){
	LISTA auxiliar;
	int cont, tamanho, opc;
	tamanho = imprimirQuantidade(lista);
	system("cls");
	if(*lista==NULL){
		printf("Agenda vazia!!!\n");
		system("color 84");
		system("pause");
	}
	else if(posicao<tamanho){
		auxiliar = *lista;
		cont = 0;
		while(posicao!=cont){ 
			auxiliar = auxiliar->prox;
			cont++;
		}
		printf("Registo encontrado!\n");
		system("color 06");
		printf("POSICAO - ID - DATA - COMPROMISSO\n");
		printf("%05d - %05d - %d/%d/%d - %s\n",posicao,auxiliar->registro.chave,auxiliar->registro.dia,auxiliar->registro.mes,auxiliar->registro.ano, auxiliar->registro.descricaoCompromisso);
		printf("Selecione uma das opcoes abaixo:\n\n");
    	printf("1 - Editar Registro\n");
    	printf("2 - Deletar Registro\n");
    	printf("9 - Sair\n");
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    		case 1:{
    			editarRegistro(lista,posicao);
				break;
			}
			case 2:{
				deletarPosicao(lista,posicao,0);
				break;
			}
			case 9:{
				system("cls");
				printf("Voce Voltara ao Menu!\n");
				system("color 05");
				system("pause");
				break;
			}
			default:{	
				system("cls");
				printf("Opcao Invalida!!!\nVoce Voltara ao Menu!\n");
				system("color 04");
				system("pause");
				break;
			}
		}
	}else{
		printf("Registro nao encontrado!\n");
		system("color 84");
		system("pause");
	}
}
void buscarChave(LISTA *lista, TIPOCHAVE chave){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("color 84");
		system("pause");
	}
	else{
		auxiliar = *lista;
		cont = 0;
		while(chave!=auxiliar->registro.chave){
			auxiliar = auxiliar->prox;
			cont++;
		}
		if(chave==auxiliar->registro.chave)
			buscarPosicao(lista,cont);
		else{
			printf("Registro nao encontrado!\n");
			system("color 84");
			system("pause");
		}
	}
}

void deletarPosicao(LISTA *lista, int posicao, int verificador){
	LISTA auxiliar, anterior;
	int cont, tamanho;
	tamanho = imprimirQuantidade(lista);
	auxiliar = *lista;
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("color 84");
		system("pause");
	}else if((*lista) == (*lista)->prox){
        free(*lista);
        *lista = NULL;
    }
	else if(posicao==0){ 
	    	while(auxiliar->prox!=(*lista))
        		auxiliar = auxiliar->prox;
        	anterior = *lista;
        	auxiliar->prox = anterior->prox;
			*lista = anterior->prox;
			free(anterior);
			if(verificador==0){
				system("color 06");
				printf("Registro deletado com sucesso!\n");
			} 		
	}else if(posicao==tamanho-1){ 
		cont = 0;
		while(posicao!=cont){ 
			anterior = auxiliar;
			auxiliar = auxiliar->prox;
			cont++;
		}
		anterior->prox = *lista;
		free(auxiliar);
		if(verificador==0){
			system("color 06");
			printf("Registro deletado com sucesso!\n");	
		}
	}
	else if(posicao<tamanho){ 
		cont = 0;
		while(posicao!=cont){
			anterior = auxiliar;
			auxiliar = auxiliar->prox;
			cont++;
		}
		anterior->prox = auxiliar->prox;
		free(auxiliar);
		if(verificador==0){
			system("color 06");
			printf("Registro deletado com sucesso!\n");	
		}
	}else{
			system("color 06");
			printf("Registro deletado com sucesso!\n");	
		}
	if(verificador==0)
		system("pause");
}

void deletarChave(LISTA *lista, TIPOCHAVE chave){
	LISTA auxiliar;
	int cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("color 84");
		system("pause");
	}
	else{
		auxiliar = *lista;
		cont = 0;
		while(chave!=auxiliar->registro.chave){
			auxiliar = auxiliar->prox;
			cont++;
		}
		if(chave==auxiliar->registro.chave)
			deletarPosicao(lista,cont,0);
		else{
			printf("Registro nao encontrado!\n");
			system("color 04");
			system("pause");
		}
	}
}

void editarRegistro(LISTA *lista, int posicao){
	LISTA auxiliar;
	REGISTRO registro;
	int cont, tamanho;
	tamanho = imprimirQuantidade(lista);
	system("cls");
	if(*lista==NULL){
		printf("Lista Vazia!\n");
		system("color 84");
	}else if(posicao<tamanho){
		auxiliar = *lista;
		cont = 0;
		while(auxiliar->prox!=*lista && posicao!=cont){
			auxiliar = auxiliar->prox;
			cont++;
		}
		printf("Registo encontrado!\n");
		printf("POSICAO - ID - DATA - COMPROMISSO\n");
		printf("%05d - %05d - %d/%d/%d - %s\n",posicao,auxiliar->registro.chave,auxiliar->registro.dia,auxiliar->registro.mes,auxiliar->registro.ano, auxiliar->registro.descricaoCompromisso);
		printf("Informe o numero de Chave na Agenda: ");
		scanf("%d",&registro.chave);
		printf("Informe a data:\n");
		printf("\nInforme dia:");
		scanf("%d", &registro.dia);
		printf("\nInforme mes:");
		scanf("%d", &registro.mes);
		printf("\nInforme ano:");
		scanf("%d", &registro.ano);
		fflush(stdin);	
		fgets(registro.descricaoCompromisso,TAM_DESC,stdin);
		auxiliar->registro = registro;
		system("cls");
		printf("Registro editado com sucesso!\n");
		system("color 06");
	}else{
		printf("Erro!\n");
		printf("Registro nao encontrado!\n");
		system("color 04");
	}
	system("pause");
}

void reiniciarLista(LISTA *lista){ //Reiniciar a lista � deletador todos os n�s
	int opc, tamanho, i;
	system("cls");
	system("color 05");
	printf("Voce deseja Reinicializar a Estrutura?\n");
	printf("0 - SIM\n");
	printf("1 - NAO\n");
    printf("Opcao: ");
    scanf("%d",&opc);
    system("cls");
    switch(opc){
    	case 0:{
			tamanho = imprimirQuantidade(lista);
			for(i=tamanho-1;i>=0;i--){
			deletarPosicao(lista,i,1); 
			printf("Lista reinicializada com Sucesso!\n");	
			}
			system("color 01");
			break;
		}
		case 1:{
			printf("Voce voltara ao Menu!\n");
			break;
		}
		default:{
			printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
			system("color 04");
			break;
		}
	}
    system("pause");
}

void gravarArquivo(LISTA *lista){
	FILE *arquivo;
	LISTA auxiliar;
	int i, cont;
	system("cls");
	if(*lista==NULL){
		printf("Lista vazia!\n");
		printf("Arquivo nao sera criado!\n");
	}else{
		arquivo = fopen ("ScheduleCommitments.txt","w");
		if(arquivo==NULL){
			printf("Erro ao criar arquivo.\n");
			system("pause");
		}else{
			auxiliar = *lista;
			cont = 0;
			fprintf(arquivo,"POSICAO - ID - DATA - COMPROMISSO\n");
			do{
				fprintf(arquivo,"%05d - %05d - %d/%d/%d - %s\n",cont,auxiliar->registro.chave,auxiliar->registro.dia,auxiliar->registro.mes,auxiliar->registro.ano, auxiliar->registro.descricaoCompromisso);
				auxiliar = auxiliar->prox;
				cont++;
			} while(auxiliar!=*lista);
			printf("Arquivo gravado com sucesso!\n");
		}
		fclose(arquivo);
	}
	system("pause");
}
