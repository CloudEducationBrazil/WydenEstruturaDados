#include <stdio.h>
#include <stdlib.h>
#define TAM_DESC 300
#include "Agenda.h"

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	LISTA *lista;
    REGISTRO registro;
    TIPOCHAVE chave;
    int opc, opc2, posicao, opcAux, tamanho;
    opc=0;
        do{
		system("cls");
    	printf("Seja Bem-vindo ao Menu!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
   		printf("1 - Criar Uma AGENDA\n");
		printf("0 - Sair\n");		
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    	    case 1:{
    	    	lista = criarAgenda();
				break;
			}
			case 0:{
				exit(1);
				break;
			}
			default:{
    	        system("cls");
    	        printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
    	        system("pause");
    	        break;
    	    }
		}
	}while(opc!=1);
			
	do{
        system("cls");
    	printf("Seja bem-vindo ao Menu!\n");
   		printf("Selecione uma das opcoes abaixo:\n\n");
    	printf("1 - Exibir Registros da AGENDA\n");
    	printf("2 - Buscar\n");
    	printf("3 - Inserir Registro\n");
    	printf("4 - Editar Registro\n");
    	printf("5 - Excluir Registro\n");
    	printf("6 - Gravar Registros em Arquivo\n");
    	printf("7 - Reinicializar a Estrutura\n");
    	printf("8 - Sair\n");
    	printf("Opcao: ");
    	scanf("%d",&opc);
    	switch(opc){
    	    case 1:{
    			do{
				system("cls");
				printf("O DESEJA EXIBIR?\n");
				printf("1 - QUANTIDADE DE REGISTROS NA AGENDA?\n");
				printf("2 - OS REGISTROS NA AGENDA?\n");
				printf("INFORME OPCAO: ");
				scanf("%d",&opc2);
	  		 	switch(opc2){
					case 1:{
					tamanho = imprimirQuantidade(lista);
   	        		printf("QUANTIDADE DE REGISTROS NA AGENDA: %d\n", tamanho);
   	        		system("pause");
    	        	break;
    	    		}	
    	    		case 2:{
    	    		imprimirAgenda(lista);
					break;
					}default:{
    	        	system("cls");
    	        	printf("ERRO, OPCAO INVALIDA!!!\n");
    	        	system("color 04");
    	        	system("pause");
    	        	break;
    	   			}
				}
			}while(opc2 != 1 && opc2 != 2); 
    	        break;
			}case 2:{
				system("cls");
    	       	printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Buscar por numero da Chave na Agenda:\n");
    	       	printf("2 - Buscar por indice da Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	switch(opcAux){
    	    		case 1:{
						printf("Informe o numero da Chave na Agenda: ");
						scanf("%d",&chave);
						buscarChave(lista,chave);
						break;
					}
					case 2:{
						printf("Informe o indice da Posicao: ");
    	    			scanf("%d",&posicao);
    	    			buscarPosicao(lista,posicao);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("color 04");
						system("pause");
						break;
					}
				}
				break;
			}
			case 3:{
				system("cls");
    	       	printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Inserir no Inicio\n");
    	       	printf("2 - Inserir no Fim\n");
    	       	printf("3 - Inserir em uma Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	if(opcAux == 1 || opcAux == 2 || opcAux == 3){
    	    		printf("Informe o numero de Chave na Agenda: "); 	    		
    	    		scanf("%d",&registro.chave);
					printf("Informe a data:\n");
					printf("\nInforme dia:");
					scanf("%d", &registro.dia);
					printf("\nInforme mes:");
					scanf("%d", &registro.mes);
					printf("\nInforme ano:");
					scanf("%d", &registro.ano);
					printf("\nInforme o compromisso:");
					fflush(stdin);	
					fgets(registro.descricaoCompromisso,TAM_DESC,stdin);
				}
    	    	switch(opcAux){
    	    		case 1:{
    	    			inserirInicio(lista,registro);
						break;
					}
					case 2:{
						inserirFinal(lista,registro);
						break;
					}
					case 3:{
						printf("Informe o indice da Posicao: ");
						scanf("%d",&posicao);
						inserirPosicao(lista,registro,posicao);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("color 04");
						system("pause");
						break;
					}
				}
				break;
			}
			case 4:{
				system("cls");
				printf("Informe o indice da Posicao do Registro na Agenda: ");
				scanf("%d",&posicao);
				editarRegistro(lista,posicao);
				break;
			}
			case 5:{
				system("cls");
				printf("Selecione uma das opcoes abaixo: \n\n");
    	       	printf("1 - Deletar pelo numero de Chave\n");
    	       	printf("2 - Deletar pelo indice da Posicao\n");
    	       	printf("Opcao: ");
    	    	scanf("%d",&opcAux);
    	    	system("cls");
    	    	switch(opcAux){
    	    		case 1:{
						printf("Informe o numero de Chave: ");
						scanf("%d",&chave);
						deletarChave(lista,chave);
						break;
					}
    	    		case 2:{
						printf("Informe o indice da Posicao:  ");
						scanf("%d",&posicao);
						deletarPosicao(lista,posicao,0);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("color 04");
						system("pause");
						break;
					}
				}
				break;
			}
			case 6:{
				gravarArquivo(lista);
				break;
			}
			case 7:{
				reiniciarLista(lista);
				break;
			}
			case 8:{
				system("cls");
				printf("AGENDA sera fechada!\n");
				printf("Deseja gravar os registros em Arquivo?\n");
				printf("0 - SIM\n");
				printf("1 - NAO\n");
    			printf("Opcao: ");
    			scanf("%d",&opcAux);
    			system("cls");
    			switch(opcAux){
    				case 0:{
    					gravarArquivo(lista);
    					system("cls");
						printf("Agenda Encerrada!\n");
						system("pause");
						exit(1);
						break;
					}
					case 1:{
						printf("Programa encerrado!\n");
						system("pause");
						exit(1);
						break;
					}
					default:{
						printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
						system("color 04");
						system("pause");
						break;
					}
				}
				break;
			}
    	    default:{
				system("cls");
				printf("Opcao Invalida!\nVoce Voltara ao Menu!\n");
				system("color 04");
				system("pause");
				break;
			}
		}
	}while(opc!=8);
	
	return 0;
}
