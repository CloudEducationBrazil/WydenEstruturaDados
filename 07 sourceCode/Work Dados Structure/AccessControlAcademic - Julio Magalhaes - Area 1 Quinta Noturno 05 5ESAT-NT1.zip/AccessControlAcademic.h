#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

// Acesso Academico de Alunos
// Aluno: Julio Magalhaes
// Data: 25/04/2019

typedef int TIPOCHAVE;
typedef struct
{
	//Controle ID
	TIPOCHAVE chave;
	// Matr�cula do Aluno
	char matricula[20];
	// Descricao da Ocorrencia (Esqueceu/Perdeu/NaoPossui/Outros cartao)
	char TipoOcorrencia[10];
} Registro;

typedef struct
{
	char matricula[20];
	char TipoOcorrencia[10];
} RegistroSaveType;

typedef struct lista
{
	Registro registro;
	struct lista *proximo;
} Lista;

//1.Criar Lista (Inicializar Lista)
Lista *Criar()
{
	Lista *nova_lista = NULL;
	return nova_lista;
}

//2.Verificar Tamanho da Lista
int Tamanho(Lista **lista)
{
	Lista *atual = (*lista);
	int retorno = 0;
	if ((*lista) == NULL)
	{
		return retorno;
	}

	do
	{
		if (atual->proximo != NULL)
		{
			atual = atual->proximo;
			retorno += 1;
		}
		else
		{
			return retorno + 1;
		}
	} while (true);
	return -1;
}

//3.Exibir Elementos da Lista
void Exibir(Lista **lista)
{
	if ((*lista) == NULL)
	{
		return;
	}

	Lista *atual = (*lista);
	do
	{
		printf("\nChave: ");
		printf("%d;", atual->registro.chave);

		printf(" Matricula: ");
		printf("%s;", atual->registro.matricula);

		printf(" Ocorrencia: ");
		printf("%s;", atual->registro.TipoOcorrencia);

		if (atual->proximo != NULL)
		{
			atual = atual->proximo;
		}
		else
		{
			return;
		}
	} while (true);
}

//4.Consultar Elementos na Lista
TIPOCHAVE Consultar(Lista **lista, TIPOCHAVE chave)
{
	Lista *atual = (*lista);
	TIPOCHAVE retorno;

	if ((*lista) == NULL)
	{
		return -1;
	}

	do
	{
		if (atual->registro.chave == chave)
		{
			return atual->registro.chave;
		}
		if (atual->proximo != NULL)
		{
			atual = atual->proximo;
		}
		else
		{
			break;
		}
	} while (true);
	return -1;
}

//5.Inserir Elemento na Lista
bool Inserir(Lista **lista, Registro registro)
{
	Registro novo_registro;
	strcpy(novo_registro.matricula, "                    ");
	strcpy(novo_registro.TipoOcorrencia, "          ");
	strcpy(novo_registro.matricula, registro.matricula);
	strcpy(novo_registro.TipoOcorrencia, registro.TipoOcorrencia);

	if ((*lista) == NULL)
	{
		(*lista) = malloc(sizeof(Lista));
		//if(registro.chave < 0) registro.chave = 0;
		(*lista)->registro = registro;
		(*lista)->proximo = NULL;
		return true;
	}

	Lista *ultimo = (*lista);
	TIPOCHAVE nova_chave;

	if (Consultar(lista, registro.chave) > -1)
	{
		nova_chave = ultimo->registro.chave + 1;
	}
	else
	{
		nova_chave = registro.chave;
	}

	do
	{
		if (ultimo->registro.chave >= nova_chave)
		{
			nova_chave = ultimo->registro.chave + 1;
		}
		else if (ultimo->proximo == NULL)
		{
			break;
		}

		if (ultimo->proximo == NULL)
			break;

		ultimo = ultimo->proximo;

	} while (true);

	Lista *nova_lista = malloc(sizeof(Lista));
	ultimo->proximo = nova_lista;
	registro.chave = nova_chave;
	nova_lista->registro = registro;
	nova_lista->proximo = NULL;

	return true;
}

//6.Alterar Elemento da Lista
bool Alterar(Lista **lista, TIPOCHAVE chave, Registro registro)
{

	if (lista == NULL || Consultar(lista, registro.chave) == -1)
		return false;
	Lista *atual = (*lista);

	while (true)
	{
		if (atual->registro.chave == chave)
		{
			strcpy(atual->registro.TipoOcorrencia, registro.TipoOcorrencia);
			strcpy(atual->registro.matricula, registro.matricula);
			return true;
		}

		if (atual->proximo != NULL)
		{
			atual = atual->proximo;
		}
		else
		{
			return false;
		}
	}
	return false;
}

//7.Excluir Elemento da Lista
bool Excluir(Lista **lista, TIPOCHAVE chave)
{

	if (lista == NULL || Consultar(lista, chave) == -1)
		return false;

	Lista *anterior = NULL;
	Lista *apagar = (*lista);
	Lista *proximo = NULL;

	do
	{
		if (apagar->registro.chave == chave)
		{
			if (anterior != NULL)
			{
				anterior->proximo = apagar->proximo;
				return true;
			}
			else
			{
				free(apagar);
				(*lista) = Criar();
				return true;
			}
		}
		anterior = apagar;
		if (apagar->proximo != NULL)
		{
			apagar = apagar->proximo;
		}
		else
		{
			break;
		}

	} while (true);

	return false;
}

//8.Salvar Lista
void Salvar(Lista **lista)
{
	FILE *outfile;
	// open file for writing
	outfile = fopen("AccessControl.academic", "w");
	if (outfile == NULL)
	{
		fprintf(stderr, "\nError opend file\n");
		exit(1);
	}

	Lista *atual = (*lista);
	char break_line[] = "\n";

	RegistroSaveType registro_save;

	while (atual != NULL)
	{
		strcpy(registro_save.matricula, atual->registro.matricula);
		strcpy(registro_save.TipoOcorrencia, atual->registro.TipoOcorrencia);

		fwrite((void *)&(registro_save), sizeof(RegistroSaveType), 1, outfile);
		atual = atual->proximo;
	}

	if (fwrite != 0)
		printf("Arquivo salvo com sucesso !\n");

	// close file
	fclose(outfile);
}

//9.Carregar Lista
Lista *Carregar()
{
	Lista *lista_salva;
	lista_salva = Criar();
	Registro registro;

	FILE *infile;

	infile = fopen("AccessControl.academic", "r");
	if (infile == NULL)
	{
		fprintf(stderr, "\nErro ao abrir arquivo\n");
		exit(1);
	}

	TIPOCHAVE chave = 0;
	RegistroSaveType registro_save;
	printf("Carregado:\n");
	while (fread((void *)&(registro_save), sizeof(RegistroSaveType), 1, infile))
	{
		printf("Matricula = %s; TipoOcorrencia = %s\n", registro_save.matricula, registro_save.TipoOcorrencia);
		registro.chave = chave;
		strcpy(registro.matricula, registro_save.matricula);
		strcpy(registro.TipoOcorrencia, registro_save.TipoOcorrencia);
		Inserir(&lista_salva, registro);
		chave++;
	}

	fclose(infile);

	return lista_salva;
}

//10.Reinicializar Lista
bool Reinicializar(Lista **lista)
{
	Lista *atual = (*lista);
	if (atual == NULL)
	{
		return false;
	}

	Lista *proximo = NULL;
	while (atual->proximo != NULL)
	{
		proximo = atual->proximo;
		free(atual);
		atual = proximo;
	}

	(*lista) = Criar();
	return true;
}
