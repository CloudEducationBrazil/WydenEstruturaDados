#include <stdio.h>
#include <stdlib.h>
#include "AccessControlAcademic.h"

// Acesso Academico de Alunos
// Aluno: J�lio Magalh�es
// Data: 25/04/2019
void executarMenu();
void executarSelecionado(int opcaoSelecionada);
int exibirOpcoes();
Lista *lista;

int main(int argc, char *argv[])
{

	executarMenu();
	
	return 0;
}

void executarMenu()
{
	bool finalizarPrograma = false;
	int opcaoSelecionada;
	do
	{
		opcaoSelecionada = exibirOpcoes();
		if (opcaoSelecionada == 0)
		{
			finalizarPrograma = true;
		}
		else
		{
			executarSelecionado(opcaoSelecionada);
		}
	} while (!finalizarPrograma);
}

int exibirOpcoes()
{
	int entradaUsuario = 0;
	do
	{
		printf("\n Menu:");
		printf("\n 1.Criar Lista");
		printf("\n 2.Verificar Tamanho da Lista");
		printf("\n 3.Exibir Elementos da Lista");
		printf("\n 4.Consultar Elementos na Lista");
		printf("\n 5.Inserir Elemento na Lista");
		printf("\n 6.Alterar Elemento da Lista");
		printf("\n 7.Excluir Elemento da Lista");
		printf("\n 8.Salvar Lista");
		printf("\n 9.Carregar Lista");
		printf("\n 10.Reinicializar Lista");
		printf("\n 0.Sair do Programa");
		scanf("%d", &entradaUsuario);

		if (entradaUsuario < 0 && entradaUsuario > 10)
		{
			system("cls");
			printf("Insira uma entrada v?lida");
			entradaUsuario = 0;
		}else{
			executarSelecionado(entradaUsuario);
		}

	} while (entradaUsuario != 0);
	return entradaUsuario;
}

void executarSelecionado(int opcaoSelecionada)
{
	Registro registro;
	int entradaUsuario = 0;
	int elemento = 0;
	system("cls");
	switch (opcaoSelecionada)
	{
	case 1:
		lista = Criar();
		printf("Lista criada!!");
		break;
		
	case 2:
		printf("Tamanho da lista: %d", Tamanho(&lista));
		break;
		
	case 3:
		Exibir(&lista);
		break;
		
	case 4:
		printf("\nInsira a chave do elemento: ");
		scanf("%d", &entradaUsuario);
		elemento = Consultar(&lista, entradaUsuario);
		if (elemento == -1)
			printf("\nElemento nao encontrado");
		else
			printf("Existe um elemento com a chave: %s localizado na %s posicao da lista", entradaUsuario, elemento);
		break;
		
	case 5:
	
		printf("Insira matricula: (20 caracteres)");
		scanf("%s", &registro.matricula);
		
		printf("Insira o tipo da ocorrencia: (10 caracteres)");
		scanf("%s", &registro.TipoOcorrencia);
		
		if (Inserir(&lista, registro))
		{
			printf("Matricula: %s ocorrencia: %s \n inserido com sucesso.", registro.matricula, registro.TipoOcorrencia);
		}
		else
		{
			printf("Matricula: %s ocorrencia: %s \n nao foi inserido", registro.matricula, registro.TipoOcorrencia);
		}
		break;

	case 6:
		entradaUsuario = 0;

		printf("\nInsira a chave do elemento a alterar:");
		scanf("%d", &entradaUsuario);

		printf("Insira matricula: (20 caracteres)");
		scanf("%s", &registro.matricula);
		
		printf("Insira o tipo da ocorrencia: (10 caracteres)");
		scanf("%s", &registro.TipoOcorrencia);

		if (Alterar(&lista, entradaUsuario, registro))
		{
			printf("\n Matricula: %s ocorrencia: %s alterado com sucesso.", registro.matricula, registro.TipoOcorrencia);
		}
		else
		{
			printf("\n Elemento nao foi alterado.");
		}
		break;
		
	case 7:
		entradaUsuario = 0;

		printf("\nInsira a chave do elemento a excluir:");
		scanf("%d", &entradaUsuario);

	
		if (Excluir(&lista, entradaUsuario))
		{
			printf("Excluido com sucesso.");
		}
		else
		{
			printf("Nao foi excluido.");
		}
		break;
		
	case 8:
		printf("Salvar Lista");
		Salvar(&lista);
		break;
		
	case 9:
		printf("Carregar Lista");
		lista = Carregar();
		break;
		
	case 10:
		Reinicializar(&lista);
		printf("Lista reinicializada com sucesso");		
		break;
	}
}
