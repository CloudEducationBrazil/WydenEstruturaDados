#include <stdio.h>
#include <stdlib.h>
#include <locale.h> 
#include <string.h>
#include "InclusionNumbersIntegers.h"
#include "ScheduleCommitments.h"
#include "AccessControlAcademic.h"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */



void menu1() {
		system("CLS");
		printf("0 - InclusionNumbersIntegers \n");
		printf("1 - ScheduleCommitments \n");
		printf("2 - AccessControlAcademic \n");
		printf("3 - Sair do Sistema \n");

};

void AccessControlAcademic(){
	lista l;
	Ocorrencia reg;
	inicializarListaOcorrencia(&l);
	int opc4;
	int chave;
	
	do{
		menuOcorrencia();
		printf("Selecione Opcao? "); scanf("%d", &opc4);
		switch(opc4){
			case 0: printf("[Lista Inicializada]\n"); inicializarListaOcorrencia(&l); break;
			case 1 : printf("[Tamanho lista] : %d",tamanho(&l)); break;
			case 2 : exibirListaOcorrencia(&l);break;
			case 3 : {
				Ocorrencia or;
				int ocorenciaopc;
				setlocale(LC_ALL, "Portuguese");
				
				printf("[Inserir Ocorrencia na Lista]\n"); 
				printf("CHAVE :");scanf("%d",&or.chave);
				printf("[Dados do Porteiro]\n");
				printf("NOME :");scanf(" %[^\n]s",&or.porteiro.nomePorteiro);
				printf("[Dados do Aluno]\n");
				printf("MATRICULA:");scanf(" %[^\n]s",&or.matricula);
				printf("[OCORR�NCIA]\n");
				printf("TIPO:\n");
				printf("0 - Esqueceu \n");
				printf("1 - Perdeu \n");
				printf("2 - N�o Possui \n");
				printf("3 - Outros cart�o \n");
				
				printf("OPS:");	scanf("%d",&ocorenciaopc);
				switch(ocorenciaopc){
					case 0 : strcpy(or.TipoOcorrencia,"Esqueceu");break;
					case 1 : strcpy(or.TipoOcorrencia,"Perdeu");break;
					case 2 : strcpy(or.TipoOcorrencia,"N�o Possui");break;
					case 3 : strcpy(or.TipoOcorrencia,"Outros cart�o");break;
				}
				
				
				if(inserirElemLista(&l,or,or.chave)){
				printf("Elemento %i inserido corretamente.\n",or.chave);
				}else{
					 printf("Nao foi possivel inserir elemento %i.\n \n",or.chave);
				break;
				}
				break;		
			}
			case 4 : printf("[Modulo Alteracao] Digite Posi��o para alteracao?");scanf("%d", &chave);
			if (buscaOcorrencia(&l, chave) >= 0 ) 
			{
				Ocorrencia or;
				int ocorenciaopc;
				printf("[Inserir Ocorrencia na Lista]\n"); 
				printf("CHAVE :");scanf("%d",&or.chave);
				printf("[Dados do Porteiro]\n");
				printf("NOME :");scanf(" %[^\n]s",&or.porteiro.nomePorteiro);
				printf("[Dados do Aluno]\n");
				printf("MATRICULA:");scanf(" %[^\n]s",&or.matricula);
				printf("[OCORR�NCIA]\n");
				printf("TIPO:\n");
				printf("0 - Esqueceu \n");
				printf("1 - Perdeu \n");
				printf("2 - N�o Possui \n");
				printf("3 - Outros cart�o \n");
				
				printf("OPS:");	scanf("%d",&ocorenciaopc);
				switch(ocorenciaopc){
					case 0 : strcpy(or.TipoOcorrencia,"Esqueceu");break;
					case 1 : strcpy(or.TipoOcorrencia,"Perdeu");break;
					case 2 : strcpy(or.TipoOcorrencia,"N�o Possui");break;
					case 3 : strcpy(or.TipoOcorrencia,"Outros cart�o");break;
				}
				
				
				
				
				if(alterarListaOcorrencia(&l,or,chave)){
					printf("Elemento %i Alterado corretamente.\n",or.chave);
				}else{
					printf("Nao foi possivel Alterar elemento %i.\n \n",or.chave);
				}
					
			} else {
					printf("\n Registro nao Encontrado"); 
					break;
			}
			
				
			break;
						
			case 5 : printf("[Modulo Exclusao] Digite Elemento a ser Excluido?");scanf("%d", &chave); 
				    if (excluirElemListaOcorrencia(chave,&l) == true ) printf("Elemento EXCLUIDO..."); else printf("Elemento nao encontrado!!!"); break;
			case 6 : printf("[Modulo Consulta] Digite Elemento a ser Consultado?");scanf("%d", &chave);
			        if (buscaOcorrencia(&l, chave) >= 0 ) printf("\n Registro Encontrado"); else printf("\n Registro nao Encontrado"); break;
			case 7 : SalvarListaOcorrencia(&l);break;
			case 8 : CarregarListaOcorrencia(&l);break;
			case 9 : printf("[Lista Reinicializada ]\n"); inicializarListaOcorrencia(&l); break;
		}	
			
			printf("\n\n");
			system("PAUSE"); 	
	}while(opc4 != 10);
} 


void ScheduleCommitments(){
	LISTA l;
	Compromisso reg;
	criarListaDinamica(&l);
	
	int opc3;
	
	do{
		menuDinamica();
		printf("Selecione Opcao? "); scanf("%d", &opc3);
		switch(opc3){
			
			case 0: printf("[Lista Inicializada]\n"); criarListaDinamica(&l); break;
			case 1 : printf("[Tamanho lista] : %d",tamanhoListaDinamica(&l)); break;
			case 2 : exibirListaDinamica(&l);break;
			case 3 : {
				Compromisso cp; 
				dataRef data;
				TIPOCHAVE chave;
				setlocale(LC_ALL, "Portuguese");
				printf("[Inserir Compromisso na Lista]\n"); 
				printf("[DATA]\n"); 
				printf("DIA :");scanf("%d",&data.dia);
				printf("M�S :");scanf("%d",&data.mes);
				printf("ANO :");scanf("%d",&data.ano);
				printf("[COMPROMISSO]\n"); 
				printf("[CHAVE] :");scanf("%d",&chave);
				printf("[DESCRI��O] :"); scanf(" %[^\n]s",cp.descricaoCompromisso);
				fflush(stdin);
				cp.dataCompromisso = data;
				cp.chave = chave;
				
			if (inserirElemListaOrd(&l,cp)) printf("Elemento %i inserido corretamente.\n",chave);
 				else printf("Nao foi possivel inserir elemento %i.\n \n",chave);
				break;
			}
			case 4 : {
				
				Compromisso cp; 
				dataRef data;
				TIPOCHAVE chave;
				setlocale(LC_ALL, "Portuguese");
				printf("[Atualizar Compromisso na Lista]\n");
				printf("[CHAVE] :");scanf("%d",&chave); 
				
				if(buscaSeqOrd(&l,chave)!= NULL){
					
					cp.chave = chave;
					
					printf("[DATA]\n"); 
					printf("DIA :");scanf("%d",&data.dia);
					printf("M�S :");scanf("%d",&data.mes);
					printf("ANO :");scanf("%d",&data.ano);
					printf("[COMPROMISSO]\n"); 
		
					printf("[DESCRI��O] :"); scanf(" %[^\n]s",cp.descricaoCompromisso);
					fflush(stdin);
					cp.dataCompromisso = data;
					
					
					if(AlterarElemenLista(&l,cp)){
						printf("Elemento %i alterado  corretamente.\n",chave);
					}else{
						printf("Nao foi possivel alterar elemento %i.\n \n",chave);
					}
					
				}
			
				
				break;
			}
			case 5 :  {
			  TIPOCHAVE ch;
			  printf("Digite Elemento ? ");
			  scanf("%i",&ch);
			  if (excluirElemLista(&l,ch)) printf("Elemento %i excluido corretamente.\n",ch);
			  else printf("Nao foi possivel excluir elemento %i.\n \n",ch);
			  
			  getchar();  
			   break;
			}
			
			case 6 :{
				TIPOCHAVE ch;
				printf("Digite chave :"); 
  				scanf("%i",&ch);
  				pont posicao = buscaSeqOrd(&l,ch);
  				
  				 if (posicao != NULL){
  				 	printf("Elemento %i encontrado no endereco:\n",ch);
  				 	  	printf("====================Compromisso %d==========================\n",ch);
					    printf("CHAVE : %d \n", posicao->dado.chave);
					    printf("DATA : %d/%d/%d \n", posicao->dado.dataCompromisso.dia,posicao->dado.dataCompromisso.mes,posicao->dado.dataCompromisso.ano);
					    printf("DESCRICAO : %s \n",posicao->dado.descricaoCompromisso);
					    printf("===============================================================\n");
  				 		
				   } 
  				else printf("Nao foi possivel encontrar elemento %i.\n \n",ch);
				break;
			}
			case 7 : SalvarListaDinamica(&l);break;
			case 8 : RecuperarListaDinamica(&l);break;
			case  9 : printf("[Reinicializar Lista ]\n"); criarListaDinamica(&l); break;
			case 10:  break;
	    	default:
		        printf("Voltando ....\n");
			
		}
			printf("\n\n");
			system("PAUSE"); 
			
		
	}while ( opc3 != 10);
	
	
	
}



void InclusionNumbersIntegers(){
	
	Registro reg;
	Lista l; 

	inicializaLista(&l);	
	int opc;
	int pos;
	int chave;
		
	
	do {
		menu();
	    printf("Selecione Opcao? "); scanf("%d", &opc);
	    
	    switch (opc) {
	    	case 0: printf("[Lista Inicializada]\n"); inicializaLista(&l); break;
	    	case 1: printf("[Tamanho da Lista]\n"); tamanhoLista(&l); break;
	    	case 2: printf("[Exibindo Lista] \n"); exibeLista(&l); break;

	    	case 3: printf("[Modulo Inclusao] Digite Elemento?");scanf("%d", &reg); 
	    	        printf("Digite Posicao?");scanf("%d", &pos); 
			        if ( inserirLista(&l, reg, pos) == true ) printf("Elemento INSERIDO..."); else printf("Posicao Invalida, buraco na Lista. Nenhum elemento inserido..."); break;

	    	case 4: inserirListaCompleta(&l); break;

	    	case 5: printf("[Modulo Alteracao] Digite Elemento para alteracao?");scanf("%d", &chave); 
	    	        printf("Digite Posicao?");scanf("%d", &pos); 
					if ( alterarLista(&l, chave, pos) == true ) printf("Elemento ALTERADO..."); else printf("Posicao INVALDA!!!"); break;

	    	case 6: printf("[Modulo Exclusao] Digite Elemento a ser Excluido?");scanf("%d", &chave); 
				    if ( excluirLista(&l, chave) == true ) printf("Elemento EXCLUIDO..."); else printf("Elemento nao encontrado!!!"); break;
				    
	    	case 7: printf("[Modulo Consulta] Digite Elemento a ser Consultado?");scanf("%d", &chave);
			        if ( buscarLista(&l, chave) >= 0 ) printf("\n Registro Encontrado"); else printf("\n Registro nao Encontrado"); break;
			case 8 : SalvarLista(&l); break;
			case 9 :RecuperarLista(&l);  break; 
	    	case 11:  break;
	    	
	    	default:
	        printf("Voltando ....\n");
			}
			
			printf("\n\n");
		    system("PAUSE");  
	   } while ( opc != 11);
}



int main(int argc, char *argv[]) {
	int opc2;
	 	setlocale(LC_ALL, "Portuguese");
		printf("%s \n",setlocale(LC_ALL,"Portuguese"));
	do{
		menu1();
	    printf("Selecione Opcao? "); scanf("%d", &opc2);
		 switch (opc2) {
		 case 0:InclusionNumbersIntegers();break; 
		 case 1 : ScheduleCommitments();break; 
		 case 2 : AccessControlAcademic();break;
		 
		 }
		 
		
		
	}while(opc2 != 4);
	
	

	
	return 0;
}
