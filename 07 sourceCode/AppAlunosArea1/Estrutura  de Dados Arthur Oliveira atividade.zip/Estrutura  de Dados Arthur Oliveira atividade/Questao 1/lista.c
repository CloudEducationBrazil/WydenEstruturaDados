#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lista.h"

struct lista
{
	int info;
	char mat[20];
	
	struct lista* prox;
};

Lista* criar_lista()
{
	return NULL;
}

Lista* inserir_lista(Lista* l, int i, char m[20])
{
	int k;

	Lista* novo = (Lista*)malloc(sizeof(Lista));
	novo->info = i;
	novo->prox = l;
	
	for(k=0; k< strlen(m); k++){
		
		novo->mat[k] = m[k];
		
	}
	

	return novo;

}


void imprimir_lista(Lista* l)
{
	Lista* p;
	int i = 1;
	printf("\n###### LISTA ######\n");
	for(p = l; p != NULL; p = p->prox){
		
		printf("%do Elemento ID: %d e MATRICULA: %s\n", i, p->info, p->mat);
		i++;
	}
}

void verificar_tamanho_lista(Lista* l)
{
	Lista* p;
	int i =0;
	for(p = l; p != NULL; p = p->prox){
		i++;
	}
	printf("Tamanho da Lista eh = %d \n", i);
}

Lista* buscar(Lista* l, int v)
{

	Lista* p;

	for(p = l; p != NULL; p = p->prox)
	{
		if(p->info == v)
		{
			return p;
		}
	}
	return NULL;
}

Lista* remover (Lista* l, int v)
{
	Lista* ant = NULL; // ponteiro para elemento anterior
	Lista* p = l; // ponteiro para percorrer a lista

	while(p != NULL && p->info != v)
	{
		ant = p;
		p = p->prox;

	}

	if(p == NULL)
		return l;

	if(ant == NULL)
	{
		//remove do inicio da lista
		l = p->prox;
	}
	else
	{
		//remove do meio da lista
		ant->prox = p->prox;
	}
	free(p);
	return l;
}

void liberar(Lista* l)
{
	Lista* p = l;
	//percorrendo elemento por elemento liberando cada elemento
	while(p != NULL)
	{
		Lista* t = p->prox;
		free(p);
		p = t;
	}
}
	void Salvar(Lista* l1){
		Lista* p1=l1;
		Lista* p2;
		int i=0;
		while(p1 != NULL )
		{
			p1 = p1->prox;
		
		 	 p2 == p1;
	}
	for(p2 = l1; p2 != NULL; p2 = p2->prox){
		
		printf("%do ID: %d\n", i, p2->info);
		i++;
	}
}
/*
	if(p1->info != p2->info)
			
				return 0;
				p1 = p1->prox;
				p2 = p2->prox;
		}
		*/




