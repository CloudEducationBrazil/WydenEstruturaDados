typedef struct lista Lista;

//funcao para criar lista
Lista* criar_lista();


// funcao para inserir no inicio da lista
Lista* inserir_lista(Lista* l, int i, char m[20]);

// funcao para imprimir os elementos da lista
void imprimir_lista(Lista* l);

// funcao para verificar lista 
int verificar_lista_vazia(Lista* l);

// busca de elementos na lista
Lista* buscar(Lista* l, int v);

// remoca ode elementos da lita
Lista* remover (Lista* l, int v);

// libera a lista
void liberar(Lista* l);

// comparar duas listas
int igual(Lista* l1, Lista* l2);

