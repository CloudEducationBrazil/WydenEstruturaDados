 /* ####Arthur de Souza Oliveira - 142030144
########Estrutura de dados
########1.AccessControlAcademic (Controle de Acesso Acad�mico de Alunos
*/

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

void limpaTela(){
    system("CLS");
}

int main(int argc, char** argv)
{
	
	Lista* lista1;
	int info;
	char mat[20];
	
	int funcaoDesejada = 1;

	while(funcaoDesejada < 10 && funcaoDesejada > 0){

        // mostrando o menu
        printf("\n Operacoes \n");
        printf("1 - Criar Lista \n");
        printf("2 - Inserir no inicio da lista \n");
        printf("3 - Imprimir os Elementos da lista \n");
        printf("4 - Liberar/Reinicializar Lista \n");
        printf("5 - Busca de elementos da Lista \n");
        printf("6 - Remover Elementos da Lista Pelo ID \n");
        printf("7 - Salvar a lista \n");
        printf("8 - Verificar Tamanho da lista \n");
        printf("9 - Sair do sistema \n");
        printf("\nEscolha um numero e pressione ENTER: \n");

        //lendo a operacao do usuaro
        scanf("%d", &funcaoDesejada);

        limpaTela();

        
        // chama a funcao desejada
    switch(funcaoDesejada){
    case 1:
    	printf("Funcao escolhida: 1 - Criar Lista \n");
        lista1 = criar_lista();
        printf("Lista Criada!  \n");

        break;
    case 2:
        printf("Funcao escolhida: 2 - Inserir no inicio da lista \n");
        printf("Digite o ID: ");
    	scanf("%d", &info);
    	printf("Digite a Matricula: ");
    	scanf("%s", mat);
 		lista1 = inserir_lista(lista1, info, mat);
        break;
    case 3:
        printf("Funcao escolhida: 3 - Imprimir os elementos da lista: ");
        imprimir_lista(lista1);
        break;
    case 4:
        printf("Funcao escolhida: 4 - Liberar/Reinicializar Lista \n ");
        liberar(lista1);
        break;
    case 5:
        printf("Funcao escolhida: 5 - Busca de elementos da Lista \n");
        printf("Digite o ID: ");
    	scanf("%d", &info);
        
        if(buscar(lista1,info) == NULL)
		printf("Nao encontrou o ID - %d -\n", info);
	else
		printf("ID - %d - encontrado\n", info);
        break;
    case 6:
        printf("Funcao escolhida: 6 - Retirar Elementos da Lista \n");
        printf("Digite o ID: ");
    	scanf("%d", &info);
        
        if(buscar(lista1,info) == NULL){
		printf("Nao encontrou o ID - %d -\n", info);
		}
	else{
		remover(lista1,info);
		printf("ID - %d - ID e Removido \n", info);
	}
        break;
    case 7:
        printf("Funcao escolhida: 7 ");
        Salvar(lista1);
        break;
    case 8:
        printf("Funcao escolhida: 8 - Verificar Tamanho da lista \n");
        verificar_tamanho_lista(lista1);
        
        break;
    case 9:
        printf("Funcao escolhida: 9 ");
        exit(1);
        break;
    }

}
	
	
	
	
	
	
	
	
		
/*	if(verificar_lista_vazia(lista1))
		printf("Lista vazia!\n ");
	else
		printf("Lista NAO VAZIA!\n "); 
	int elemento=100;
	if(buscar(lista1,elemento) == NULL)
		printf("Nao encontrou o elemento - %d -\n", elemento);
	else
		printf("Elemento - %d - encontrado\n", elemento);*/
	

	
	return 0;
}