 /* ####Arthur de Souza Oliveira - 142030144
########Estrutura de dados
########3. InclusionNumbersIntegers
  */
#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

void limpaTela(){
    system("CLS");
}

int main(int argc, char** argv){
	Lista* lista1;
	int info;
	int funcaoDesejada = 1;

	while(funcaoDesejada < 10 && funcaoDesejada > 0){
		
			/*
		1.	Criar Lista (Inicializar Lista) FEITO 1-
		2.	Verificar Tamanho da Lista		FEITO 8-
		3.	Exibir Elementos da Lista		FEITO 3-
		4.	Consultar Elementos na Lista	FEITO 5-
		5.	Inserir Elemento na Lista		FEITO 2- 
		6.	Alterar Elemento da Lista		N�O
		7.	Excluir Elemento da Lista		FEITO 6-
		8.	Salvar Lista					N�O
		9.	Carregar Lista					N�O
		10.	Reinicializar Lista				FEITO 4-
		*/

        // mostrando o menu
        printf("\n Operacoes \n");
        printf("1 - Criar Lista \n");
        printf("2 - Inserir REGISTRO no inicio da lista \n");
        printf("3 - Imprimir os REGISTROS da lista \n");
        printf("4 - Liberar/Reinicializar Lista \n");
        printf("5 - Busca de REGISTROS da Lista \n");
        printf("6 - Remover REGISTROS da Lista \n");
        printf("7 - Salvar a lista \n");
        printf("8 - Verificar Tamanho da lista \n");
        printf("9 - Sair do sistema \n");
        printf("\nEscolha um numero e pressione ENTER: \n");

        //lendo a operacao do usuaro
        scanf("%d", &funcaoDesejada);

        limpaTela();

        
        // chama a funcao desejada
    switch(funcaoDesejada){
    case 1:
    	printf("Funcao escolhida: 1 - Criar Lista \n");
        lista1 = criar_lista();
        printf("Lista Criada!  \n");

        break;
    case 2:
        printf("Funcao escolhida: 2 - Inserir Registro no inicio da lista \n");
        printf("Digite o Registro: ");
    	scanf("%d", &info);
 		lista1 = inserir_lista(lista1, info);
        break;
    case 3:
        printf("Funcao escolhida: 3 - Imprimir os Registro da lista: ");
        imprimir_lista(lista1);
        break;
    case 4:
        printf("Funcao escolhida: 4 - Liberar/Reinicializar Lista \n ");
        liberar(lista1);
        break;
    case 5:
        printf("Funcao escolhida: 5 - Busca de Registro da Lista \n");
        printf("Digite o Registro: ");
    	scanf("%d", &info);
        
        if(buscar(lista1,info) == NULL)
		printf("Nao encontrou o Registro - %d -\n", info);
	else
		printf("Registro - %d - encontrado\n", info);
        break;
    case 6:
        printf("Funcao escolhida: 6 - Retirar Registro da Lista \n");
        printf("Digite o ID: ");
    	scanf("%d", &info);
        buscar(lista1, info);
        if(buscar(lista1,info) == NULL){
		printf("Nao encontrou o Registro - %d - \n", info);
		}
	else{
		remover(lista1,info);
		printf("Registro - %d - Removido \n", info);
	}
        break;
    case 7:
        printf("Funcao escolhida: 7 ");
        Salvar(lista1);
        break;
    case 8:
        printf("Funcao escolhida: 8 - Verificar Tamanho da lista \n");
        verificar_tamanho_lista(lista1);
        
        break;
    case 9:
        printf("Funcao escolhida: 9 ");
        exit(1);
        break;
    }

}

		
/*	if(verificar_lista_vazia(lista1))
		printf("Lista vazia!\n ");
	else
		printf("Lista NAO VAZIA!\n "); 
	int elemento=100;
	if(buscar(lista1,elemento) == NULL)
		printf("Nao encontrou o elemento - %d -\n", elemento);
	else
		printf("Elemento - %d - encontrado\n", elemento);*/

	return 0;
}