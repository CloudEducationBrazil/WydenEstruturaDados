1. Impress�o de 1 at� 10 utilizando recursividade
2. C�lculo de Fatorial
3. Somat�rio de 2 ate 100 dos pares
4. Elaborar um programa menu recursivo chamando as opera��es matem�ticas
5. Vetor
6. Somat�rio da Seq de Fibonacci

1 + 1 + 2 + 3 + 5 + 8 + 13 + 21 + 34 + 55 + ...

Respostas:

1. 
void fImprime(int num) {
    printf("%d ", 11 - num);
    if ( num != 1 ) 
      fImprime(num-1);
}

int main()
{   fImprime(10);
    return 0;
}

2. 

int fFatorial(int num) {
    if ( num == 0) return 1;
    else return num * fFatorial(num - 1);
}

int main()
{   int numero;
    scanf("%i",&numero);
    if ( numero >=0 )
	  printf("%d", fFatorial(numero));
	else
	  printf("Fatorial n�o existe");
    return 0;
}

3.

int fSomatorio(int num) {
    if ( num == 0) return 0;
	 return num + fSomatorio(num - 2);
}

int main()
{  	printf("%d", fSomatorio(10));
    return 0;
}

4. 

#include <stdio.h>
#include <stdlib.h>

void menu();
void adicao();
void subtracao();
void divisao();
void multiplicacao();
void sair();

int main()
{  	menu();
    return 0;
}

void menu(){
	int opc;
	system("CLS");
	printf("Escolha sua opcao \n \n:");
	printf("1 - adicao \n \n:");
	printf("2 - subtracao \n \n:");
	printf("3 - divisao \n \n:");
	printf("4 - multiplicacao \n \n:");
	printf("5 - Sair \n \ \n:");
	
	printf("opcao:");
	scanf("%d", &opc);
	
	switch (opc) {
	   case 1 : adicao(); break;
	   case 2 : subtracao(); break;
	   case 3 : divisao(); break;
	   case 4 : multiplicacao(); break;
	   case 5 : sair(); break;
	   default:
	      printf("op��o inv�lida \n");
	      menu();
		}
}

void adicao(){
	int a=7 , b=9;
	
	printf("\nselecionou adi��o \n");
	printf("Soma %d \n", a + b);
	system("PAUSE");
    menu();
}

void subtracao(){
	int a , b;
	scanf("%d", &a);
	scanf("%d", &b);
	
	printf("\nselcionou subtra��o \n");
	printf("Subtracao %d \n", a - b);
	system("PAUSE");
	menu();
}

void divisao(){
	printf("selcionou divis�o");
	system("PAUSE");
	menu();
}

void multiplicacao(){
	printf("selcionou multiplica��o");
	system("PAUSE");
	menu();
}

void sair(){
	printf("selcionou sair");
	exit(1);
}

5.

#include <stdio.h>
#include <stdlib.h>

void fLerVetor(int *v, int x);
int fSomarVetor(int *v, int x);

int main()
{ int v[3], resultado;

  fLerVetor(v, 3);
  resultado = fSomarVetor(v, 3);
  printf("Resultado: %d", resultado);
  return 0;
}

void fLerVetor(int *v, int x){
	for (x=0; x<=2; x++)
	{
		printf("Digite um numero \n");
		scanf("%d", &v[x]);
	}
}

int fSomarVetor(int *v, int x){
	int soma;
	for (x=0; x<=2; x++)
	{
		soma += v[x];
	}
	return soma;
}

6. Seq Fibonacci

#include <stdio.h>
//#include <conio.h> 

int fibonacci(int n);

main()
{
   int n,i;
   printf("Digite a quantidade de termos da sequ�ncia de Fibonacci: ");
   scanf("%d", &n);

   printf("\nA Sequ�ncia de Fibonacci e: \n");
   for(i=0; i<n; i++)
       printf("%d ", fibonacci(i+1));
   return 0;
} 

int fibonacci(int n)
{ int retorno;
   if ( (n==1) || (n==2) )
       return 1;
   else { 
          retorno = fibonacci(n-1) + fibonacci(n-2);     
          return retorno; 
       }
}

***************** PONTEIROS
# include <stdio.h>
# include <stdlib.h>

int main()
{
	int x=19;
	int *p;
	p = &x;
	printf("%p \n", &x);
	printf("%p \n", &p);
	printf("%d \n", *p);
	return 0;
}


