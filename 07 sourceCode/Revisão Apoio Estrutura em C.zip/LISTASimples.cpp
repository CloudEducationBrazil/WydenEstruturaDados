#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#define tamVetor 5
#define FALSE 0
#define TRUE 1

//typedef int bool;
//enum { false , true };

//typedef enum {false , true} bool;

typedef int TIPO_CHAVE;

typedef struct {
	TIPO_CHAVE chave;
} REGISTRO;

typedef struct {
	REGISTRO A[tamVetor];
	int nroElemt;
} LISTA;

void inicializarLista(LISTA* l);
int tamanhoLista(LISTA* l);
void exibirLista(LISTA* l);
int  buscarLista(LISTA* l, TIPO_CHAVE ch);
bool inserirLista(LISTA* l, REGISTRO reg, int pos);
//bool excluirLista(LISTA* l, REGISTRO reg, int pos);
//bool alterarLista(LISTA* l, REGISTRO reg, int pos);
void sair();
int menu(int *opc);

int main() {
  LISTA lista;
  REGISTRO reg;
  int opc;
  int pos;
  
  do {
    menu(&opc);

	//printf("%d  xxxx TESTE", opc);
  
	switch ( opc ) {
		case 1  : inicializarLista(&lista); break;
		case 2  : tamanhoLista(&lista); 
		 		  //printf("Tamanho da lista (em bytes): %i.\n",tamanhoEmBytes(&lista));
		  		  printf("Numero de elementos na lista: %i.\n",tamanhoLista(&lista));
		  		  system("pause");
				  break;
		case 3  : exibirLista(&lista); break;
		case 4  :  printf("Qual elemento"); 
		           scanf("%d", &reg);
		           pos = buscarLista(&lista, 3); 
		           if ( pos == -1 ) 
		             printf("Elemento n�o encontrado");
		           //else
		           //  printf("Elemento %d", A[pos]);
		           
		           break;
		case 7  : sair(); break;
		default : printf("Opcao Invalida\n");
		          system("PAUSE");
				  menu(&opc);
		          break;
	};
  } while ( opc != 7);
  
  return 0;
};

void inicializarLista(LISTA* l){
	l->nroElemt = 0;
};

int tamanhoLista(LISTA* l){
	return l->nroElemt;
};

void exibirLista(LISTA* l){
	for ( int i = 0; i < l->nroElemt; i++)
	  printf("Elemento [%d] = %d", i, l->A[i].chave);

	system("pause");
};

int buscarLista(LISTA* l, TIPO_CHAVE ch){
	for ( int i = 0; i < l->nroElemt; i++ )
	  if ( ch == l->A[i].chave ) 
	    return i;
    return -1;
};

bool inserirLista(LISTA* l, REGISTRO reg, int i) {
  if ( ( l->nroElemt == tamVetor ) || ( i < 0 ) || ( i > l->nroElemt ) )
    return FALSE;
  
  for ( int j=l->nroElemt; j > i; j-- )
    l->A[j] = l->A[j-1];
    
  l->A[i] = reg;
  l->nroElemt++;
  return TRUE;
};

//bool inserirLista(LISTA* l, REGISTRO rg, int pos);

int menu(int *opc) {
	int opcAux;
	system("CLS");
	printf("Selecione uma Opcao\n\n\n");
	printf("0 Inicializar Lista\n\n");
	printf("1 Tamanho da Lista\n\n");
	printf("2 Exibir Lista\n\n");
	printf("3 Buscar Lista\n\n");
	printf("4 Inserir Lista\n\n");
	printf("5 Excluir Lista\n\n");
	printf("6 Alterar Lista\n\n");
	printf("7 Sair Lista\n\n");
	scanf("%d", &opcAux);

	*opc = opcAux;
	
	return opcAux;
};

void sair(){
	system("pause");
	exit(1);
};

