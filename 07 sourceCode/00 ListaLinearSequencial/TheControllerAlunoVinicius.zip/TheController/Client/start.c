#include <stdio.h>
#include <stdlib.h>
#include "start.h"
#include "accesscontrol.h"

void help(){
	
	system("CLS");
    printf("Modulos disponiveis:\n");
    printf("\n");
    printf("AcccesControlAcademic - a\n");
    printf("ScheduleCommitments - b\n");
    printf("InclusionNumbersIntegers - c\n");
    printf("Sair - q \n");
    
     char c = ' ';
    printf("Digite Opcao ? \n");
  scanf("%c",&c);
  while (c != 'q'){
    switch (c) {
      case 'a' : controleacesso(); break;
	  }
    } 

  } 
     


