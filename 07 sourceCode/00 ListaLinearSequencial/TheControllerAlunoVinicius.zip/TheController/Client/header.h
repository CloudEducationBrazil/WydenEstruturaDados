/* This application coded by Vinicius Santana */
/* contact  jakov.dev@gmail.com or san.vini@yahoo.com */
/* Don't allow the reproduction for part ou complete code */
/* CONTROLLER 1.0 */

// Header Lib File

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef int TIPOCHAVE;

typedef struct {
	int dia;
	int mes;
	int ano;
} dataRef;

typedef struct {
	dataRef dataAcesso; // Data de Acesso
	char nomePorteiro[200]; // Nome Porteiro
} dadosHeaderf;


