/* This application coded by Vinicius Santana */
/* contact  jakov.dev@gmail.com or san.vini@yahoo.com */
/* Don't allow the reproduction for part ou complete code */
/* CONTROLLER 1.0 */

// Acess control structure library
#include <stdio.h>
#include <stdlib.h>
#include "header.h"
#include <malloc.h>
#include <stdbool.h>
#include <time.h>
//Structure of data

void controleacesso();
void accesscontrolmodule();
void limpar();
void exibirdata();
void inserirdata();
int tamanho_data();

typedef struct {
	TIPOCHAVE chave; // Controle ID
	char matricula[20]; // Matr�cula do Aluno
	char TipoOcorrencia[10];
	dadosHeaderf header;
} Registro;

typedef struct temp {
	Registro dados;
	struct temp* prox;
} ELEMENTO;

typedef ELEMENTO* pont;

typedef struct{
	pont inicio;
} Lista;


void iniciarlista(Lista* l){
	l->inicio = NULL;
}

void limparlista(Lista* l){
	pont end = l->inicio;
	while(end!=NULL){
		pont apagar = end;
		end = end->prox;
		free(apagar);
	}
	l->inicio=NULL;
}


// Retorno tamanho lista em elementos.

int tamanho(Lista* l){
	pont end = l->inicio;
	int tam = 0;
	while(end != NULL){
		tam++;
		end = end->prox;
	}
	return tam;
	getchar();
}

//Fun��o retorno tamanho de lista em bytes
int tamanho_bytes(Lista* l){
	return(tamanho(l)*sizeof(ELEMENTO))+sizeof(Lista);
}


//  Fun��o para exibi��o de elementos da lista.
void exibir(Lista* l){
	Registro dados;
	pont end = l->inicio;
	if (end==NULL){
		printf("Esta lista esta vazia.\n");
	}
	else{
		printf("Lista:\n"" ");
		while(end!=NULL){
			printf("%d %s %s \n",end->dados.chave,end->dados.matricula,end->dados.TipoOcorrencia,end->dados.header.nomePorteiro,dados.header.dataAcesso.dia,dados.header.dataAcesso.mes,dados.header.dataAcesso.ano);
			end= end->prox;
		}
		printf("\n ");
	}
}

// Busca sequencial
pont buscaSeqExc(Lista* l, TIPOCHAVE ch, pont* ant){
  *ant = NULL;
  pont atual = l->inicio;
  while (atual != NULL && atual->dados.chave<ch){
    *ant = atual;
    atual = atual->prox;
  }
  if ((atual != NULL) && (atual->dados.chave == ch)) return atual;
  return NULL;
}

bool excluiritem(Lista* l, TIPOCHAVE ch){
  pont ant, i;
  i = buscaSeqExc(l,ch,&ant);
  if (i == NULL) return false;
  if (ant == NULL) l->inicio = i->prox;
  else ant->prox = i->prox;
  free(i);
  return true;
}

// Inserir Elementos

bool inserirElemListaOrd(Lista* l, Registro dados) {
  TIPOCHAVE ch = dados.chave;
  pont ant, i;
  i = buscaSeqExc(l,ch,&ant);
  if (i != NULL)  return false;
  i = (pont) malloc(sizeof(ELEMENTO));
  i->dados = dados;
  if (ant == NULL) { // o novo elemento serah o 1o da lista
    i->prox = l->inicio;
    l->inicio = i;
  } else {  // inser��o ap�s um elemento j� existente
    i->prox = ant->prox;
    ant->prox = i;
  }
  return true;
}

// inserir dados

void inserir(Lista *l){
  Registro dados;
  printf("Digite Elemento ? \n ");
  fflush(stdin);
  scanf("%i",&dados.chave);

  printf("Digite a matricula ?\n ");
  fflush(stdin);
  scanf("%s",&dados.matricula);

  printf("Digite tipo de ocorrencia \n ");
  fflush(stdin);
  scanf("%s",&dados.TipoOcorrencia);

  printf("Digite nome do porteiro \n ");
  fflush(stdin);
  scanf("%s",&dados.header.nomePorteiro);

  if (inserirElemListaOrd(l,dados)) printf("Elemento %i %s %s inserido corretamente.\n",dados.chave,dados.matricula,dados.TipoOcorrencia);
  else printf("Nao foi possivel inserir elemento %i.\n \n",dados.chave);

  getchar();
}

// Modulos de gerenciamento de estruturas .

Lista lista;

void accesscontrolmodule(){
	iniciarlista(&lista);
	printf("Lista inicializada com sucesso. \n");

}

void limpar(){
	limparlista(&lista);
	printf("Lista limpa com sucesso \n");
}

void excluir(Lista *l){
  TIPOCHAVE ch;
  printf("Digite Elemento ? ");
  scanf("%i",&ch);
  if (excluiritem(l,ch)) printf("Elemento %i excluido corretamente.\n",ch);
  else printf("Nao foi possivel excluir elemento %i.\n \n",ch);

  getchar();
}

void exibirdata(){
	exibir(&lista);
}

void inserirdata(){
	inserir(&lista);
}

void tamanho_lista(Lista *l){
	printf("O numero de elementos na lista e %i. \n",tamanho(l));
	getchar();
}



