#include <stdio.h>
#include <stdlib.h>
#include "start.h"
#include <unistd.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	printf("Bem vindo ao controller 1.0 \n");
	printf("Voce esta usando o cliente 1.0 \n");
	printf("Iniciando testes de conexao.... \n");
	sleep(1);
	help();
	return 0;
}
