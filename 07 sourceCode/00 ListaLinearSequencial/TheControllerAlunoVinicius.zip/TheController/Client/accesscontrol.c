/* This application coded by Vinicius Santana */
/* contact  jakov.dev@gmail.com or san.vini@yahoo.com */
/* Don't allow the reproduction for part ou complete code */
/* CONTROLLER 1.0 */

//Acess control structure file

#include <stdio.h>
#include <stdlib.h>


void controleacesso(){
	system("cls");
	printf("Bem vindo ao modulo de controle de acesso ! \n");
	printf("\n");
	printf("E possivel utilizar as seguintes funcoes \n");
	printf("\n");
	printf("Inicializar lista : i \n");
	printf("Verificar tamanho da lista : v \n");
	printf("Exibir elementos da lista : e \n");
	printf("Consultar elementos da lista : c \n");
	printf("Inserir elemento na lista : x \n");
	printf("Alterar elemento na lista : z \n");
	printf("Excluir elemento da lista : d \n");
	printf("Salvar lista no servidor : s \n");
	printf("Carregar lista existente do servidor : r \n ");
	printf("Reinicializar lista : k \n");

	char c = ' ';
    printf("Digite Opcao ? \n");
    scanf("%c",&c);
    while (c != 'q'){
    	switch (c) {
      	case 'i' : accesscontrolmodule(); break;
      	case 'k' : limpar(); break;
      	case 'e' : exibirdata(); break;
      	case 'x' : inserirdata(); break;
      	case 'v' : tamanho_lista(); break;
      	case 'd' : excluir(); break;

      	default: {while (c != '\n') scanf("%c",&c);};
    }
    printf("Digite Opcao ? \n");
    scanf("%c",&c);
  }
}
